// Tiny capture sink for headless verification.
// The page renders a frame, encodes it as a JPEG data URL, and POSTs it here;
// we decode and write it to liberty3d/shots/<name>.jpg so it can be read back.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const DIR = path.join(here, '..', 'shots');
fs.mkdirSync(DIR, { recursive: true });
let counter = 0;

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', '*');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
  if (req.method === 'GET') { res.writeHead(200); res.end('shot-server ok\n'); return; }
  if (req.method === 'POST') {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      try {
        const u = new URL(req.url, 'http://x');
        const name = (u.searchParams.get('name') || ('shot' + (++counter))).replace(/[^a-z0-9_.-]/gi, '_');
        let b64 = body;
        const comma = b64.indexOf(',');
        if (b64.startsWith('data:') && comma >= 0) b64 = b64.slice(comma + 1);
        const buf = Buffer.from(b64, 'base64');
        const file = path.join(DIR, name + '.jpg');
        fs.writeFileSync(file, buf);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, file, bytes: buf.length }));
        console.log('wrote', file, buf.length, 'bytes');
      } catch (e) {
        res.writeHead(500); res.end(String(e));
      }
    });
    return;
  }
  res.writeHead(404); res.end();
});
server.listen(5199, () => console.log('shot-server listening on http://localhost:5199 ->', DIR));
