# LIBERTY DRIVE — PROGRESS

Self-refining build loop state. Read this first every cycle. Scores are harsh and honest; no self-congratulation.

## Architecture decisions (settled — don't relitigate without strong cause)
- **Renderer: real-time 3D, WebGL via Three.js.** Rationale: the user explicitly required a *true 3D third-person open-world* (not a top-down 2D canvas). This overrides the generic "default to single-file canvas" guidance. Settled 2026-06-25.
- **Build: Vite + multi-file ES modules** under `src/` (city, player, vehicle, npc, effects, audio, cameraRig, hud, input, util, config, main). Justified: the world is already past the single-file bottleneck.
- **Physics: custom arcade** (no physics lib). Flat ground (y=0), circle-vs-AABB building collision, velocity-based car model. Keeps it deterministic and tunable.
- **Toolchain:** portable Node at `%LOCALAPPDATA%\node-portable\...` (not on PATH). Run via preview `liberty3d` config or `play.bat`. Headless verify trick: `window.__game.tickOnce(dt)` + `setLoopPaused(v)` (rAF is paused on the hidden preview tab).

## Pillar scores (0–10) — cycle 2026-06-26
| Tier | Pillar | Score | Notes |
|---|---|---|---|
| 1 | Vehicle feel | **7.5** ↑ | grip/drift/handbrake-slide + weight-transfer lean; tyre smoke + skid marks; **5 distinct classes** (sports/muscle/van/compact/sedan — accel/top/grip/turn). Verified sports 99.8 vs van 61.8. Missing: suspension, steered front wheels, collision impact feel. |
| 1 | On-foot + camera | 6.5 | responsive; follow-cam w/ wall collision; walk/run/jump. Aim could be tighter. |
| 2 | Map & navigation | **6.5** ↑ (was 5.5) | + 4 quadrant district palettes (NE warm / NW steel / SE concrete / SW teal) and a distinct 232-tall beacon-topped landmark tower at block (6,5) to orient by. Still grid-uniform road geometry; no full-map screen. |
| 2 | Traffic & ped AI | 5.0 | cardinal road-following traffic; peds wander + alarm on gunfire. No yielding, no traffic lights, no real pathing. |
| 3 | Wanted/heat | 5.5 | stars escalate, police spawn/chase/shoot, cooldown decay. No line-of-sight / no real evasion. |
| 3 | Missions | **6.5** ↑ | data-driven job-giver at the marker: DELIVER/CHASE/EVADE/COLLECT/ELIMINATE — timers, scaled payouts, success/fail + cleanup; target cars shootable; magenta objective blip. Verified full lifecycle. |
| 3 | Combat & interaction | **6.5** ↑ | 3 weapons (1·2·3, shop-unlocked) with per-weapon ped damage wired to ped HP: pistol one-shots, SMG/shotgun WOUND→flee (shotgun pellets matter by range). Carjack enter/exit, hitscan, damage model. Still no melee; can't pull AI drivers out. |
| 3 | Economy & progression | **6.5** ↑ | armor (soaks dmg, HUD bar) + LOADOUT shop (hold E): ammo/armor/health, SMG+Shotgun unlocks, +top-speed/+plating upgrades; survive-heat cash bonus. Verified. |
| 4 | Time/weather/lighting | 5.0 | day/night cycle added. No weather. |
| 4 | Audio | 4.5 | engine-by-speed, siren, gunshot. No radio, weak positioning. |
| 4 | HUD/UX | 6.5 | minimap, vitals, money, stars, weapon/ammo, speedo, damage vignette. No full-map screen. |
| 4 | Juice | **5.5** ↑ | muzzle/tracer/blood/explosion/body-roll + tyre smoke + skid marks. Still no screen shake / camera kick. |
| 5 | Performance | 6.0 | instanced buildings, pooled FX, far-traffic recycle. ~160–220 draw calls. Not profiled at max density. |
| 5 | Architecture | 6.5 | clean module split; data-driven WEAPONS/PICKUP_TYPES arrays. |

## Biggest weakness → next target (9-agent audit, ranked by leverage = weight × (10−score))
1. ~~Missions & economy (lev 40)~~ — **DONE 2026-06-26**: 5 mission types (DELIVER/CHASE/EVADE/COLLECT/ELIMINATE) + LOADOUT shop/armor/upgrades, both verified. New top priority is Traffic/ped AI + Combat depth (peds have no hp).
2. **Vehicle feel (lev 25)** — drift now readable (skids done). Next: distinct vehicle classes (per-class ENGINE/GRIP/MAX_SPEED), steered front wheels, collision impact feel.
3. **Map & navigation (lev 24)** — districts + landmark done; next: legible roads (curbs/stop-lines), 1–2 more landmarks.
4. **Combat & interaction (lev 24)** — peds have NO hp (instant-kill at any range, shotgun pellets wasted); no real carjacking (can't pull AI drivers out). Add ped hp + hurt()/flinch; eject AI driver on F.

Coordination note: a parallel editor is actively improving the same files (it shipped skid marks). De-conflict by taking a different pillar than vehicle/effects when possible; always re-read before editing.

## Changelog (newest first)
- **2026-06-26 — Project Bible + free asset pipeline + dialogue/voice.** Multi-agent design pass produced **docs/BIBLE.md** (world "SOLACE" — 5 named districts, 4 factions, 7-character cast, 10-mission story mapped to the 5 mission types, art/audio/realism charter, roadmap + "Definition of Convincing") and **docs/ASSET_PIPELINE.md** (procedural-first / CC0 / AI plan: Kenney, Quaternius, Poly Haven, ambientCG, freesound, jsfxr, Piper TTS + Three.js integration). These + PROGRESS.md are the rails. Shipped **src/dialogue.js**: free Web Speech API voice + subtitle overlay, canon cast (Wren/Tio/Mara/Civic Shield/Lucia/Dorian/Echo), wired to welcome / mission-giver / complete / fail / wasted lines. Verified: lines display + speak, fade out, no errors. Also fixed vite.config to honor `PORT` so the preview tool's autoPort matches Vite's bind.
- **2026-06-26 — HUD: full-screen city map (Tier 4).** Press **M** (or Esc) to toggle a full-map overlay rendered in `hud.js` — whole city + all blips + player heading. Self-contained (no main.js/index.html edits) to de-conflict. Verified: M opens/closes, map renders content, no errors.
- **2026-06-26 — Juice: screen shake (Tier 4).** `cameraRig.addShake()`/decay jitters the camera position while keeping aim on target; triggers: gun kick (0.045), taking damage (scaled by n), explosions (1.1). Verified: hit→shake 0.6, cam jitter 0.82, decays to 0, no errors. Score (juice) 5.5→6.5.
- **2026-06-26 — Weather (Tier 4).** New `weather.js`: slow clear↔overcast↔rain cycle; instanced rain (up to 900 streaks) around the player, dimmer sun/ambient + greyer fog with a closer far-plane when wet; runs after day/night so it composes with time-of-day. Verified: RAIN→900 drops & fog far 330, CLEAR→0 & far 760, no errors. Kept in a standalone module to de-conflict with the parallel editor. Score (time/weather/lighting) 5.0→6.5.
- **2026-06-26 — Combat depth: ped HP wired (Tier 3).** fireOnce now calls `ped.hurt(dmgPed)` instead of instant `die()`; added per-weapon `dmgPed` (pistol 100 one-shot, SMG 34, shotgun 24/pellet). Peds wound→flee instead of always dying; shotgun pellets aggregate by range. Verified: SMG hit → hp 100→66 + panic flee; pistol → kill; 19 peds, no errors. Score 5.5→6.5.
- **2026-06-26 — Vehicle classes (Tier 1).** 5 classes (sedan/sports/muscle/van/compact) as multipliers on ENGINE/MAX_SPEED/GRIP/TURN; player + traffic get a random class, police = sports. Verified: sports top 99.8 vs van 61.8, 4 distinct among spawns, no errors. Feel 6.5→7.5.
- **2026-06-26 — Economy + Shop + Armor (Tier 3).** Armor soaks damage before health (HUD bar). LOADOUT shop (drive/walk in, hold E) sells ammo refill, +50 armor, full health, SMG/Shotgun unlocks (weapon hotkeys gated by `state.unlocked`), +top-speed & +armor-plating upgrades; surviving heat to 0★ pays $40/peak-star. Verified: soak order (armor→hp), hold-E open, buys, gating (Digit2 locked→unlocked), upgrade, HUD bar. Score 2→6.5.
- **2026-06-26 — Missions: data-driven job system (Tier 3).** Marker is a job-giver; 5 types (DELIVER/CHASE/EVADE/COLLECT/ELIMINATE) with timers, scaled payouts, success/fail + cleanup; mission target cars (kind 'mission') shootable; magenta objective blip; job cancels on death. Verified full lifecycle (COLLECT paid, 0 orphan cars, no errors). Score 2.5→6.5. (Design via background workflow.)
- **2026-06-26 — Map: district identity + landmark (Tier 2).** 4 per-quadrant building palettes so each corner reads differently; one distinct deep-blue 232-tall skyscraper with an emissive gold beacon at block (6,5) to orient by. Verified: landmark at (155,93), tallest=232, no errors. Score 5.5→6.5.
- **2026-06-26 — Vehicle juice: tyre smoke + skid marks (Tier 1/4).** Skid decals at rear wheels + smoke puffs when lateral slip is high → the drift model is now readable. (effects.js skid()/smoke() + vehicle.slip + main.js emit.) Score: feel 6→6.5, juice 4.5→5.5.
- **2026-06-26 — Vehicle feel: grip/drift model (Tier 1).** Player car now uses world-space velocity decomposed into longitudinal (engine/brake/drag) + lateral (grip). Steering turns the nose without rotating momentum → real slip; handbrake/boost drop grip for drifts. Added weight-transfer body lean (roll/pitch, YXZ euler). AI kept on the on-rails model (no pathing regression). Verified: slip 0°→15°→44° (straight/turn/handbrake), traffic still moves, no NaN. Score 3→6.
- **2026-06-25 — Day/night cycle (Tier 4).** ~3.5-min cycle drives sun height/intensity/color, ambient, sky dome, fog. Verified noon vs midnight.
- **2026-06-25 — World pickups (Tier 3).** Health / SMG-ammo / shotgun crates that grant + relocate on cooldown; minimap blips. Verified +30 HP, +90 ammo.
- **2026-06-25 — Hit feedback (Tier 4 juice).** Red screen-flash on damage + low-HP pulse vignette (injected from hud.js).
- **2026-06-25 — Weapons (Tier 3).** Pistol/SMG/Shotgun, 1·2·3 switch, fire-rate/spread/pellets, finite ammo, wired to existing HUD.
- **2026-06-25 — Police rebalance.** Lethality scaled with stars; ★★★ now survivable (100→86 HP/5s vs instant death).

## Known bugs / debt
- A car left mid-drift keeps a tiny body lean while parked (cosmetic; _roll/_pitch not reset on exit).
- Police have perfect knowledge of player position (no line-of-sight / evasion).
- Traffic doesn't yield or obey intersections; can pile up.
- No full-map screen; minimap only.
- Weapon HUD hint shows [1·2·3] but SMG/shotgun now start locked (buy at LOADOUT shop); SMG/shotgun ammo pickups are inert until the weapon is unlocked.
