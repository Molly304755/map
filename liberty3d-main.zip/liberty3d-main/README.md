# SOLACE — *No City Sleeps Clean*
### (working repo: `liberty3d`)

An original, **GTA-style 3D third-person open-world sandbox** that runs in the browser — built with **Three.js + Vite** and custom arcade physics. Drive distinct cars with real drift, jack them, run missions for cash, dodge an escalating police "heat" system, and explore a districted city through a day/night + weather cycle. Original IP — *Solace City, 2031*, a corporate-dystopia satire.

> ⚠️ Active development / prototype. See **`PROGRESS.md`** for the live state & scores and **`docs/BIBLE.md`** for the full design.

![Daytime](shots/cur_day.jpg)
| Night | Map |
|---|---|
| ![Night](shots/cur_night.jpg) | ![Map](shots/cur_map.jpg) |

## Run it

Requires **Node 18+**.

```bash
npm install
npm run dev          # → http://localhost:5173
```

Production build: `npm run build` (outputs `dist/`, serve it with any static server, e.g. `npm run preview`).

**Windows one-click:** double-click `play.bat` (uses a portable Node at `%LOCALAPPDATA%\node-portable\...` if you don't have Node on PATH; otherwise just use `npm run dev`).

## Controls

| Input | Action |
|---|---|
| **W A S D** | Walk / run · drive |
| **Mouse** | Look / aim · **Click** shoot |
| **Shift** | Sprint · boost |
| **Space** | Jump · handbrake |
| **F** | Enter / exit (jack) a car |
| **1 · 2 · 3** | Weapons (SMG/Shotgun unlock at the shop) |
| **E** (hold) | Shop, at the cyan marker |
| **M** | Full-screen city map |
| **Esc** | Release mouse / close menus |

## What's in here

- **Driving** — arcade grip/drift model with handbrake, weight-transfer lean, tyre smoke + skid marks, and 5 vehicle classes.
- **Missions** — a data-driven job system: DELIVER / CHASE / EVADE / COLLECT / ELIMINATE, with timers, payouts and a giver.
- **Combat & heat** — 3 weapons, pedestrian HP, a wanted-stars police system that spawns, chases and shoots.
- **Economy** — money, a LOADOUT shop (armor, ammo, weapon unlocks, top-speed & armor upgrades), world pickups.
- **World** — procedural 8×8 city, four colour-coded districts + downtown + a landmark tower, day/night cycle, dynamic rain, street lamps, lit windows.
- **Voice & dialogue** — free runtime voice via the browser **Web Speech API** + subtitles, with an original cast (Wren, Tio, Mara, Civic Shield, Lucia, Dorian, Echo).
- **Juice & HUD** — muzzle/tracers/blood/explosions, screen shake, minimap + full map, health/armor/money/stars/weapon/speedometer.

## Project structure

```
src/        game modules (main, city, vehicle, npc, player, effects, audio,
            weather, dialogue, cameraRig, hud, input, config, util)
docs/       BIBLE.md (world/story/cast/art/audio/realism/roadmap)
            ASSET_PIPELINE.md (free / AI asset sourcing → Three.js)
PROGRESS.md live per-cycle tracker (pillar scores + changelog)
tools/      shot-server.mjs (headless screenshot sink for verification)
shots/      reference screenshots
```

## Docs / design

- **`docs/BIBLE.md`** — the source of truth: world, factions, characters, the 10-mission story, art/audio/realism charter, roadmap, and the "Definition of Convincing" that marks done-enough.
- **`docs/ASSET_PIPELINE.md`** — how to bring in **free / AI-generated** meshes, textures, sounds, music and voice (procedural-first → CC0 → AI) and wire them into Three.js.

## Tech

Three.js · Vite · vanilla ES modules · custom arcade physics (no physics lib) · procedural geometry & textures · Web Speech API for voice. All assets currently procedural or runtime-generated; real CC0/AI assets are the next phase (see the pipeline doc).
