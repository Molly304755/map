import * as THREE from 'three';
import { PLAYER } from './config.js';
import { clamp, damp, dampAngle, lerp } from './util.js';

// A simple low-poly humanoid assembled from boxes, with limbs pivoted at the
// hips/shoulders so we can drive a procedural walk cycle. Reused for NPCs by
// passing a colour palette.
export function buildAvatar(palette = {}) {
  const root = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({ color: palette.skin ?? 0xd8a07a, roughness: 0.8 });
  const jacket = new THREE.MeshStandardMaterial({ color: palette.jacket ?? 0x2f6f8f, roughness: 0.7 });
  const pants = new THREE.MeshStandardMaterial({ color: palette.pants ?? 0x2a2f3a, roughness: 0.9 });
  const shoe = new THREE.MeshStandardMaterial({ color: palette.shoe ?? 0x14161b, roughness: 0.9 });

  const legLen = 1.5, torsoLen = 1.25, armLen = 1.25;
  const hipY = legLen, shoulderY = legLen + torsoLen - 0.15;

  const mk = (geo, mat, cast = true) => { const m = new THREE.Mesh(geo, mat); m.castShadow = cast; return m; };

  // torso
  const torso = mk(new THREE.BoxGeometry(1.1, torsoLen, 0.6), jacket);
  torso.position.y = hipY + torsoLen / 2;
  // head
  const head = mk(new THREE.BoxGeometry(0.62, 0.62, 0.62), skin);
  head.position.y = hipY + torsoLen + 0.34;
  // hair / cap
  const cap = mk(new THREE.BoxGeometry(0.66, 0.22, 0.66), pants);
  cap.position.y = hipY + torsoLen + 0.62;
  root.add(torso, head, cap);

  const makeLimb = (px, pivotY, len, w, mat, withShoe) => {
    const g = new THREE.Group();
    g.position.set(px, pivotY, 0);
    const seg = mk(new THREE.BoxGeometry(w, len, w), mat);
    seg.position.y = -len / 2;
    g.add(seg);
    if (withShoe) {
      const s = mk(new THREE.BoxGeometry(w + 0.08, 0.3, w + 0.45), shoe);
      s.position.set(0, -len + 0.05, 0.12);
      g.add(s);
    }
    root.add(g);
    return g;
  };

  const legL = makeLimb(-0.3, hipY, legLen, 0.42, pants, true);
  const legR = makeLimb(0.3, hipY, legLen, 0.42, pants, true);
  const armL = makeLimb(-0.72, shoulderY, armLen, 0.34, jacket, false);
  const armR = makeLimb(0.72, shoulderY, armLen, 0.34, jacket, false);

  // a little pistol in the right hand
  const gun = mk(new THREE.BoxGeometry(0.22, 0.22, 0.7), shoe);
  gun.position.set(0, -armLen + 0.1, 0.3);
  gun.visible = false;
  armR.add(gun);

  return { root, legL, legR, armL, armR, gun, height: hipY + torsoLen + 0.66 };
}

export class Player {
  constructor(scene, spawn) {
    const a = buildAvatar();
    this.avatar = a;
    this.mesh = a.root;
    scene.add(this.mesh);

    this.pos = new THREE.Vector3(spawn.x, 0, spawn.z);
    this.vel = new THREE.Vector3();   // horizontal velocity (x,z)
    this.vy = 0;
    this.heading = 0;                 // body yaw
    this.grounded = true;
    this.speed = 0;
    this.phase = 0;                   // walk-cycle phase
    this.bob = 0;                     // vertical bob offset applied in _sync
    this.hp = PLAYER.MAX_HP;
    this.alive = true;
    this.aiming = false;
    this._sync();
  }

  setVisible(v) { this.mesh.visible = v; }

  // dir: desired world-space ground direction (x,z), magnitude 0..1.
  // run/jump are booleans. aimYaw (optional) faces the body toward camera when aiming.
  update(dt, dir, run, jump, city, aimYaw = null) {
    const maxSpeed = run ? PLAYER.RUN : PLAYER.WALK;
    const mag = Math.min(1, Math.hypot(dir.x, dir.z));
    const desired = new THREE.Vector3(dir.x, 0, dir.z);
    if (mag > 1e-3) desired.normalize().multiplyScalar(maxSpeed * mag);

    // accelerate horizontal velocity toward desired
    this.vel.x = damp(this.vel.x, desired.x, 9, dt);
    this.vel.z = damp(this.vel.z, desired.z, 9, dt);

    // gravity + jump
    if (jump && this.grounded) { this.vy = PLAYER.JUMP; this.grounded = false; }
    this.vy -= PLAYER.GRAVITY * dt;

    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;
    this.pos.y += this.vy * dt;
    if (this.pos.y <= 0) { this.pos.y = 0; this.vy = 0; this.grounded = true; }

    // collide against the city
    const res = city.collideCircle(this.pos.x, this.pos.z, PLAYER.RADIUS);
    if (res.hit) {
      // cancel velocity component pushing into the wall
      this.pos.x = res.x; this.pos.z = res.z;
    }

    this.speed = Math.hypot(this.vel.x, this.vel.z);

    // facing: toward movement, or toward camera when aiming
    if (aimYaw !== null) {
      this.heading = dampAngle(this.heading, aimYaw, 18, dt);
    } else if (this.speed > 0.6) {
      const target = Math.atan2(this.vel.x, this.vel.z);
      this.heading = dampAngle(this.heading, target, PLAYER.TURN_LERP, dt);
    }

    this._animate(dt);
    this._sync();
  }

  _animate(dt) {
    const a = this.avatar;
    if (this.grounded) {
      const norm = clamp(this.speed / PLAYER.RUN, 0, 1);
      const rate = 6 + norm * 9;
      this.phase += dt * rate;
      const amp = 0.25 + norm * 0.75;
      const s = Math.sin(this.phase) * amp;
      a.legL.rotation.x = s; a.legR.rotation.x = -s;
      a.armL.rotation.x = -s * 0.85; a.armR.rotation.x = s * 0.85;
      this.bob = Math.abs(Math.sin(this.phase)) * 0.06 * norm; // subtle bob
    } else {
      this.bob = 0;
      // airborne tuck
      a.legL.rotation.x = lerp(a.legL.rotation.x, -0.5, 0.2);
      a.legR.rotation.x = lerp(a.legR.rotation.x, 0.5, 0.2);
      a.armL.rotation.x = lerp(a.armL.rotation.x, -1.6, 0.2);
      a.armR.rotation.x = lerp(a.armR.rotation.x, -1.6, 0.2);
    }
    a.gun.visible = this.aiming;
    if (this.aiming) { a.armR.rotation.x = -1.4; }
  }

  _sync() {
    this.mesh.position.set(this.pos.x, this.pos.y + this.bob, this.pos.z);
    this.mesh.rotation.y = this.heading;
  }

  // world position of the head (for camera target / muzzle origin)
  get head() {
    return new THREE.Vector3(this.pos.x, this.pos.y + this.avatar.height * 0.85, this.pos.z);
  }
}
