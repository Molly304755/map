import * as THREE from 'three';
import { CITY, CAM, COLORS, PLAYER, VEHICLE } from './config.js';
import { City } from './city.js';
import { Player } from './player.js';
import { Vehicle } from './vehicle.js';
import { Crowd } from './npc.js';
import { Effects } from './effects.js';
import { Audio } from './audio.js';
import { Weather } from './weather.js';
import { CameraRig } from './cameraRig.js';
import { HUD } from './hud.js';
import { Dialogue, defaultCast } from './dialogue.js';
import { dampAngle } from './util.js';
import { initInput, input, isDown, axisX, axisY, wasPressed, consumeMouseClick, endFrame } from './input.js';

const canvas = document.getElementById('app');

// ---------- renderer / scene ----------
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;

const scene = new THREE.Scene();
scene.background = new THREE.Color(COLORS.SKY);
scene.fog = new THREE.Fog(0xcddcea, 180, 760);

// gradient sky dome
const sky = new THREE.Mesh(
  new THREE.SphereGeometry(900, 24, 16),
  new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { top: { value: new THREE.Color(0x4a82c4) }, bottom: { value: new THREE.Color(0xd2e2ef) } },
    vertexShader: 'varying vec3 vP; void main(){ vP = position; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
    fragmentShader: 'varying vec3 vP; uniform vec3 top; uniform vec3 bottom; void main(){ float h = normalize(vP).y; float t = smoothstep(-0.05, 0.55, h); gl_FragColor = vec4(mix(bottom, top, t), 1.0); }',
  })
);
sky.frustumCulled = false;
scene.add(sky);

const camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 1400);
camera.position.set(0, 20, 30);

// lighting
const hemi = new THREE.HemisphereLight(0xcfe2f5, 0x6c6a63, 1.25);
scene.add(hemi);
const sun = new THREE.DirectionalLight(COLORS.SUN, 2.3);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.near = 10;
sun.shadow.camera.far = 420;
sun.shadow.camera.left = -90; sun.shadow.camera.right = 90;
sun.shadow.camera.top = 90; sun.shadow.camera.bottom = -90;
sun.shadow.bias = -0.0004;
scene.add(sun);
scene.add(sun.target);
const SUN_OFF = new THREE.Vector3(70, 130, 50);

// ---------- world / actors ----------
const city = new City(scene);
const player = new Player(scene, city.spawn);
player.inCar = null;
const rig = new CameraRig(camera);
const hud = new HUD();
const dialogue = new Dialogue(); defaultCast(dialogue);
initInput(canvas);

// ---------- vehicles (parked + AI traffic) ----------
const cars = [];
for (let i = 0; i < 14; i++) {
  const s = city.laneSpawn();
  if (Math.hypot(s.x - player.pos.x, s.z - player.pos.z) < 16) continue; // not on top of player
  cars.push(new Vehicle(scene, s.x, s.z, s.yaw, 'parked'));
}
for (let i = 0; i < 18; i++) {
  const s = city.laneSpawn();
  cars.push(new Vehicle(scene, s.x, s.z, s.yaw, 'traffic'));
}

// ---------- action systems ----------
const effects = new Effects(scene);
const crowd = new Crowd(scene, city);
const audio = new Audio();
const weather = new Weather(scene);
const hospital = city.spawn.clone();

const state = {
  running: false, money: 0, stars: 0,
  wanted: 0, lastCrime: -999, time: 0,
  dead: false, deadTimer: 0, fireCd: 0, weapon: 0, tod: 0.30,
  armor: 0, armorMax: 100, topSpeedBonus: 0,
  unlocked: new Set([0]),          // weapon indices owned (pistol always)
  shopHold: 0, shopOpen: false, _prevStars: 0,
};
let blips = [];

// objective marker (delivery for cash)
const marker = (() => {
  const g = new THREE.Group();
  const cyl = new THREE.Mesh(
    new THREE.CylinderGeometry(2.4, 2.4, 7, 22, 1, true),
    new THREE.MeshBasicMaterial({ color: 0xffd34e, transparent: true, opacity: 0.32, side: THREE.DoubleSide, depthWrite: false })
  );
  cyl.position.y = 3.5;
  const core = new THREE.Mesh(
    new THREE.CylinderGeometry(0.5, 0.5, 7, 8),
    new THREE.MeshBasicMaterial({ color: 0xffe98a, transparent: true, opacity: 0.6, depthWrite: false })
  );
  core.position.y = 3.5;
  g.add(cyl, core);
  scene.add(g);
  return { group: g, cyl, pos: new THREE.Vector3() };
})();
function placeMarker() {
  let p;
  do { p = city.randomRoadPoint(Math.random); }
  while (Math.hypot(p.x - player.pos.x, p.z - player.pos.z) < 45);
  marker.pos.set(p.x, 0, p.z);
  marker.group.position.set(p.x, 0, p.z);
}
placeMarker();

// ---------- shop (drive/walk in, hold E to open) ----------
const shop = (() => {
  const g = new THREE.Group();
  const ring = new THREE.Mesh(
    new THREE.CylinderGeometry(3.0, 3.0, 8, 26, 1, true),
    new THREE.MeshBasicMaterial({ color: 0x49d6ff, transparent: true, opacity: 0.3, side: THREE.DoubleSide, depthWrite: false })
  );
  ring.position.y = 4;
  const core = new THREE.Mesh(
    new THREE.CylinderGeometry(0.55, 0.55, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0x9fe9ff, transparent: true, opacity: 0.6, depthWrite: false })
  );
  core.position.y = 4;
  g.add(ring, core);
  scene.add(g);
  const p = city.randomRoadPoint(Math.random);
  g.position.set(p.x, 0, p.z);
  return { group: g, ring, pos: new THREE.Vector3(p.x, 0, p.z) };
})();

const SHOP_ITEMS = [
  { id: 'ammo', name: 'Refill ammo', desc: () => `Top up ${WEAPONS[state.weapon].name}`, price: 60,
    avail: () => WEAPONS[state.weapon].ammo !== Infinity,
    apply: () => { WEAPONS[state.weapon].ammo = (AMMO_CAP[state.weapon] ?? WEAPONS[state.weapon].ammo); } },
  { id: 'armor50', name: '+50 Armor', desc: () => `Body armor (max ${state.armorMax})`, price: 120,
    avail: () => state.armor < state.armorMax,
    apply: () => { state.armor = Math.min(state.armorMax, state.armor + 50); } },
  { id: 'heal', name: 'Full health', desc: () => 'Patch up to 100', price: 80,
    avail: () => player.hp < PLAYER.MAX_HP,
    apply: () => { player.hp = PLAYER.MAX_HP; } },
  { id: 'smg', name: 'Unlock SMG', desc: () => 'Automatic · adds ammo', price: 400,
    owned: () => state.unlocked.has(1),
    apply: () => { state.unlocked.add(1); WEAPONS[1].ammo = Math.max(WEAPONS[1].ammo, 250); } },
  { id: 'shotgun', name: 'Unlock Shotgun', desc: () => 'Close-range · adds shells', price: 550,
    owned: () => state.unlocked.has(2),
    apply: () => { state.unlocked.add(2); WEAPONS[2].ammo = Math.max(WEAPONS[2].ammo, 48); } },
  { id: 'speed', name: '+Top speed', desc: () => 'Tune every car you drive', price: 700,
    owned: () => state.topSpeedBonus >= 14,
    apply: () => { state.topSpeedBonus = 14; } },
  { id: 'plate', name: '+Armor plating', desc: () => 'Raise armor cap to 150', price: 650,
    owned: () => state.armorMax >= 150,
    apply: () => { state.armorMax = 150; } },
];

const shopEl = document.getElementById('shop');
const shopList = document.getElementById('shopItems');
const shopMoney = document.getElementById('shopMoney');
function renderShop() {
  if (shopMoney) shopMoney.textContent = Math.round(state.money).toLocaleString('en-US');
  let html = '';
  for (const it of SHOP_ITEMS) {
    const owned = it.owned ? it.owned() : false;
    const avail = it.avail ? it.avail() : true;
    const afford = state.money >= it.price;
    const dis = owned || !avail || !afford;
    const tag = owned ? 'OWNED' : !avail ? '—' : '$' + it.price;
    html += `<button class="shopItem${dis ? ' dis' : ''}" data-id="${it.id}"${dis ? ' disabled' : ''}>` +
      `<span class="si-name">${it.name}</span><span class="si-desc">${it.desc()}</span>` +
      `<span class="si-price${afford || owned ? '' : ' no'}">${tag}</span></button>`;
  }
  shopList.innerHTML = html;
}
function openShop() {
  if (state.shopOpen || state.dead) return;
  state.shopOpen = true;
  document.exitPointerLock?.();
  renderShop();
  shopEl.classList.add('show');
}
function closeShop() {
  if (!state.shopOpen) return;
  state.shopOpen = false;
  shopEl.classList.remove('show');
  if (state.running) canvas.requestPointerLock?.();
}
function buy(id) {
  const it = SHOP_ITEMS.find((x) => x.id === id);
  if (!it) return;
  if (it.owned && it.owned()) return;
  if (it.avail && !it.avail()) return;
  if (state.money < it.price) { hud.toast('Not enough cash', 'busted', 1100); return; }
  state.money -= it.price;
  it.apply();
  hud.toast(`${it.name}  -$${it.price}`, 'good', 1300);
  renderShop();
}
if (shopList) shopList.addEventListener('click', (e) => {
  const b = e.target.closest('.shopItem'); if (b && !b.disabled) buy(b.dataset.id);
});
if (shopEl) shopEl.addEventListener('click', (e) => { if (e.target === shopEl) closeShop(); });
window.addEventListener('keydown', (e) => { if (state.shopOpen && (e.code === 'Escape' || e.code === 'KeyE')) closeShop(); });

function updateShop(dt) {
  shop.ring.rotation.y += dt * 0.9;
  const d = Math.hypot(player.pos.x - shop.pos.x, player.pos.z - shop.pos.z);
  const inRange = d < 7 && !state.dead;
  if (state.shopOpen) { hud.prompt(null); return; }
  if (inRange) {
    if (isDown('KeyE')) {
      state.shopHold += dt;
      if (state.shopHold >= 0.5) { state.shopHold = 0; openShop(); }
      hud.prompt('Keep holding <b>E</b> to shop…');
    } else {
      state.shopHold = 0;
      hud.prompt('Hold <b>E</b> to shop');
    }
  } else if (state.shopHold > 0) {
    state.shopHold = 0;
  }
}

// ---------- pickups (ammo / health crates) ----------
const PICKUP_TYPES = {
  smg:     { color: 0x6fd0ff, label: '+90 SMG ammo',      give: () => { WEAPONS[1].ammo += 90; } },
  shotgun: { color: 0xffa23a, label: '+20 shotgun shells', give: () => { WEAPONS[2].ammo += 20; } },
  health:  { color: 0x4dff7a, label: '+30 health',         give: () => { player.hp = Math.min(PLAYER.MAX_HP, player.hp + 30); } },
};
const pickups = [];
function spawnPickup(type, p) {
  const def = PICKUP_TYPES[type];
  const mesh = new THREE.Mesh(
    new THREE.OctahedronGeometry(1.1, 0),
    new THREE.MeshStandardMaterial({ color: def.color, emissive: def.color, emissiveIntensity: 0.55, roughness: 0.3, metalness: 0.3 })
  );
  mesh.castShadow = true;
  mesh.position.set(p.x, 1.6, p.z);
  scene.add(mesh);
  pickups.push({ type, mesh, pos: new THREE.Vector3(p.x, 0, p.z), cooldown: 0 });
}
['health', 'smg', 'shotgun', 'health', 'smg', 'shotgun', 'health', 'smg'].forEach((t) => spawnPickup(t, city.randomRoadPoint(Math.random)));
function updatePickups(dt) {
  for (const pk of pickups) {
    pk.mesh.rotation.y += dt * 1.6;
    if (pk.cooldown > 0) { pk.cooldown -= dt; pk.mesh.visible = false; continue; }
    pk.mesh.visible = true;
    pk.mesh.position.y = 1.6 + Math.sin(state.time * 2 + pk.pos.x) * 0.22;
    const dx = player.pos.x - pk.pos.x, dz = player.pos.z - pk.pos.z;
    if (dx * dx + dz * dz < 3 * 3 && !state.dead) {
      PICKUP_TYPES[pk.type].give();
      hud.toast(PICKUP_TYPES[pk.type].label, 'good', 1300);
      pk.cooldown = 12;                            // respawn elsewhere after a beat
      const np = city.randomRoadPoint(Math.random);
      pk.pos.set(np.x, 0, np.z);
      pk.mesh.position.set(np.x, 1.6, np.z);
    }
  }
}

// ---------- start screen ----------
const startEl = document.getElementById('start');
const playBtn = document.getElementById('playBtn');
function beginGame() {
  if (state.running) return;
  state.running = true;
  startEl.classList.add('hidden');
  audio.resume();
  dialogue.resume();
  dialogue.say('WREN', 'Welcome to Liberty, Kid. Find a job marker and earn your keep.', { interrupt: true });
  canvas.requestPointerLock?.();
}
playBtn.addEventListener('click', beginGame);

// ---------- resize (robust: track the canvas' real display size every frame) ----------
function resizeToDisplay() {
  const c = renderer.domElement;
  const w = c.clientWidth || window.innerWidth || 1280;
  const h = c.clientHeight || window.innerHeight || 720;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const nw = Math.floor(w * dpr), nh = Math.floor(h * dpr);
  if (c.width !== nw || c.height !== nh) {
    renderer.setPixelRatio(dpr);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
}
window.addEventListener('resize', resizeToDisplay);
resizeToDisplay();

// ---------- loop ----------
const tmpF = new THREE.Vector3(), tmpR = new THREE.Vector3(), dir = new THREE.Vector3();
const camTarget = new THREE.Vector3();
let last = performance.now();
let loopPaused = false;          // lets headless verification freeze the loop for a clean capture

function frame(now) {
  let dt = (now - last) / 1000;
  last = now;
  if (dt > 0.05) dt = 0.05;     // clamp big hitches
  if (!loopPaused) tickOnce(dt);
  requestAnimationFrame(frame);
}

// One simulation+render step. Exposed so it can be driven manually (e.g. for
// headless verification where requestAnimationFrame is paused on a hidden tab).
function tickOnce(dt) {
  resizeToDisplay();
  if (state.running) update(dt);

  // keep the sun + its shadow frustum centred on the player
  sun.position.copy(player.pos).add(SUN_OFF);
  sun.target.position.copy(player.pos);
  sun.target.updateMatrixWorld();

  renderer.render(scene, camera);
  hud.tick(dt);
  dialogue.tick(dt);
  hud.drawMinimap(city, player, blips);
  endFrame();
}

function update(dt) {
  state.time += dt;

  if (state.dead) {
    state.deadTimer -= dt;
    camTarget.set(player.pos.x, player.pos.y + CAM.HEIGHT_AIM, player.pos.z);
    rig.update(dt, camTarget, city);
    if (state.deadTimer <= 0) doRespawn();
  } else {
    handleEnterExit();
    handleWeaponSwitch();
    if (player.inCar) updateDriving(dt);
    else updateOnFoot(dt);
    tryShoot(dt);
  }

  // --- world systems (always run) ---
  for (const c of cars) {
    if (c.kind === 'traffic' && c.driver !== 'player') c.updateAI(dt, city);
  }
  maintainPolice(dt);
  updatePolice(dt);
  const kills = crowd.update(dt, player, cars, player.inCar, effects);
  if (kills > 0) addWanted(0.8 * kills);
  effects.update(dt);
  updateMission(dt);
  updatePickups(dt);
  updateShop(dt);
  updateDayNight(dt);
  weather.update(dt, player, sun, hemi, scene.fog);
  if (cars.some((c) => c.kind === 'police')) audio.sirenOn(); else audio.sirenOff();

  // wanted decay after a cooldown with no crimes
  if (state.time - state.lastCrime > 7 && state.wanted > 0) {
    state.wanted = Math.max(0, state.wanted - 0.12 * dt);
  }
  state.stars = Math.floor(state.wanted);

  // survive-the-heat payout: pay per peak star when the last star clears via decay
  if (state._prevStars > 0 && state.stars === 0 && !state.dead) {
    const bonus = state._prevStars * 40;
    state.money += bonus;
    hud.toast(`+$${bonus}  shook the cops`, 'good', 1500);
  }
  state._prevStars = state.stars;

  hud.setHealth(player.hp);
  hud.setArmor(state.armor, state.armorMax);
  hud.setMoney(state.money);
  hud.setStars(state.stars);
  hud.setWeapon(WEAPONS[state.weapon].name, WEAPONS[state.weapon].ammo);

  // minimap blips
  blips.length = 0;
  for (const c of cars) {
    blips.push({
      x: c.pos.x, z: c.pos.z, r: 3.2,
      color: c === player.inCar ? '#ffd34e'
        : c.kind === 'police' ? '#ff4d4d'
        : c.kind === 'traffic' ? '#79a8ff' : '#aab0ba',
    });
  }
  for (const p of crowd.list()) if (!p.dead) blips.push({ x: p.pos.x, z: p.pos.z, r: 1.4, color: '#cfd2dd' });
  if (!job.active) blips.push({ x: marker.pos.x, z: marker.pos.z, r: 4.5, color: '#ffe34e' });
  if (job.blip) blips.push({ x: job.blip.x, z: job.blip.z, r: 4.5, color: '#ff5ad6' });
  blips.push({ x: shop.pos.x, z: shop.pos.z, r: 4.5, color: '#49d6ff' });
  for (const pk of pickups) if (pk.mesh.visible) blips.push({ x: pk.pos.x, z: pk.pos.z, r: 2.2, color: '#8effb0' });
}

// ---------- combat / weapons ----------
const _camDir = new THREE.Vector3();
const WEAPONS = [
  { name: 'PISTOL',  fireCd: 0.22,  dmgCop: 34, dmgPed: 100, spread: 0.006, pellets: 1, auto: false, ammo: Infinity, range: 150 },
  { name: 'SMG',     fireCd: 0.075, dmgCop: 19, dmgPed: 34,  spread: 0.028, pellets: 1, auto: true,  ammo: 250,      range: 130 },
  { name: 'SHOTGUN', fireCd: 0.72,  dmgCop: 22, dmgPed: 24,  spread: 0.07,  pellets: 8, auto: false, ammo: 48,       range: 70 },
];
const AMMO_CAP = [Infinity, 250, 48];   // shop 'Refill ammo' tops the current weapon to these

function handleWeaponSwitch() {
  if (wasPressed('Digit1') && state.unlocked.has(0)) state.weapon = 0;
  else if (wasPressed('Digit2') && state.unlocked.has(1)) state.weapon = 1;
  else if (wasPressed('Digit3') && state.unlocked.has(2)) state.weapon = 2;
}

function tryShoot(dt) {
  state.fireCd -= dt;
  const w = WEAPONS[state.weapon];
  const click = consumeMouseClick();           // edge for semi-auto weapons
  if (player.inCar || state.fireCd > 0) return;
  const wantFire = w.auto ? input.mouseDown : click;
  if (!wantFire) return;
  if (w.ammo <= 0) { state.weapon = 0; return; } // out of ammo -> back to pistol
  state.fireCd = w.fireCd;
  if (w.ammo !== Infinity) w.ammo--;
  fireOnce(w);
}

function fireOnce(w) {
  camera.getWorldDirection(_camDir);
  const origin = player.head;
  effects.muzzle(origin.clone().addScaledVector(_camDir, 1.3));
  audio.gunshot();
  let hitAny = false, pedKill = false, copKill = false;
  for (let i = 0; i < w.pellets; i++) {
    const d = _camDir.clone();
    if (w.spread > 0) {
      d.x += (Math.random() - 0.5) * w.spread * 2;
      d.y += (Math.random() - 0.5) * w.spread * 2;
      d.z += (Math.random() - 0.5) * w.spread * 2;
      d.normalize();
    }
    const muzzle = origin.clone().addScaledVector(d, 1.3);
    effects.tracer(muzzle, origin.clone().addScaledVector(d, w.range));
    const hit = raycastTargets(origin, d, w.range);
    if (!hit) continue;
    hitAny = true;
    if (hit.type === 'ped') { if (hit.obj.hurt(w.dmgPed, origin.x, origin.z)) pedKill = true; effects.bloodAt(hit.obj.pos); }
    else if (hit.type === 'mission') { hit.obj.hp -= w.dmgCop; effects.burst(hit.point, 0xffaa33, 6, { spread: 4 }); }
    else if (hit.type === 'police') {
      hit.obj.hp -= w.dmgCop; effects.burst(hit.point, 0xffaa33, 6, { spread: 4 });
      if (hit.obj.hp <= 0) { destroyPolice(hit.obj); copKill = true; }
    }
  }
  if (copKill) addWanted(1.2);
  else if (pedKill) addWanted(1.1);
  else if (hitAny) addWanted(0.5);
  else addWanted(0.05);
  rig.addShake(0.045);          // gun kick
  crowd.alarm(origin, 35);
}

const _tmpC = new THREE.Vector3();
function raycastTargets(o, d, maxDist) {
  let best = null, bestT = maxDist;
  const test = (cx, cy, cz, radius, type, obj) => {
    const ox = cx - o.x, oy = cy - o.y, oz = cz - o.z;
    const tca = ox * d.x + oy * d.y + oz * d.z;
    if (tca < 0) return;
    const d2 = ox * ox + oy * oy + oz * oz - tca * tca;
    const r2 = radius * radius;
    if (d2 > r2) return;
    const t = tca - Math.sqrt(r2 - d2);
    if (t > 0 && t < bestT) { bestT = t; best = { type, obj, point: o.clone().addScaledVector(d, t) }; }
  };
  for (const p of crowd.list()) { if (!p.dead) test(p.pos.x, 1.7, p.pos.z, 1.3, 'ped', p); }
  for (const c of cars) { if (c.kind === 'police') test(c.pos.x, 1.7, c.pos.z, 2.7, 'police', c); }
  for (const c of cars) { if (c.mission) test(c.pos.x, 1.7, c.pos.z, 2.7, 'mission', c); }
  return best;
}

// ---------- police / wanted ----------
function addWanted(n) { state.wanted = Math.min(5, state.wanted + n); state.lastCrime = state.time; }

function maintainPolice(dt) {
  const want = state.stars > 0 ? Math.min(6, state.stars + 1) : 0;
  const police = cars.filter((c) => c.kind === 'police');
  if (want === 0) { if (police.length) removeAllPolice(); return; }
  if (police.length < want) {
    for (let tries = 0; tries < 10; tries++) {
      const s = city.laneSpawn();
      const d = Math.hypot(s.x - player.pos.x, s.z - player.pos.z);
      if (d > 55 && d < 170) {
        const v = new Vehicle(scene, s.x, s.z, s.yaw, 'police', 0x15171c);
        v.driver = 'ai'; v.hp = 120;
        cars.push(v);
        break;
      }
    }
  }
}

function updatePolice(dt) {
  for (const c of cars) {
    if (c.kind !== 'police') continue;
    c.updateChase(dt, player.pos, city);
    if (state.dead) continue;
    const dist = Math.hypot(player.pos.x - c.pos.x, player.pos.z - c.pos.z);
    if (!player.inCar && dist < 4.2) damagePlayer(11 * dt); // ramming on foot
    c._shootCd = (c._shootCd ?? Math.random()) - dt;
    if (dist < 46 && c._shootCd <= 0) {
      c._shootCd = 1.0 + Math.random() * 0.9;
      effects.tracer(_tmpC.set(c.pos.x, 2.3, c.pos.z), player.head);
      // scale lethality with heat: survivable at 1★, deadly at 5★
      const heat = Math.max(0.6, Math.min(1.6, state.stars / 3));
      if (Math.random() < 0.55) damagePlayer((player.inCar ? 2 : 4) * heat);
    }
    // police lost interest if very far for long
    if (dist > 230) { c.dispose(scene); const i = cars.indexOf(c); if (i >= 0) cars.splice(i, 1); }
  }
}

function destroyPolice(c) {
  const p = _tmpC.set(c.pos.x, 1.6, c.pos.z);
  effects.burst(p, 0xffa033, 30, { spread: 13, up: 13, life: 1.0, size: 1.5 });
  effects.burst(p, 0x2b2b2b, 18, { spread: 9, up: 9, life: 1.4, size: 1.6, grav: 6 });
  rig.addShake(1.1);            // explosion kick
  c.dispose(scene);
  const i = cars.indexOf(c); if (i >= 0) cars.splice(i, 1);
}

function removeAllPolice() {
  for (let i = cars.length - 1; i >= 0; i--) {
    if (cars[i].kind === 'police') { cars[i].dispose(scene); cars.splice(i, 1); }
  }
}

// ---------- health / death ----------
function damagePlayer(n) {
  if (state.dead) return;
  if (state.armor > 0) {                 // armor soaks first, then health
    const soak = Math.min(state.armor, n);
    state.armor -= soak;
    n -= soak;
  }
  if (n > 0) player.hp -= n;
  if (n >= 1) rig.addShake(Math.min(0.7, 0.1 + n / 40));   // hit shake
  hud.hurt(Math.min(0.85, 0.15 + n / 30));
  if (player.hp <= 0) { player.hp = 0; wasted(); }
}
function wasted() {
  state.dead = true;
  state.deadTimer = 3.0;
  hud.toast('WASTED', 'wasted', 2800);
  dialogue.say('CIVIC SHIELD', 'Suspect is down. Wrap it up.', { interrupt: true });
  hud.prompt(null);
  hud.speed(null);
}
function doRespawn() {
  state.dead = false;
  player.hp = PLAYER.MAX_HP;
  state.armor = 0;
  state.wanted = 0; state.stars = 0; state._prevStars = 0;
  if (state.shopOpen) closeShop();
  removeAllPolice();
  if (job.active) endJob('fail');
  if (player.inCar) { player.inCar.driver = null; player.inCar = null; player.setVisible(true); }
  audio.engineOff();
  player.pos.copy(hospital); player.vy = 0; player.grounded = true;
  player.vel.set(0, 0, 0);
  state.money = Math.max(0, state.money - 100);
  hud.toast('-$100 hospital bill', 'busted', 1600);
}

// ---------- mission system (data-driven jobs) ----------
// The yellow marker is the JOB start. Stepping into it begins a random mission
// from MISSIONS. Each def: start() sets up actors; update(dt) -> 'active' |
// 'done' | 'fail'; cleanup() tears down. updateMission drives the active job.
const job = { active: null, def: null, t: 0, blip: null, payout: 0 };

function distXZ(ax, az, bx, bz) { return Math.hypot(ax - bx, az - bz); }
function playerNear(x, z, r) { return !state.dead && distXZ(player.pos.x, player.pos.z, x, z) < r; }
function roadAwayFromPlayer(minD = 60, maxTries = 24) {
  let p;
  for (let i = 0; i < maxTries; i++) { p = city.randomRoadPoint(Math.random); if (distXZ(p.x, p.z, player.pos.x, player.pos.z) > minD) return p; }
  return p;
}
function spawnMissionCar(minD = 70) {
  let s = null;
  for (let i = 0; i < 16; i++) { const c = city.laneSpawn(); if (distXZ(c.x, c.z, player.pos.x, player.pos.z) > minD) { s = c; break; } }
  if (!s) s = city.laneSpawn();
  const v = new Vehicle(scene, s.x, s.z, s.yaw, 'mission', 0xd24bff);
  v.driver = 'ai'; v.hp = 100; v.mission = true;
  cars.push(v);
  return v;
}
function removeMissionCar(v) { if (!v) return; v.dispose(scene); const i = cars.indexOf(v); if (i >= 0) cars.splice(i, 1); }
// drive a fleeing car away from a point along open roads (CHASE/ELIMINATE)
function fleeStep(dt, v, fromX, fromZ) {
  const away = Math.atan2(v.pos.x - fromX, v.pos.z - fromZ);
  v.forward(v._fwd);
  const ahead = 8, ax = v.pos.x + v._fwd.x * ahead, az = v.pos.z + v._fwd.z * ahead;
  if (city.pointInBuilding(ax, az) || Math.abs(ax) > city.HALF - 6 || Math.abs(az) > city.HALF - 6) v._pickCardinal(city, true);
  const err = ((away - v.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
  v.step(dt, 1, Math.max(-1, Math.min(1, err * 1.4)), false, city, true);
}

const MISSIONS = [
  { name: 'DELIVER', pay: [220, 360], limit: 55, start(c) {
      const p = roadAwayFromPlayer(70); c.dropoff = new THREE.Vector3(p.x, 0, p.z); c.blipAt = c.dropoff;
    },
    update(dt, c) {
      const d = distXZ(player.pos.x, player.pos.z, c.dropoff.x, c.dropoff.z);
      hud.setMission(`DELIVER: reach the dropoff — ${Math.round(d)} m · ${Math.ceil(job.t)}s`);
      if (job.t <= 0) return 'fail';
      if (d < 6) return 'done';
      return 'active';
    }, cleanup() {} },

  { name: 'CHASE', pay: [320, 520], limit: 50, start(c) {
      c.car = spawnMissionCar(60); c.blipAt = c.car.pos;
    },
    update(dt, c) {
      if (!c.car) return 'fail';
      fleeStep(dt, c.car, player.pos.x, player.pos.z);
      const d = distXZ(player.pos.x, player.pos.z, c.car.pos.x, c.car.pos.z);
      hud.setMission(`CHASE: catch the runner — ${Math.round(d)} m · ${Math.ceil(job.t)}s`);
      if (job.t <= 0) return 'fail';
      if (d > 230) return 'fail';
      if (player.inCar && d < 6) return 'done';
      return 'active';
    }, cleanup(c) { removeMissionCar(c.car); c.car = null; } },

  { name: 'EVADE', pay: [300, 480], limit: 30, start(c) {
      c.need = 2; c.armed = false; c.surv = c.limit; c.blipAt = null;
      if (state.stars < c.need) addWanted(c.need + 0.4 - state.wanted);
    },
    update(dt, c) {
      if (state.dead) return 'fail';
      if (!c.armed) {
        hud.setMission(`EVADE: reach ${c.need}★ heat to start the clock (now ${state.stars}★)`);
        if (state.stars >= c.need) c.armed = true;
        return 'active';
      }
      c.surv -= dt;
      hud.setMission(`EVADE: stay wanted & alive — ${Math.ceil(c.surv)}s (${state.stars}★)`);
      if (state.stars < 1) return 'fail';
      if (c.surv <= 0) return 'done';
      return 'active';
    }, cleanup() {} },

  { name: 'COLLECT', pay: [260, 420], limit: 55, start(c) {
      c.k = 5; c.got = 0; c.crates = [];
      for (let i = 0; i < c.k; i++) {
        const p = roadAwayFromPlayer(35);
        const m = new THREE.Mesh(
          new THREE.BoxGeometry(1.3, 1.3, 1.3),
          new THREE.MeshStandardMaterial({ color: 0xffd34e, emissive: 0xffb000, emissiveIntensity: 0.5, roughness: 0.4 })
        );
        m.castShadow = true; m.position.set(p.x, 1.2, p.z); scene.add(m);
        c.crates.push({ mesh: m, x: p.x, z: p.z, taken: false });
      }
      c.blipAt = null;
    },
    update(dt, c) {
      for (const cr of c.crates) {
        if (cr.taken) continue;
        cr.mesh.rotation.y += dt * 1.8;
        cr.mesh.position.y = 1.2 + Math.sin(state.time * 2 + cr.x) * 0.2;
        if (playerNear(cr.x, cr.z, 3.2)) { cr.taken = true; cr.mesh.visible = false; c.got++; hud.toast(`cargo ${c.got}/${c.k}`, 'good', 900); }
      }
      const cur = c.crates.find((x) => !x.taken);
      c.blipAt = cur ? cur.mesh.position : null;
      hud.setMission(`COLLECT: gather cargo ${c.got}/${c.k} · ${Math.ceil(job.t)}s`);
      if (job.t <= 0) return 'fail';
      if (c.got >= c.k) return 'done';
      return 'active';
    }, cleanup(c) { for (const cr of c.crates) scene.remove(cr.mesh); c.crates = []; } },

  { name: 'ELIMINATE', pay: [380, 600], limit: 60, start(c) {
      c.car = spawnMissionCar(60); c.car.hp = 130; c.blipAt = c.car.pos;
    },
    update(dt, c) {
      if (!c.car) return 'fail';
      fleeStep(dt, c.car, player.pos.x, player.pos.z);
      if (c.car.hp <= 0) {
        effects.burst(_tmpC.set(c.car.pos.x, 1.6, c.car.pos.z), 0xffa033, 30, { spread: 13, up: 13, life: 1.0, size: 1.5 });
        effects.burst(_tmpC.set(c.car.pos.x, 1.6, c.car.pos.z), 0x2b2b2b, 18, { spread: 9, up: 9, life: 1.4, size: 1.6, grav: 6 });
        removeMissionCar(c.car); c.car = null; return 'done';
      }
      const d = distXZ(player.pos.x, player.pos.z, c.car.pos.x, c.car.pos.z);
      hud.setMission(`ELIMINATE: destroy the target (${Math.max(0, Math.round(c.car.hp))} hp) — ${Math.round(d)} m · ${Math.ceil(job.t)}s`);
      if (job.t <= 0) return 'fail';
      return 'active';
    }, cleanup(c) { removeMissionCar(c.car); c.car = null; } },
];

function startRandomJob() {
  const def = MISSIONS[Math.floor(Math.random() * MISSIONS.length)];
  const ctx = { limit: def.limit, blipAt: null };
  job.def = def; job.active = ctx; job.t = def.limit;
  job.payout = Math.round(def.pay[0] + Math.random() * (def.pay[1] - def.pay[0]));
  def.start(ctx);
  hud.toast(`JOB: ${def.name}  (+$${job.payout})`, 'good', 1700);
  dialogue.say('TIO', { DELIVER: 'Package run. Do not keep them waiting.', CHASE: 'Runner on the move. Catch them!', EVADE: 'Heat is coming. Stay alive and lose the cops.', COLLECT: 'Grab the cargo before it walks.', ELIMINATE: 'Target needs to vanish. You up for it?' }[def.name] || 'Got work. Move.', { interrupt: true });
  marker.group.visible = false;
}
function endJob(result) {
  const def = job.def, ctx = job.active;
  if (def && def.cleanup) def.cleanup(ctx);
  if (result === 'done') { state.money += job.payout; hud.toast(`+$${job.payout}  ${def.name} complete`, 'good', 1800); dialogue.say('WREN', 'Clean work. Cash is in your account.', { interrupt: true }); }
  else { hud.toast(`${def ? def.name : 'JOB'} failed`, 'busted', 1700); dialogue.say('WREN', 'Job is blown. Shake it off and try again.', { interrupt: true }); }
  job.def = null; job.active = null; job.blip = null;
  marker.group.visible = true;
  placeMarker();
}

function updateMission(dt) {
  marker.cyl.rotation.y += dt * 1.1;
  job.blip = null;

  if (!job.active) {
    const d = distXZ(player.pos.x, player.pos.z, marker.pos.x, marker.pos.z);
    hud.setMission(`Reach the JOB marker to start work — ${Math.round(d)} m`);
    if (d < 6 && !state.dead) startRandomJob();
    return;
  }

  job.t -= dt;
  let res = 'active';
  try { res = job.def.update(dt, job.active); } catch (e) { res = 'fail'; }
  const b = job.active && job.active.blipAt;
  if (b) job.blip = { x: b.x, z: b.z };
  if (res === 'done') endJob('done');
  else if (res === 'fail') endJob('fail');
}

// ---------- day / night cycle ----------
const _c1 = new THREE.Color(), _c2 = new THREE.Color(), _c3 = new THREE.Color();
const DAY = { skyTop: 0x4a82c4, skyBot: 0xd2e2ef, bg: 0x9fc7e8, fog: 0xcddcea };
const NIGHT = { skyTop: 0x070b16, skyBot: 0x12203a, bg: 0x0a1020, fog: 0x0b1424 };
const SUN_DAY = 0xfff3d6, SUN_DUSK = 0xff8a4a;
function updateDayNight(dt) {
  state.tod = (state.tod + dt / 210) % 1;              // ~3.5 min full day
  const ang = (state.tod - 0.25) * Math.PI * 2;
  const elev = Math.sin(ang);                           // -1 midnight … +1 noon
  const day = Math.max(0, elev);
  const horizon = 1 - Math.min(1, Math.abs(elev) * 3);  // 1 near sunrise/sunset
  const t = Math.min(1, day * 1.4);

  SUN_OFF.set(80, 30 + elev * 175, 95);                 // sun rides up/down the sky
  sun.intensity = 0.05 + day * 2.4;
  sun.color.copy(_c1.set(SUN_DAY).lerp(_c2.set(SUN_DUSK), horizon * 0.85));
  hemi.intensity = 0.3 + day * 1.05;

  scene.background.copy(_c1.set(NIGHT.bg).lerp(_c2.set(DAY.bg), t));
  scene.fog.color.copy(_c1.set(NIGHT.fog).lerp(_c2.set(DAY.fog), t));
  const u = sky.material && sky.material.uniforms;
  if (u && u.top && u.bottom) {
    u.top.value.copy(_c1.set(NIGHT.skyTop).lerp(_c2.set(DAY.skyTop), t));
    u.bottom.value.copy(_c1.set(NIGHT.skyBot).lerp(_c2.set(DAY.skyBot), t)).lerp(_c3.set(SUN_DUSK), horizon * 0.45);
  }
}

function updateOnFoot(dt) {
  rig.forwardFlat(tmpF);
  rig.rightFlat(tmpR);
  const ax = axisX(), ay = axisY();
  dir.set(tmpF.x * ay + tmpR.x * ax, 0, tmpF.z * ay + tmpR.z * ax);

  const run = isDown('ShiftLeft') || isDown('ShiftRight');
  const jump = wasPressed('Space');
  player.aiming = input.mouseDown;
  const aimYaw = player.aiming ? rig.yaw : null;

  player.update(dt, dir, run, jump, city, aimYaw);

  camTarget.set(player.pos.x, player.pos.y + CAM.HEIGHT_AIM, player.pos.z);
  rig.update(dt, camTarget, city);
  hud.speed(null);

  // "enter vehicle" prompt
  let near = false;
  for (const c of cars) {
    if (c.driver) continue;
    const dx = c.pos.x - player.pos.x, dz = c.pos.z - player.pos.z;
    if (dx * dx + dz * dz < 7 * 7) { near = true; break; }
  }
  hud.prompt(near ? 'Press <b>F</b> to enter vehicle' : null);
}

function updateDriving(dt) {
  const car = player.inCar;
  const throttle = axisY(), steer = axisX();
  const boost = isDown('ShiftLeft') || isDown('ShiftRight');
  const handbrake = isDown('Space');
  car.maxSpeedBonus = state.topSpeedBonus;   // +Top speed upgrade
  car.step(dt, throttle, steer, handbrake, city, boost);

  // tire marks + smoke while the car is sliding
  if (car.slip > 7 && Math.abs(car.speed) > 5) {
    const fx = Math.sin(car.yaw), fz = Math.cos(car.yaw);
    const rx = Math.cos(car.yaw), rz = -Math.sin(car.yaw);
    const rear = -VEHICLE.LENGTH * 0.32, strength = Math.min(1, car.slip / 25);
    for (const side of [-1, 1]) {
      effects.skid(car.pos.x + fx * rear + rx * side * (VEHICLE.WIDTH / 2),
                   car.pos.z + fz * rear + rz * side * (VEHICLE.WIDTH / 2), car.yaw, strength);
    }
    if (Math.random() < 0.4) effects.smoke(car.pos.x + fx * rear, car.pos.z + fz * rear);
  }

  player.pos.copy(car.pos);                 // keep player + shadow frustum on the car
  // camera trails behind the car but still allows free mouse-look
  rig.yaw = dampAngle(rig.yaw, car.yaw, 2.4, dt);
  camTarget.set(car.pos.x, car.pos.y + 3.4, car.pos.z);
  rig.update(dt, camTarget, city, 17);

  hud.speed(Math.round(Math.abs(car.speed) * 3.6));
  hud.prompt('Press <b>F</b> to exit');
  audio.engineUpdate(Math.abs(car.speed) / VEHICLE.MAX_SPEED);
}

function handleEnterExit() {
  if (!wasPressed('KeyF')) return;
  if (player.inCar) {
    const car = player.inCar;
    car.driver = null;
    player.inCar = null;
    const leftX = -Math.cos(car.yaw), leftZ = Math.sin(car.yaw);
    let ex = car.pos.x + leftX * (VEHICLE.WIDTH / 2 + 1.8);
    let ez = car.pos.z + leftZ * (VEHICLE.WIDTH / 2 + 1.8);
    const res = city.collideCircle(ex, ez, PLAYER.RADIUS);
    player.pos.set(res.x, 0, res.z);
    player.vy = 0; player.grounded = true;
    player.setVisible(true);
    audio.engineOff();
  } else {
    let best = null, bd = 7 * 7;
    for (const c of cars) {
      if (c.driver) continue;
      const dx = c.pos.x - player.pos.x, dz = c.pos.z - player.pos.z;
      const d = dx * dx + dz * dz;
      if (d < bd) { bd = d; best = c; }
    }
    if (best) {
      player.inCar = best;
      best.driver = 'player';
      player.setVisible(false);
      player.pos.copy(best.pos);
      audio.engineOn();
    }
  }
}

requestAnimationFrame(frame);

// expose for debugging / verification
window.__game = { THREE, scene, camera, renderer, city, player, cars, crowd, effects, marker, rig, hud, state, input,
  beginGame, tickOnce, resizeToDisplay, addWanted, damagePlayer, pickups, job, shop, SHOP_ITEMS, openShop, closeShop, buy, get MISSIONS() { return MISSIONS; },
  weather,
  dialogue,
  setLoopPaused: (v) => { loopPaused = v; } };
