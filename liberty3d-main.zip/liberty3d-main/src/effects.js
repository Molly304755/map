import * as THREE from 'three';

// Pooled particle / tracer / decal effects. Everything is pre-allocated so we
// never thrash the GC mid-game.
export class Effects {
  constructor(scene) {
    this.scene = scene;

    // --- particle cubes ---
    this.pGeo = new THREE.BoxGeometry(0.28, 0.28, 0.28);
    this.particles = [];
    for (let i = 0; i < 220; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const m = new THREE.Mesh(this.pGeo, mat);
      m.visible = false;
      scene.add(m);
      this.particles.push({ mesh: m, vel: new THREE.Vector3(), life: 0, max: 1, grav: 38 });
    }

    // --- tracers (thin stretched boxes) ---
    this.tGeo = new THREE.BoxGeometry(0.07, 0.07, 1);
    this.tracers = [];
    for (let i = 0; i < 24; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0xfff1a8, transparent: true, opacity: 0 });
      const m = new THREE.Mesh(this.tGeo, mat);
      m.visible = false;
      scene.add(m);
      this.tracers.push({ mesh: m, life: 0 });
    }

    // --- ground decals (blood) ---
    this.dGeo = new THREE.CircleGeometry(0.9, 10);
    this.dGeo.rotateX(-Math.PI / 2);
    this.decals = [];
    this.decalIdx = 0;
    for (let i = 0; i < 48; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0x6b0d0d, transparent: true, opacity: 0, depthWrite: false });
      const m = new THREE.Mesh(this.dGeo, mat);
      m.visible = false;
      m.renderOrder = 1;
      scene.add(m);
      this.decals.push(m);
    }

    // --- skid marks (dark tire streaks laid down while drifting) ---
    this.sGeo = new THREE.PlaneGeometry(0.55, 1.7);
    this.sGeo.rotateX(-Math.PI / 2);
    this.skids = [];
    this.skidIdx = 0;
    for (let i = 0; i < 220; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: 0x0a0a0c, transparent: true, opacity: 0, depthWrite: false });
      const m = new THREE.Mesh(this.sGeo, mat);
      m.visible = false; m.renderOrder = 1;
      scene.add(m);
      this.skids.push(m);
    }
  }

  _freeParticle() {
    for (const p of this.particles) if (p.life <= 0) return p;
    return null;
  }

  burst(pos, color, count = 10, opts = {}) {
    const spread = opts.spread ?? 7;
    const up = opts.up ?? 6;
    const size = opts.size ?? 1;
    const life = opts.life ?? 0.7;
    for (let i = 0; i < count; i++) {
      const p = this._freeParticle();
      if (!p) break;
      p.mesh.visible = true;
      p.mesh.material.color.setHex(color);
      p.mesh.scale.setScalar(size);
      p.mesh.position.copy(pos);
      p.vel.set((Math.random() * 2 - 1) * spread, Math.random() * up + 1, (Math.random() * 2 - 1) * spread);
      p.life = p.max = life * (0.7 + Math.random() * 0.6);
      p.grav = opts.grav ?? 38;
    }
  }

  // muzzle flash: a few bright sparks, no gravity
  muzzle(pos) {
    this.burst(pos, 0xffe089, 6, { spread: 3, up: 3, size: 0.7, life: 0.12, grav: 0 });
  }

  bloodAt(pos) {
    this.burst(pos, 0xaa1414, 14, { spread: 6, up: 7, size: 1, life: 0.8 });
    // splat a decal on the ground beneath
    const m = this.decals[this.decalIdx];
    this.decalIdx = (this.decalIdx + 1) % this.decals.length;
    m.visible = true;
    m.position.set(pos.x, 0.03, pos.z);
    m.scale.setScalar(0.6 + Math.random() * 0.8);
    m.material.opacity = 0.85;
    m.rotation.y = Math.random() * Math.PI;
  }

  // a single tire streak on the ground, oriented to travel direction
  skid(x, z, yaw, strength = 1) {
    const m = this.skids[this.skidIdx];
    this.skidIdx = (this.skidIdx + 1) % this.skids.length;
    m.visible = true;
    m.position.set(x, 0.04, z);
    m.rotation.y = yaw;
    m.material.opacity = Math.min(0.55, 0.25 + strength * 0.3);
  }

  // light tire-smoke puff
  smoke(x, z) {
    this.burst({ x, y: 0.6, z }, 0xc2c2c2, 2, { spread: 1.4, up: 1.4, size: 1.1, life: 0.55, grav: -3 });
  }

  tracer(from, to) {
    let t = this.tracers.find((x) => x.life <= 0) || this.tracers[0];
    const m = t.mesh;
    m.visible = true;
    const mid = from.clone().add(to).multiplyScalar(0.5);
    const len = from.distanceTo(to);
    m.position.copy(mid);
    m.scale.set(1, 1, Math.max(0.1, len));
    m.lookAt(to);
    m.material.opacity = 0.9;
    t.life = 0.06;
  }

  update(dt) {
    for (const p of this.particles) {
      if (p.life <= 0) continue;
      p.life -= dt;
      if (p.life <= 0) { p.mesh.visible = false; continue; }
      p.vel.y -= p.grav * dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      if (p.mesh.position.y < 0.05) { p.mesh.position.y = 0.05; p.vel.y *= -0.3; p.vel.x *= 0.6; p.vel.z *= 0.6; }
      p.mesh.material.opacity = 1;
      const k = p.life / p.max;
      p.mesh.scale.setScalar(Math.max(0.05, k));
    }
    for (const t of this.tracers) {
      if (t.life <= 0) continue;
      t.life -= dt;
      t.mesh.material.opacity = Math.max(0, t.life / 0.06) * 0.9;
      if (t.life <= 0) t.mesh.visible = false;
    }
    // decals fade very slowly
    for (const m of this.decals) {
      if (!m.visible) continue;
      m.material.opacity -= dt * 0.02;
      if (m.material.opacity <= 0) m.visible = false;
    }
    // skid marks linger, then fade
    for (const m of this.skids) {
      if (!m.visible) continue;
      m.material.opacity -= dt * 0.035;
      if (m.material.opacity <= 0) m.visible = false;
    }
  }
}
