import * as THREE from 'three';
import { VEHICLE, CITY } from './config.js';
import { clamp, angleDelta, damp } from './util.js';

const { WIDTH, LENGTH } = VEHICLE;

const CAR_COLORS = [
  0xb5402f, 0x2f5fb5, 0x2f9d56, 0xd9b53a, 0xcdd2d8,
  0x3a3f47, 0x8a5a2b, 0x6a3fa0, 0xc96a2f, 0x2fa6a6,
];

// distinct vehicle classes — multipliers on the base VEHICLE tuning
const CLASSES = {
  sedan:   { accel: 1.0,  top: 1.0,  grip: 1.0,  turn: 1.0 },
  sports:  { accel: 1.35, top: 1.28, grip: 1.18, turn: 1.15 },  // fast, planted, agile
  muscle:  { accel: 1.28, top: 1.2,  grip: 0.8,  turn: 0.92 },  // power, loose tail (drifty)
  van:     { accel: 0.72, top: 0.82, grip: 0.92, turn: 0.8 },   // heavy, sluggish
  compact: { accel: 0.95, top: 0.85, grip: 1.12, turn: 1.28 },  // nimble, low top end
};
const CLASS_NAMES = ['sedan', 'sports', 'muscle', 'van', 'compact'];

let _wheelGeo = null, _wheelMat = null;
function wheel() {
  if (!_wheelGeo) {
    _wheelGeo = new THREE.CylinderGeometry(0.92, 0.92, 0.7, 14);
    _wheelGeo.rotateZ(Math.PI / 2);   // axle along X; spin via mesh.rotation.x
    _wheelMat = new THREE.MeshStandardMaterial({ color: 0x14151a, roughness: 0.9 });
  }
  const m = new THREE.Mesh(_wheelGeo, _wheelMat);
  m.castShadow = true;
  return m;
}

// Car faces +Z (length along Z, width along X) to match forward = (sin yaw, cos yaw).
function buildCarMesh(color) {
  const g = new THREE.Group();
  const paint = new THREE.MeshStandardMaterial({ color, roughness: 0.45, metalness: 0.35 });
  const glass = new THREE.MeshStandardMaterial({ color: 0x10151c, roughness: 0.15, metalness: 0.6 });

  const body = new THREE.Mesh(new THREE.BoxGeometry(WIDTH, 1.5, LENGTH), paint);
  body.position.y = 1.35; body.castShadow = true; body.receiveShadow = true;
  // bevel the lower chassis a touch with a darker skirt
  const skirt = new THREE.Mesh(new THREE.BoxGeometry(WIDTH + 0.1, 0.7, LENGTH + 0.1),
    new THREE.MeshStandardMaterial({ color: 0x1a1c20, roughness: 0.8 }));
  skirt.position.y = 0.85;
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(WIDTH * 0.84, 1.15, LENGTH * 0.5), paint);
  cabin.position.set(0, 2.55, 0.4); cabin.castShadow = true;
  const windshield = new THREE.Mesh(new THREE.BoxGeometry(WIDTH * 0.78, 1.0, LENGTH * 0.52), glass);
  windshield.position.set(0, 2.55, 0.4);
  windshield.scale.set(1.01, 1.0, 1.0);
  // headlights + tail lights
  const hlMat = new THREE.MeshStandardMaterial({ color: 0xfff4c4, emissive: 0xfff0b0, emissiveIntensity: 0.7 });
  const tlMat = new THREE.MeshStandardMaterial({ color: 0x661111, emissive: 0xaa1818, emissiveIntensity: 0.6 });
  const lightGeo = new THREE.BoxGeometry(0.7, 0.45, 0.2);
  for (const sx of [-1, 1]) {
    const hl = new THREE.Mesh(lightGeo, hlMat); hl.position.set(sx * WIDTH * 0.32, 1.3, LENGTH / 2 + 0.02); g.add(hl);
    const tl = new THREE.Mesh(lightGeo, tlMat); tl.position.set(sx * WIDTH * 0.32, 1.3, -LENGTH / 2 - 0.02); g.add(tl);
  }
  g.add(skirt, body, cabin, windshield);

  // wheels at the four corners
  const wheels = [];
  const wx = WIDTH / 2 + 0.02, wz = LENGTH * 0.32;
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const w = wheel();
    w.position.set(sx * wx, 0.92, sz * wz);
    g.add(w); wheels.push(w);
  }
  return { group: g, wheels };
}

export class Vehicle {
  constructor(scene, x, z, yaw, kind = 'parked', color = null) {
    this.kind = kind;            // 'parked' | 'traffic' | 'player'
    this.color = color ?? CAR_COLORS[Math.floor(Math.random() * CAR_COLORS.length)];
    this.pos = new THREE.Vector3(x, 0, z);
    this.yaw = yaw;
    this.speed = 0;
    this.driver = null;          // 'player' | 'ai' | null
    this.cruise = 18 + Math.random() * 12;
    this.cls = CLASSES[kind === 'police' ? 'sports' : CLASS_NAMES[Math.floor(Math.random() * CLASS_NAMES.length)]];
    this._fwd = new THREE.Vector3();
    this._wheelRoll = 0;
    this.vel = new THREE.Vector3();   // world-space velocity (drift model)
    this._roll = 0; this._pitch = 0;  // weight-transfer body lean
    this.slip = 0;                    // lateral slide speed (drives skid FX)

    const built = buildCarMesh(this.color);
    this.mesh = built.group;
    this.mesh.rotation.order = 'YXZ';   // yaw, then pitch/roll lean
    this.wheels = built.wheels;
    if (kind === 'police') this._addLightBar();
    scene.add(this.mesh);
    this._sync();
  }

  _addLightBar() {
    this._flashT = 0;
    const geo = new THREE.BoxGeometry(0.7, 0.32, 0.7);
    this.lightRed = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0x550000, emissive: 0xff1a1a, emissiveIntensity: 1.2 }));
    this.lightBlue = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0x000055, emissive: 0x1a4dff, emissiveIntensity: 0.2 }));
    this.lightRed.position.set(-0.45, 3.25, 0.4);
    this.lightBlue.position.set(0.45, 3.25, 0.4);
    this.mesh.add(this.lightRed, this.lightBlue);
  }

  _flash(dt) {
    if (!this.lightRed) return;
    this._flashT += dt;
    const on = Math.floor(this._flashT * 6) % 2 === 0;
    this.lightRed.material.emissiveIntensity = on ? 1.6 : 0.15;
    this.lightBlue.material.emissiveIntensity = on ? 0.15 : 1.6;
  }

  // Chase a target position (used by police).
  updateChase(dt, target, city) {
    const desired = Math.atan2(target.x - this.pos.x, target.z - this.pos.z);
    const err = angleDelta(this.yaw, desired);
    const steer = clamp(err * 1.7, -1, 1);
    const dist = Math.hypot(target.x - this.pos.x, target.z - this.pos.z);
    const throttle = dist < 7 ? 0.1 : 1;
    this.step(dt, throttle, steer, false, city, dist > 60);
    this._flash(dt);
  }

  forward(out) { return out.set(Math.sin(this.yaw), 0, Math.cos(this.yaw)); }

  // Dispatch: the player's car gets the full grip/drift model; AI keeps the
  // lighter on-rails model so traffic/police pathing doesn't regress.
  step(dt, throttle, steer, handbrake, city, boost = false) {
    if (this.driver === 'player') this._driveDrift(dt, throttle, steer, handbrake, boost);
    else this._driveSimple(dt, throttle, steer, handbrake, boost);
    this._collide(city);
    this._spinWheels(dt);
    this._sync();
  }

  // On-rails: velocity always points along the nose. Used by AI.
  _driveSimple(dt, throttle, steer, handbrake, boost) {
    const engine = VEHICLE.ENGINE * this.cls.accel * (boost ? 1.5 : 1);
    const maxFwd = (VEHICLE.MAX_SPEED * this.cls.top + (this.maxSpeedBonus || 0)) * (boost ? 1.35 : 1);
    if (throttle > 0) this.speed += engine * throttle * dt;
    else if (throttle < 0) {
      if (this.speed > 0.5) this.speed -= VEHICLE.BRAKE * dt;
      else this.speed -= engine * 0.55 * dt;
    } else this.speed -= this.speed * 1.4 * dt;
    if (handbrake) this.speed -= this.speed * 3.2 * dt;
    this.speed -= this.speed * VEHICLE.DRAG * dt;
    this.speed = clamp(this.speed, -VEHICLE.REVERSE_MAX, maxFwd);
    const authority = clamp(Math.abs(this.speed) / 6, 0, 1);
    const dir = this.speed >= 0 ? 1 : -1;
    this.yaw += steer * VEHICLE.TURN * this.cls.turn * dt * authority * dir;
    this.forward(this._fwd);
    this.pos.x += this._fwd.x * this.speed * dt;
    this.pos.z += this._fwd.z * this.speed * dt;
    this.vel.set(this._fwd.x * this.speed, 0, this._fwd.z * this.speed);
  }

  // Grip/drift model: world-space velocity with longitudinal engine force and
  // lateral grip. Steering turns the nose; momentum makes the tail step out
  // (handbrake/boost drop grip for slides). Adds weight-transfer body lean.
  _driveDrift(dt, throttle, steer, handbrake, boost) {
    const f = this.forward(this._fwd);
    const rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw);   // right vector
    let vLong = this.vel.x * f.x + this.vel.z * f.z;
    let vLat = this.vel.x * rx + this.vel.z * rz;

    const engine = VEHICLE.ENGINE * this.cls.accel * (boost ? 1.5 : 1);
    const maxFwd = (VEHICLE.MAX_SPEED * this.cls.top + (this.maxSpeedBonus || 0)) * (boost ? 1.35 : 1);
    if (throttle > 0) vLong += engine * throttle * dt;
    else if (throttle < 0) {
      if (vLong > 0.5) vLong -= VEHICLE.BRAKE * dt;
      else vLong -= engine * 0.55 * dt;
    } else vLong -= vLong * 1.4 * dt;
    vLong -= vLong * VEHICLE.DRAG * dt;
    vLong = clamp(vLong, -VEHICLE.REVERSE_MAX, maxFwd);

    // lateral grip bleeds sideways velocity; handbrake/boost loosen it
    const grip = (handbrake ? 1.6 : VEHICLE.GRIP * this.cls.grip) * (boost ? 0.75 : 1);
    vLat -= vLat * Math.min(1, grip * dt);
    this.slip = Math.abs(vLat);

    // recompose velocity with the CURRENT heading (before steering) so the
    // next frame's heading change produces real slip
    this.vel.set(f.x * vLong + rx * vLat, 0, f.z * vLong + rz * vLat);

    // steer the nose (does NOT rotate the velocity vector)
    const authority = clamp(Math.abs(vLong) / 6, 0, 1);
    const dir = vLong >= 0 ? 1 : -1;
    const steerRate = VEHICLE.TURN * this.cls.turn * (handbrake ? 1.3 : 1);
    this.yaw += steer * steerRate * dt * authority * dir;

    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;
    this.speed = vLong;

    // weight transfer: lean out of turns, pitch under accel/brake
    const accelIn = throttle > 0 ? throttle : throttle < 0 ? -1 : 0;
    this._roll = damp(this._roll, clamp(-vLat * 0.010, -0.13, 0.13), 8, dt);
    this._pitch = damp(this._pitch, clamp(-accelIn * 0.045 + (handbrake ? 0.02 : 0), -0.06, 0.05), 8, dt);
  }

  _collide(city) {
    const r = WIDTH * 0.5;
    this.forward(this._fwd);
    let hit = false;
    for (const s of [LENGTH * 0.33, -LENGTH * 0.33]) {
      const px = this.pos.x + this._fwd.x * s;
      const pz = this.pos.z + this._fwd.z * s;
      const res = city.collideCircle(px, pz, r);
      if (res.hit) { this.pos.x += res.x - px; this.pos.z += res.z - pz; hit = true; }
    }
    if (hit) { this.speed *= 0.3; this.vel.multiplyScalar(0.3); }
  }

  _spinWheels(dt) {
    this._wheelRoll += (this.speed * dt) / 0.92;
    for (const w of this.wheels) w.rotation.x = this._wheelRoll;
  }

  _inBounds(x, z) {
    const lim = CITY.HALF - CITY.ROAD * 0.5;
    return x > -lim && x < lim && z > -lim && z < lim;
  }

  // Cardinal road-following AI: drive straight, turn at obstacles/intersections.
  updateAI(dt, city) {
    this.forward(this._fwd);
    const ahead = 7;
    const ax = this.pos.x + this._fwd.x * ahead;
    const az = this.pos.z + this._fwd.z * ahead;
    if (city.pointInBuilding(ax, az) || !this._inBounds(ax, az)) {
      this._pickCardinal(city);
    } else if (Math.random() < 0.004) {
      // occasionally turn at an intersection for variety
      this._pickCardinal(city, true);
    }
    const throttle = this.speed < this.cruise ? 1 : -0.15;
    this.step(dt, throttle, 0, false, city, false);
  }

  _pickCardinal(city, allowStraight = false) {
    const cards = [0, Math.PI / 2, Math.PI, -Math.PI / 2];
    const opts = [];
    const back = ((this.yaw + Math.PI) % (Math.PI * 2));
    for (const c of cards) {
      const fx = Math.sin(c), fz = Math.cos(c);
      const ax = this.pos.x + fx * 9, az = this.pos.z + fz * 9;
      if (city.pointInBuilding(ax, az) || !this._inBounds(ax, az)) continue;
      // avoid immediate U-turns unless nothing else is open
      if (Math.abs(((c - back + Math.PI * 3) % (Math.PI * 2)) - Math.PI) < 0.1 && !allowStraight) continue;
      opts.push(c);
    }
    if (opts.length === 0) { this.yaw += Math.PI; return; }
    this.yaw = opts[Math.floor(Math.random() * opts.length)];
  }

  _sync() {
    this.mesh.position.set(this.pos.x, this.pos.y, this.pos.z);
    this.mesh.rotation.set(this._pitch, this.yaw, this._roll);
  }

  dispose(scene) { scene.remove(this.mesh); }
}
