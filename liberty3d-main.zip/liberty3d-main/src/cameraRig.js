import * as THREE from 'three';
import { CAM, CITY } from './config.js';
import { clamp } from './util.js';
import { consumeMouse } from './input.js';

// Third-person camera with an elevation-based aim model: `pitch` is a true look
// angle (negative = down, positive = up), so camera.getWorldDirection() is the
// aim ray and mouse movement maps intuitively for shooting. Camera sits behind
// the target along that ray and pulls in when a building is in the way.
export class CameraRig {
  constructor(camera) {
    this.camera = camera;
    this.yaw = Math.PI;
    this.pitch = -0.12;       // slight downward rest angle
    this.dist = CAM.DIST;
    this.target = new THREE.Vector3();
    this._fwd = new THREE.Vector3();
    this._desired = new THREE.Vector3();
    this.shake = 0;           // transient screen-shake magnitude
  }

  addShake(a) { this.shake = Math.min(2.6, this.shake + a); }

  // horizontal-only basis for movement
  forwardFlat(out = new THREE.Vector3()) {
    return out.set(Math.sin(this.yaw), 0, Math.cos(this.yaw));
  }
  rightFlat(out = new THREE.Vector3()) {
    return out.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
  }

  update(dt, targetPos, city, distOverride = null) {
    const m = consumeMouse();
    this.yaw -= m.x * CAM.SENS;
    this.pitch = clamp(this.pitch - m.y * CAM.SENS, CAM.MIN_PITCH, CAM.MAX_PITCH);

    const dist = distOverride ?? this.dist;
    this.target.copy(targetPos);

    const cp = Math.cos(this.pitch), sp = Math.sin(this.pitch);
    this._fwd.set(Math.sin(this.yaw) * cp, sp, Math.cos(this.yaw) * cp);

    this._desired.set(
      this.target.x - this._fwd.x * dist,
      this.target.y - this._fwd.y * dist,
      this.target.z - this._fwd.z * dist
    );

    // pull camera in if a building blocks the line to the target
    const allowed = this._collideDistance(this.target, this._desired, city);
    if (allowed < 1) this._desired.lerpVectors(this.target, this._desired, Math.max(0.18, allowed));

    const k = 1 - Math.exp(-CAM.FOLLOW * dt);
    this.camera.position.lerp(this._desired, k);
    if (this.camera.position.y < 1.0) this.camera.position.y = 1.0;
    if (this.shake > 0.0001) {                 // jitter position, keep aim on target
      const s = this.shake;
      this.camera.position.x += (Math.random() * 2 - 1) * s;
      this.camera.position.y += (Math.random() * 2 - 1) * s * 0.7;
      this.camera.position.z += (Math.random() * 2 - 1) * s;
      this.shake *= Math.exp(-9 * dt);
      if (this.shake < 0.01) this.shake = 0;
    }
    this.camera.lookAt(this.target);
  }

  _collideDistance(from, to, city) {
    const ox = from.x, oy = from.y, oz = from.z;
    const dx = to.x - ox, dy = to.y - oy, dz = to.z - oz;
    const segLen = Math.hypot(dx, dy, dz) || 1;
    let best = 1;
    const buffer = 0.6;
    for (const b of city.buildings) {
      const t = raySegAABB(ox, oy, oz, dx, dy, dz, b.minX, 0, b.minZ, b.maxX, b.h + CITY.SIDEWALK, b.maxZ);
      if (t !== null && t < best) best = Math.max(0, t - buffer / segLen);
    }
    return best;
  }
}

// Segment vs AABB; returns entry fraction t in [0,1] or null.
function raySegAABB(ox, oy, oz, dx, dy, dz, minx, miny, minz, maxx, maxy, maxz) {
  let tmin = 0, tmax = 1;
  const axes = [
    [ox, dx, minx, maxx],
    [oy, dy, miny, maxy],
    [oz, dz, minz, maxz],
  ];
  for (const [o, d, mn, mx] of axes) {
    if (Math.abs(d) < 1e-8) {
      if (o < mn || o > mx) return null;
    } else {
      let t1 = (mn - o) / d, t2 = (mx - o) / d;
      if (t1 > t2) { const tmp = t1; t1 = t2; t2 = tmp; }
      if (t1 > tmin) tmin = t1;
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return null;
    }
  }
  return tmin;
}
