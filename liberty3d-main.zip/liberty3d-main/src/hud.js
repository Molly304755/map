import { CITY } from './config.js';
import { clamp } from './util.js';

// DOM + minimap HUD. Pure presentation; game logic lives elsewhere.
export class HUD {
  constructor() {
    this.elStars = document.getElementById('stars');
    this.elHealth = document.getElementById('healthFill');
    this.elArmor = document.getElementById('armorFill');
    this.elArmorRow = document.getElementById('armorRow');
    this.elMoney = document.getElementById('moneyVal');
    this.elMission = document.getElementById('missionText');
    this.elWeaponName = document.getElementById('weaponName');
    this.elAmmo = document.getElementById('ammoVal');
    this.elPrompt = document.getElementById('prompt');
    this.elSpeedo = document.getElementById('speedo');
    this.elSpeed = document.getElementById('speedVal');
    this.elToast = document.getElementById('toast');
    this.mm = document.getElementById('minimap');
    this.mmx = this.mm.getContext('2d');
    this._toastTimer = 0;
    this._lastStars = -1;
    this._lastMoney = -1;
    // damage-feedback overlay (red vignette): flash on hit, pulse when low HP
    this._hurt = 0; this._hp = 100; this._pulse = 0;
    const v = document.createElement('div');
    v.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:3;opacity:0;' +
      'background:radial-gradient(ellipse at center, rgba(170,0,0,0) 38%, rgba(165,0,0,0.85) 100%);';
    document.body.appendChild(v);
    this.elHurt = v;

    // full-map screen (toggle M / Esc)
    this._mapOpen = false;
    const mo = document.createElement('div');
    mo.style.cssText = 'position:fixed;inset:0;z-index:8;display:none;align-items:center;justify-content:center;background:rgba(6,9,14,0.82);';
    const mc = document.createElement('canvas');
    mc.width = 760; mc.height = 760;
    mc.style.cssText = 'width:min(86vmin,860px);height:min(86vmin,860px);border-radius:14px;border:1px solid rgba(255,255,255,0.14);box-shadow:0 30px 80px rgba(0,0,0,0.6);';
    const cap = document.createElement('div');
    cap.textContent = 'CITY MAP — M or Esc to close';
    cap.style.cssText = 'position:absolute;top:7%;left:0;right:0;text-align:center;color:#cfd6e0;font-size:13px;letter-spacing:3px;';
    mo.appendChild(mc); mo.appendChild(cap);
    document.body.appendChild(mo);
    this.elMap = mo; this.mapCanvas = mc; this.mapCtx = mc.getContext('2d');
    window.addEventListener('keydown', (e) => {
      if (e.code === 'KeyM') { this._mapOpen = !this._mapOpen; this.elMap.style.display = this._mapOpen ? 'flex' : 'none'; }
      else if (e.code === 'Escape' && this._mapOpen) { this._mapOpen = false; this.elMap.style.display = 'none'; }
    });
  }

  setHealth(hp) { this._hp = hp; this.elHealth.style.width = clamp(hp, 0, 100) + '%'; }

  setArmor(a, max = 100) {
    if (!this.elArmor) return;
    const pct = max > 0 ? clamp(a, 0, max) / max * 100 : 0;
    this.elArmor.style.width = pct + '%';
    if (this.elArmorRow) this.elArmorRow.style.display = a > 0 ? 'block' : 'none';
  }

  hurt(amount) { this._hurt = Math.min(1, this._hurt + amount); }

  setMoney(n) {
    if (n === this._lastMoney) return;
    this._lastMoney = n;
    this.elMoney.textContent = Math.round(n).toLocaleString('en-US');
  }

  setStars(n) {
    if (n === this._lastStars) return;
    this._lastStars = n;
    let s = '';
    for (let i = 0; i < 5; i++) s += `<span class="${i < n ? 'on' : ''}">★</span>`;
    this.elStars.innerHTML = s;
  }

  setMission(text) { if (this.elMission.textContent !== text) this.elMission.textContent = text; }

  setWeapon(name, ammo) {
    if (this.elWeaponName.textContent !== name) this.elWeaponName.textContent = name;
    const a = ammo === Infinity ? '∞' : String(ammo);
    if (this.elAmmo.textContent !== a) this.elAmmo.textContent = a;
  }

  prompt(text) {
    if (text) { this.elPrompt.innerHTML = text; this.elPrompt.classList.add('show'); }
    else this.elPrompt.classList.remove('show');
  }

  speed(kmh) {
    if (kmh === null) { this.elSpeedo.classList.remove('show'); return; }
    this.elSpeedo.classList.add('show');
    this.elSpeed.textContent = Math.round(kmh);
  }

  toast(text, cls = 'good', ms = 1800) {
    this.elToast.textContent = text;
    this.elToast.className = 'show ' + cls;
    this._toastTimer = ms / 1000;
  }

  tick(dt) {
    if (this._toastTimer > 0) {
      this._toastTimer -= dt;
      if (this._toastTimer <= 0) this.elToast.className = '';
    }
    // damage vignette: quick flash on hit + pulsing red when health is low
    this._pulse += dt;
    this._hurt = Math.max(0, this._hurt - dt * 2.5);
    let low = 0;
    if (this._hp < 28) {
      const t = 1 - this._hp / 28;
      low = (0.25 + 0.22 * Math.sin(this._pulse * 6)) * t;
    }
    this.elHurt.style.opacity = String(Math.min(0.9, Math.max(this._hurt, low)));
  }

  // ---- minimap (north-up, centred on player) ----
  drawMinimap(city, player, blips) {
    const ctx = this.mmx;
    const W = this.mm.width, H = this.mm.height, R = W / 2;
    const range = 130;             // world units shown from centre to edge
    const scale = R / range;
    ctx.save();
    // circular clip
    ctx.beginPath(); ctx.arc(R, R, R - 2, 0, Math.PI * 2); ctx.clip();
    ctx.fillStyle = '#23272e'; ctx.fillRect(0, 0, W, H);

    ctx.translate(R, R);
    ctx.scale(scale, scale);
    ctx.translate(-player.pos.x, -player.pos.z);

    // buildings
    ctx.fillStyle = '#3c424b';
    for (const b of city.buildings) {
      const w = b.maxX - b.minX, d = b.maxZ - b.minZ;
      // cull
      if (Math.abs(b.minX - player.pos.x) > range + 30 || Math.abs(b.minZ - player.pos.z) > range + 30) continue;
      ctx.fillRect(b.minX, b.minZ, w, d);
    }

    // blips (cars, cops, objectives…)
    for (const bl of blips) {
      ctx.fillStyle = bl.color;
      ctx.beginPath();
      ctx.arc(bl.x, bl.z, bl.r || 2.4 / scale * 1.0, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();

    // player arrow (always centre)
    ctx.save();
    ctx.translate(R, R);
    ctx.rotate(player.heading + Math.PI); // map z-down; arrow points up = forward
    ctx.fillStyle = '#ffd34e';
    ctx.beginPath();
    ctx.moveTo(0, -9); ctx.lineTo(6, 7); ctx.lineTo(0, 3); ctx.lineTo(-6, 7);
    ctx.closePath(); ctx.fill();
    ctx.restore();

    // ring
    ctx.strokeStyle = 'rgba(255,255,255,0.12)';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(R, R, R - 3, 0, Math.PI * 2); ctx.stroke();

    if (this._mapOpen) this._drawFullMap(city, player, blips);
  }

  // Full-screen city map (toggle M). Draws the whole city to fit the canvas.
  _drawFullMap(city, player, blips) {
    const ctx = this.mapCtx, S = this.mapCanvas.width;
    const HALF = city.HALF || 240, span = HALF * 2 + 30, sc = S / span;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = '#0e1218'; ctx.fillRect(0, 0, S, S);
    ctx.save();
    ctx.translate(S / 2, S / 2); ctx.scale(sc, sc);
    ctx.fillStyle = '#2a2f37'; ctx.fillRect(-HALF, -HALF, HALF * 2, HALF * 2);
    ctx.fillStyle = '#474e59';
    for (const b of city.buildings) ctx.fillRect(b.minX, b.minZ, b.maxX - b.minX, b.maxZ - b.minZ);
    for (const bl of blips) { ctx.fillStyle = bl.color; ctx.beginPath(); ctx.arc(bl.x, bl.z, (bl.r || 3) + 3, 0, Math.PI * 2); ctx.fill(); }
    ctx.restore();
    ctx.save();
    ctx.translate(S / 2 + player.pos.x * sc, S / 2 + player.pos.z * sc);
    ctx.rotate(player.heading + Math.PI);
    ctx.fillStyle = '#ffd34e';
    ctx.beginPath(); ctx.moveTo(0, -12); ctx.lineTo(8, 9); ctx.lineTo(0, 4); ctx.lineTo(-8, 9); ctx.closePath(); ctx.fill();
    ctx.restore();
  }
}
