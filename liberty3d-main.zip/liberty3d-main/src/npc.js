import * as THREE from 'three';
import { buildAvatar } from './player.js';
import { dampAngle, clamp } from './util.js';

const SKINS = [0xf0c8a0, 0xd8a07a, 0xb87a52, 0x8a5a38, 0xe8b890];
const CLOTHES = [0x9b3b3b, 0x3b5e9b, 0x3b9b5e, 0xb0a23b, 0x6a3b9b, 0x3b9b9b, 0xcccccc, 0x444a52, 0xd98a3b];
const rc = (a) => a[Math.floor(Math.random() * a.length)];

export class Pedestrian {
  constructor(scene, x, z) {
    const a = buildAvatar({ skin: rc(SKINS), jacket: rc(CLOTHES), pants: rc(CLOTHES) });
    this.avatar = a;
    this.mesh = a.root;
    this.mesh.scale.setScalar(0.92 + Math.random() * 0.16);
    scene.add(this.mesh);

    this.pos = new THREE.Vector3(x, 0, z);
    this.heading = Math.random() * Math.PI * 2;
    this.dir = this.heading;
    this.speed = 2.4 + Math.random() * 2.2;
    this.phase = Math.random() * 10;
    this.changeTimer = 1 + Math.random() * 2;
    this.hp = 100;
    this.dead = false;
    this.deadTimer = 0;
    this.gone = false;
    this.panic = 0;
    this.fleeFrom = new THREE.Vector3();
    this._curSpeed = this.speed;
    this._sync();
  }

  // Make this pedestrian flee away from a threat point for `dur` seconds.
  scare(fx, fz, dur = 3.5) {
    if (this.dead) return;
    this.fleeFrom.set(fx, 0, fz);
    this.panic = Math.max(this.panic, dur);
  }

  die() {
    if (this.dead) return;
    this.dead = true;
    this.deadTimer = 6;       // lie on the ground for a while, then despawn
  }

  // take damage from a shooter at (fx,fz); returns true if this shot killed.
  hurt(dmg, fx, fz) {
    if (this.dead) return false;
    this.hp -= dmg;
    if (this.hp <= 0) { this.die(); return true; }
    this.scare(fx, fz, 4);                       // wounded -> flee the shooter
    const a = Math.atan2(this.pos.x - fx, this.pos.z - fz);
    this.pos.x += Math.sin(a) * 0.4; this.pos.z += Math.cos(a) * 0.4;  // knockback
    return false;
  }

  update(dt, city) {
    if (this.dead) {
      this.deadTimer -= dt;
      // fall flat
      this.mesh.rotation.z = dampAngle(this.mesh.rotation.z, Math.PI / 2, 10, dt);
      this.mesh.position.y = Math.max(0.5, this.mesh.position.y - dt * 2);
      if (this.deadTimer <= 0) this.gone = true;
      return;
    }

    let spd = this.speed;
    if (this.panic > 0) {
      this.panic -= dt;
      // sprint directly away from the threat
      this.dir = Math.atan2(this.pos.x - this.fleeFrom.x, this.pos.z - this.fleeFrom.z);
      spd = this.speed * 2.4;
      this.changeTimer = 0.3;
    } else {
      this.changeTimer -= dt;
      if (this.changeTimer <= 0) {
        this.dir += (Math.random() - 0.5) * 1.4;
        this.changeTimer = 1.5 + Math.random() * 2.5;
      }
    }
    this._curSpeed = spd;
    this.pos.x += Math.sin(this.dir) * spd * dt;
    this.pos.z += Math.cos(this.dir) * spd * dt;

    const res = city.collideCircle(this.pos.x, this.pos.z, 0.6);
    if (res.hit) {
      this.pos.x = res.x; this.pos.z = res.z;
      this.dir += Math.PI * 0.6 + (Math.random() - 0.5);   // bounce off
      if (this.panic <= 0) this.changeTimer = 0.8;
    }

    this.heading = dampAngle(this.heading, this.dir, 10, dt);
    this._animate(dt);
    this._sync();
  }

  _animate(dt) {
    this.phase += dt * (6 + this._curSpeed);
    const amp = this.panic > 0 ? 0.9 : 0.6;
    const s = Math.sin(this.phase) * amp;
    this.avatar.legL.rotation.x = s; this.avatar.legR.rotation.x = -s;
    this.avatar.armL.rotation.x = -s * 0.8; this.avatar.armR.rotation.x = s * 0.8;
  }

  _sync() {
    this.mesh.position.set(this.pos.x, this.mesh.position.y || 0, this.pos.z);
    if (!this.dead) { this.mesh.position.y = 0; this.mesh.rotation.set(0, this.heading, 0); }
    else this.mesh.rotation.y = this.heading;
  }

  dispose(scene) { scene.remove(this.mesh); }
}

export class Crowd {
  constructor(scene, city) {
    this.scene = scene;
    this.city = city;
    this.peds = [];
    this.target = 22;
  }

  _spawnNear(player) {
    const ang = Math.random() * Math.PI * 2;
    const dist = 36 + Math.random() * 46;
    let x = player.pos.x + Math.sin(ang) * dist;
    let z = player.pos.z + Math.cos(ang) * dist;
    const res = this.city.collideCircle(x, z, 0.6);
    x = res.x; z = res.z;
    const lim = this.city.HALF ?? 240;
    if (Math.abs(x) > lim || Math.abs(z) > lim) return;
    this.peds.push(new Pedestrian(this.scene, x, z));
  }

  // returns number of pedestrians killed by the player's car this frame
  update(dt, player, cars, playerCar, effects) {
    // population maintenance
    for (let i = this.peds.length - 1; i >= 0; i--) {
      const p = this.peds[i];
      if (p.gone) { p.dispose(this.scene); this.peds.splice(i, 1); continue; }
      const d = Math.hypot(p.pos.x - player.pos.x, p.pos.z - player.pos.z);
      if (!p.dead && d > 135) { p.dispose(this.scene); this.peds.splice(i, 1); continue; }
      p.update(dt, this.city);
    }
    if (this.peds.length < this.target && Math.random() < 0.5) this._spawnNear(player);

    // run-overs
    let playerKills = 0;
    for (const car of cars) {
      if (Math.abs(car.speed) < 6) continue;
      const fx = Math.sin(car.yaw), fz = Math.cos(car.yaw);
      for (const p of this.peds) {
        if (p.dead) continue;
        const dx = p.pos.x - car.pos.x, dz = p.pos.z - car.pos.z;
        const along = dx * fx + dz * fz;
        const side = dx * Math.cos(car.yaw) - dz * Math.sin(car.yaw);
        if (Math.abs(along) < 4.6 && Math.abs(side) < 2.7) {
          p.die();
          if (effects) effects.bloodAt(p.pos);
          if (car === playerCar) playerKills++;
        } else if (along > 0 && along < 18 && Math.abs(side) < 6) {
          p.scare(car.pos.x, car.pos.z, 1.4);   // dive out of the way
        }
      }
    }
    return playerKills;
  }

  // Scatter pedestrians within `radius` of a threat (e.g. gunfire).
  alarm(pos, radius) {
    const r2 = radius * radius;
    for (const p of this.peds) {
      if (p.dead) continue;
      const dx = p.pos.x - pos.x, dz = p.pos.z - pos.z;
      if (dx * dx + dz * dz < r2) p.scare(pos.x, pos.z, 3 + Math.random() * 2);
    }
  }

  // nearest living pedestrian to a ray origin within maxDist (for hitscan)
  list() { return this.peds; }
}
