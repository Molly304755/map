// Keyboard + mouse input with pointer-lock mouse-look.
// Keys are tracked by KeyboardEvent.code (layout independent: KeyW, ShiftLeft…).

export const input = {
  down: Object.create(null),   // held this frame
  pressed: Object.create(null), // edge: went down since last consume
  mouseDX: 0,
  mouseDY: 0,
  mouseDown: false,
  mousePressed: false,
  locked: false,
};

export function isDown(code) { return !!input.down[code]; }

// Movement axis helpers (returns -1..1).
export function axisX() { return (isDown('KeyA') || isDown('ArrowLeft') ? 1 : 0) - (isDown('KeyD') || isDown('ArrowRight') ? 1 : 0); }
export function axisY() { return (isDown('KeyW') || isDown('ArrowUp') ? 1 : 0) - (isDown('KeyS') || isDown('ArrowDown') ? 1 : 0); }

const BLOCK = new Set(['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'KeyW', 'KeyA', 'KeyS', 'KeyD']);

export function initInput(canvas) {
  window.addEventListener('keydown', (e) => {
    if (e.repeat) return;
    if (!input.down[e.code]) input.pressed[e.code] = true;
    input.down[e.code] = true;
    if (BLOCK.has(e.code)) e.preventDefault();
  });
  window.addEventListener('keyup', (e) => { input.down[e.code] = false; });

  // Lose all keys when the tab loses focus (prevents "stuck" movement).
  window.addEventListener('blur', () => {
    for (const k in input.down) input.down[k] = false;
    input.mouseDown = false;
  });

  canvas.addEventListener('mousedown', (e) => {
    if (e.button === 0) { input.mouseDown = true; input.mousePressed = true; }
    if (!input.locked) canvas.requestPointerLock?.();
  });
  window.addEventListener('mouseup', (e) => { if (e.button === 0) input.mouseDown = false; });

  window.addEventListener('mousemove', (e) => {
    if (input.locked) { input.mouseDX += e.movementX || 0; input.mouseDY += e.movementY || 0; }
  });

  document.addEventListener('pointerlockchange', () => {
    input.locked = document.pointerLockElement === canvas;
  });
}

// Pull-and-reset the accumulated mouse delta for this frame.
export function consumeMouse() {
  const d = { x: input.mouseDX, y: input.mouseDY };
  input.mouseDX = 0; input.mouseDY = 0;
  return d;
}

// Was a key pressed since the last endFrame()? (edge detection)
export function wasPressed(code) { return !!input.pressed[code]; }
export function consumeMouseClick() { const v = input.mousePressed; input.mousePressed = false; return v; }

// Call at the very end of each frame to clear edge state.
export function endFrame() {
  for (const k in input.pressed) input.pressed[k] = false;
}
