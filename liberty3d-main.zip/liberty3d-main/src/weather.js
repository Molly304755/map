import * as THREE from 'three';

// Dynamic weather: a slow clear ↔ overcast ↔ rain cycle that darkens the sky,
// thickens the fog, and drops instanced rain around the player. Designed to run
// AFTER the day/night pass each frame — it multiplies the lighting it finds, so
// it composes with time-of-day instead of fighting it.
const GREY = new THREE.Color(0x9aa3ad);

export class Weather {
  constructor(scene) {
    this.wet = 0;            // 0 = clear, 1 = downpour
    this.target = 0;
    this.timer = 16;         // first mood change after ~16s
    this._fogFarBase = (scene.fog && scene.fog.far) || 760;

    // rain — instanced vertical streaks recycled around the player
    this.MAX = 900;
    this.R = 60;
    const geo = new THREE.BoxGeometry(0.05, 1.5, 0.05);
    const mat = new THREE.MeshBasicMaterial({ color: 0xaebfcf, transparent: true, opacity: 0.5, depthWrite: false });
    this.rain = new THREE.InstancedMesh(geo, mat, this.MAX);
    this.rain.frustumCulled = false;
    this.rain.count = 0;
    scene.add(this.rain);

    this.drops = [];
    for (let i = 0; i < this.MAX; i++) this.drops.push({ x: 0, y: -1, z: 0, v: 55 + Math.random() * 28 });
    this._m = new THREE.Matrix4();
    this._q = new THREE.Quaternion();
    this._s = new THREE.Vector3(1, 1, 1);
    this._p = new THREE.Vector3();
  }

  get label() { return this.wet > 0.6 ? 'RAIN' : this.wet > 0.25 ? 'OVERCAST' : 'CLEAR'; }

  update(dt, player, sun, hemi, fog) {
    this.timer -= dt;
    if (this.timer <= 0) {
      const r = Math.random();
      this.target = r < 0.45 ? 0 : r < 0.75 ? 0.45 : 1;   // clear / overcast / rain
      this.timer = 45 + Math.random() * 55;
    }
    this.wet += (this.target - this.wet) * Math.min(1, dt * 0.25);   // slow transitions
    const wet = this.wet;

    // mood: dimmer, greyer, closer horizon when wet
    if (sun) sun.intensity *= (1 - 0.55 * wet);
    if (hemi) hemi.intensity *= (1 - 0.35 * wet);
    if (fog) {
      fog.color.lerp(GREY, wet * 0.5);
      fog.far = this._fogFarBase - wet * 430;
    }

    // rain particles (only real rain above the overcast threshold)
    const rainAmt = Math.max(0, (wet - 0.35) / 0.65);
    const active = Math.floor(rainAmt * this.MAX);
    this.rain.count = active;
    if (active > 0) {
      const px = player.pos.x, pz = player.pos.z;
      for (let i = 0; i < active; i++) {
        const d = this.drops[i];
        d.y -= d.v * dt;
        if (d.y < 0.2 || Math.abs(d.x - px) > this.R || Math.abs(d.z - pz) > this.R) {
          d.x = px + (Math.random() * 2 - 1) * this.R;
          d.z = pz + (Math.random() * 2 - 1) * this.R;
          d.y = 16 + Math.random() * 16;
        }
        this._p.set(d.x, d.y, d.z);
        this._m.compose(this._p, this._q, this._s);
        this.rain.setMatrixAt(i, this._m);
      }
      this.rain.instanceMatrix.needsUpdate = true;
    }
  }
}
