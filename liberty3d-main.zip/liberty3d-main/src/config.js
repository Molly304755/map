// Central tuning + world layout constants. Keep gameplay numbers here so the
// rest of the code reads cleanly and refinement passes have one place to tweak.

export const CITY = {
  GRID: 8,          // blocks per side
  BLOCK: 44,        // building-lot footprint (square side)
  ROAD: 18,         // road width between blocks
  SIDEWALK: 1.0,    // sidewalk slab height
  MAX_BUILDING_H: 64,
  MIN_BUILDING_H: 9,
};
CITY.CELL = CITY.BLOCK + CITY.ROAD;        // grid pitch
CITY.SPAN = CITY.GRID * CITY.CELL;          // total city size
CITY.HALF = CITY.SPAN / 2;                  // world extends [-HALF, +HALF]

export const PLAYER = {
  RADIUS: 0.7,
  HEIGHT: 3.4,
  WALK: 7.5,
  RUN: 14.5,
  ACCEL: 60,
  TURN_LERP: 14,    // how fast the body swivels to face movement
  JUMP: 16,
  GRAVITY: 42,
  MAX_HP: 100,
};

export const CAM = {
  DIST: 9.5,
  HEIGHT_AIM: 2.7,  // look target above player feet (chest/head height)
  MIN_PITCH: -0.7,  // look down
  MAX_PITCH: 0.62,  // look up
  SENS: 0.0024,
  FOLLOW: 10,       // position smoothing
};

export const VEHICLE = {
  ENGINE: 95,       // forward acceleration
  BRAKE: 140,
  REVERSE_MAX: 26,
  MAX_SPEED: 78,
  BOOST: 120,
  DRAG: 0.9,
  GRIP: 7.0,        // lateral grip (higher = less drift)
  TURN: 2.3,        // steering rate
  WIDTH: 4.2,
  LENGTH: 8.2,
};


export const COLORS = {
  SKY: 0x9fc7e8,
  FOG: 0xc8d6e6,
  ASPHALT: 0x3a3e45,
  SIDEWALK: 0x787e87,
  LANE: 0xd9d9c0,
  GRASS: 0x4a7a44,
  SUN: 0xfff3d6,
};
