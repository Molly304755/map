// Dialogue + voice. Uses the browser's built-in Web Speech API (SpeechSynthesis)
// for runtime voice — completely free, no assets, no network. Shows subtitles in
// a DOM overlay so it still "reads" even if a device has no TTS engine.
//
// Characters are defined with voice profiles (pitch/rate/colour) so each one
// sounds and looks distinct. Story/mission/ambient lines call say()/bark().

export class Dialogue {
  constructor() {
    this.synth = (typeof window !== 'undefined' && window.speechSynthesis) || null;
    this.enabled = !!this.synth;
    this.voices = [];
    this.muted = false;
    this._timer = 0;
    this._lastBark = -999;
    this.cast = Object.create(null);

    if (this.synth) {
      const load = () => { this.voices = this.synth.getVoices() || []; };
      load();
      try { this.synth.addEventListener('voiceschanged', load); } catch (e) { this.synth.onvoiceschanged = load; }
    }

    const el = document.createElement('div');
    el.style.cssText = 'position:fixed;left:50%;bottom:15%;transform:translateX(-50%);max-width:72vw;' +
      'text-align:center;z-index:6;pointer-events:none;opacity:0;transition:opacity .18s;' +
      'font-size:19px;line-height:1.4;text-shadow:0 2px 10px #000,0 0 2px #000;font-weight:600;';
    document.body.appendChild(el);
    this.el = el;
  }

  // register a character voice profile
  define(name, { pitch = 1, rate = 1, color = '#ffd34e', voiceHint = null } = {}) {
    this.cast[name] = { pitch, rate, color, voiceHint };
  }

  _pickVoice(hint) {
    if (!this.voices.length) return null;
    if (hint) {
      const v = this.voices.find((x) => (x.name || '').toLowerCase().includes(hint));
      if (v) return v;
    }
    return this.voices.find((x) => (x.lang || '').toLowerCase().startsWith('en')) || this.voices[0];
  }

  // speaker '' = no name label (ambient/system). opts: {interrupt, volume, silent}
  say(speaker, text, opts = {}) {
    const p = this.cast[speaker] || {};
    this.el.innerHTML =
      (speaker ? `<b style="color:${p.color || '#ffd34e'}">${speaker}</b>  ` : '') +
      `<span style="color:#eef2f7">${text}</span>`;
    this.el.style.opacity = '1';
    this._timer = Math.max(1.8, Math.min(7, text.length * 0.055));

    if (this.enabled && !this.muted && !opts.silent) {
      try {
        if (opts.interrupt) this.synth.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.pitch = p.pitch ?? 1;
        u.rate = p.rate ?? 1;
        u.volume = opts.volume ?? 0.95;
        const v = this._pickVoice(p.voiceHint);
        if (v) u.voice = v;
        this.synth.speak(u);
      } catch (e) { /* TTS unavailable — subtitle still shows */ }
    }
  }

  // short ambient one-liner (subtitle only by default, rate-limited)
  bark(text, now = 0) {
    if (now - this._lastBark < 3) return;
    this._lastBark = now;
    this.say('', text, { volume: 0.55 });
  }

  tick(dt) {
    if (this._timer > 0) {
      this._timer -= dt;
      if (this._timer <= 0) this.el.style.opacity = '0';
    }
  }

  resume() { try { this.synth && this.synth.resume(); } catch (e) {} }
  setMuted(v) { this.muted = v; if (v && this.synth) try { this.synth.cancel(); } catch (e) {} }
}

// A small default cast so the world has voices out of the box. Original characters.
export function defaultCast(d) {
  // canon characters from the SOLACE bible
  d.define('WREN',         { pitch: 1.28, rate: 1.12, color: '#9affc0', voiceHint: 'female' }); // Offline comms / handler
  d.define('TIO',          { pitch: 0.85, rate: 0.92, color: '#ff8a5b' });                      // garage boss / quest giver
  d.define('MARA',         { pitch: 0.95, rate: 0.98, color: '#7fe6ff' });                      // protagonist (you)
  d.define('CIVIC SHIELD', { pitch: 0.80, rate: 1.05, color: '#ff6b6b' });                      // private police net
  d.define('LUCIA',        { pitch: 0.90, rate: 0.92, color: '#d9a0ff', voiceHint: 'female' }); // Meridian heir
  d.define('DORIAN',       { pitch: 1.10, rate: 1.00, color: '#ffd34e' });                      // HALO antagonist
  d.define('ECHO',         { pitch: 0.70, rate: 1.00, color: '#b0b8c0' });                      // rogue AI
}

// generic city ambience lines (original, flavour)
export const PED_BARKS = [
  'Watch where you’re going!',
  'Crazy weather lately, huh?',
  'You didn’t see anything.',
  'Spare a credit?',
  'This city eats people alive.',
  'Nice ride.',
  'Keep it moving, pal.',
  'I’m late, I’m late…',
];
