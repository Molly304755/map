// Minimal procedural audio (no asset files). Everything is wrapped so a missing
// or suspended AudioContext can never throw and break the game loop.
export class Audio {
  constructor() {
    this.ok = false;
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      this.ctx = new Ctx();
      this.master = this.ctx.createGain();
      this.master.gain.value = 0.5;
      this.master.connect(this.ctx.destination);
      this.ok = true;
    } catch (e) { /* no audio available */ }
    this._engine = null;
    this._siren = null;
    this._noiseBuf = null;
  }

  resume() { if (this.ok && this.ctx.state === 'suspended') this.ctx.resume().catch(() => {}); }

  _noise() {
    if (this._noiseBuf) return this._noiseBuf;
    const len = Math.floor(this.ctx.sampleRate * 0.2);
    const b = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = b.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    this._noiseBuf = b;
    return b;
  }

  gunshot() {
    if (!this.ok) return;
    try {
      const t = this.ctx.currentTime;
      const src = this.ctx.createBufferSource();
      src.buffer = this._noise();
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.55, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      const lp = this.ctx.createBiquadFilter();
      lp.type = 'lowpass'; lp.frequency.value = 2000;
      src.connect(lp); lp.connect(g); g.connect(this.master);
      src.start(t); src.stop(t + 0.2);
    } catch (e) {}
  }

  engineOn() {
    if (!this.ok || this._engine) return;
    try {
      const o = this.ctx.createOscillator();
      o.type = 'sawtooth'; o.frequency.value = 60;
      const g = this.ctx.createGain(); g.gain.value = 0;
      o.connect(g); g.connect(this.master); o.start();
      this._engine = { o, g };
    } catch (e) {}
  }
  engineOff() {
    if (!this._engine) return;
    try { this._engine.o.stop(); } catch (e) {}
    this._engine = null;
  }
  engineUpdate(speedNorm) {
    if (!this._engine) return;
    try {
      const t = this.ctx.currentTime;
      this._engine.o.frequency.setTargetAtTime(55 + speedNorm * 230, t, 0.08);
      this._engine.g.gain.setTargetAtTime(0.04 + speedNorm * 0.13, t, 0.1);
    } catch (e) {}
  }

  sirenOn() {
    if (!this.ok || this._siren) return;
    try {
      // smooth sine wail (not a buzzy square), low-passed, gentle slow warble
      const o = this.ctx.createOscillator(); o.type = 'sine'; o.frequency.value = 600;
      const g = this.ctx.createGain(); g.gain.value = 0.032;
      const lp = this.ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1100; lp.Q.value = 0.4;
      const lfo = this.ctx.createOscillator(); lfo.type = 'sine'; lfo.frequency.value = 0.9;
      const lg = this.ctx.createGain(); lg.gain.value = 85;     // wail spans ~515–685 Hz
      lfo.connect(lg); lg.connect(o.frequency);
      o.connect(lp); lp.connect(g); g.connect(this.master);
      o.start(); lfo.start();
      this._siren = { o, lfo };
    } catch (e) {}
  }
  sirenOff() {
    if (!this._siren) return;
    try { this._siren.o.stop(); this._siren.lfo.stop(); } catch (e) {}
    this._siren = null;
  }
}
