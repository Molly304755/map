import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { CITY, COLORS } from './config.js';
import { clamp, makeRng, rangeFromRng } from './util.js';

// Procedural facade texture: light wall tinted by per-building vertex colour,
// with a grid of recessed (darker) windows, a few "lit" warm ones.
function makeWindowTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const x = c.getContext('2d');
  x.fillStyle = '#dadde2'; x.fillRect(0, 0, 128, 128);
  const cols = 4, rows = 4, pad = 10, gap = 9;
  const cw = (128 - pad * 2 - gap * (cols - 1)) / cols;
  const ch = (128 - pad * 2 - gap * (rows - 1)) / rows;
  for (let r = 0; r < rows; r++) {
    for (let cI = 0; cI < cols; cI++) {
      const px = pad + cI * (cw + gap), py = pad + r * (ch + gap);
      const lit = Math.random() < 0.18;
      x.fillStyle = lit ? '#ffe7a6' : '#5a5e66';
      x.fillRect(px, py, cw, ch);
      x.fillStyle = 'rgba(0,0,0,0.25)';
      x.fillRect(px, py, cw, 2);                 // subtle sill shadow
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

const { GRID, BLOCK, ROAD, CELL, HALF, SIDEWALK, MIN_BUILDING_H, MAX_BUILDING_H } = CITY;

// Muted urban palette for building instances.
const BUILDING_COLORS = [
  0x8d8f96, 0x9aa0a8, 0x7c828c, 0xb0a89a, 0x6f7a85,
  0xa89f93, 0x868d83, 0x9b9088, 0x7a8694, 0xb4b7bd,
];

// Four district palettes by map quadrant so each corner of the city has its
// own identity and the player can orient by colour. (NE, NW, SE, SW)
const DISTRICTS = [
  [0xb0815f, 0xa6745a, 0xc09a6e, 0x97624a, 0xb89a72], // NE — warm terracotta
  [0x6f7a85, 0x7a8694, 0x8a96a4, 0x5f6b78, 0x9aa6b4], // NW — cool steel/glass
  [0xc6c2b6, 0xb4b0a2, 0xd0ccbe, 0xa9a596, 0xbfbbae], // SE — pale concrete
  [0x5f7a6e, 0x6f8a7e, 0x547064, 0x789a8c, 0x4f6a5e], // SW — green / teal
];
const districtPalette = (cx, cz) => DISTRICTS[(cx >= 0 ? 0 : 1) + (cz >= 0 ? 0 : 2)];
const LANDMARK_I = 6, LANDMARK_J = 5;   // grid block that hosts the skyscraper

// Centre line of road index k (0..GRID) along one axis.
const gridLine = (k) => k * CELL - HALF;
// Centre of block index i (0..GRID-1) along one axis.
const blockCenter = (i) => (i + 0.5) * CELL - HALF;

export class City {
  constructor(scene) {
    this.group = new THREE.Group();
    scene.add(this.group);
    this.buildings = [];      // collision AABBs: {minX,maxX,minZ,maxZ,h}
    this.HALF = HALF;         // world extends [-HALF, +HALF]
    this.gridLines = [];      // road centre coordinates (shared for X and Z)
    for (let k = 0; k <= GRID; k++) this.gridLines.push(gridLine(k));

    const rng = makeRng(1337);
    this._buildGround();
    this._buildRoadPaint();
    this._buildBlocks(rng);
    this._finalizeBuildings();

    // A sensible on-foot spawn: standing on a road near the city centre.
    const c = this.nearestGridLine(2);
    this.spawn = new THREE.Vector3(c + ROAD * 0.2, 0, this.nearestGridLine(-6));
  }

  // ---- terrain -----------------------------------------------------------
  _buildGround() {
    const size = CITY.SPAN + CELL * 4;
    const geo = new THREE.PlaneGeometry(size, size);
    geo.rotateX(-Math.PI / 2);
    const mat = new THREE.MeshStandardMaterial({ color: COLORS.ASPHALT, roughness: 0.95, metalness: 0 });
    const ground = new THREE.Mesh(geo, mat);
    ground.position.y = 0;
    ground.receiveShadow = true;
    this.group.add(ground);
  }

  _buildRoadPaint() {
    // Dashed yellow centre lines along every road, both axes.
    const dashLen = 4, gap = 4, lineW = 0.5, y = 0.02;
    const mat = new THREE.MeshBasicMaterial({ color: COLORS.LANE });
    const segGeo = new THREE.PlaneGeometry(lineW, dashLen);
    segGeo.rotateX(-Math.PI / 2);

    const dashesPerRoad = Math.floor(CITY.SPAN / (dashLen + gap));
    const total = this.gridLines.length * dashesPerRoad * 2;
    const inst = new THREE.InstancedMesh(segGeo, mat, total);
    const m = new THREE.Matrix4();
    let n = 0;
    for (const g of this.gridLines) {
      for (let d = 0; d < dashesPerRoad; d++) {
        const along = -HALF + d * (dashLen + gap) + dashLen / 2;
        // vertical road (runs along Z): line oriented along Z
        m.makeTranslation(g, y, along);
        inst.setMatrixAt(n++, m);
        // horizontal road (runs along X): rotate segment 90°
        const m2 = new THREE.Matrix4().makeRotationY(Math.PI / 2).setPosition(along, y, g);
        inst.setMatrixAt(n++, m2);
      }
    }
    inst.count = n;
    inst.instanceMatrix.needsUpdate = true;
    this.group.add(inst);
  }

  // ---- blocks ------------------------------------------------------------
  _buildBlocks(rng) {
    this._bldGeos = [];     // {w,h,d,x,z,color} collected, instanced later
    this._sidewalkGeos = [];

    for (let i = 0; i < GRID; i++) {
      for (let j = 0; j < GRID; j++) {
        const cx = blockCenter(i), cz = blockCenter(j);
        this._sidewalkGeos.push({ x: cx, z: cz });
        if (i === LANDMARK_I && j === LANDMARK_J) { this._buildLandmark(cx, cz); continue; }
        const isPark = rng() < 0.13;
        if (isPark) this._buildPark(cx, cz, rng);
        else this._buildLot(cx, cz, rng);
      }
    }
    this._buildSidewalks();
    this._buildBuildings();
    this._buildLamps();
  }

  _buildSidewalks() {
    const geo = new THREE.BoxGeometry(BLOCK, SIDEWALK, BLOCK);
    const mat = new THREE.MeshStandardMaterial({ color: COLORS.SIDEWALK, roughness: 1 });
    const inst = new THREE.InstancedMesh(geo, mat, this._sidewalkGeos.length);
    inst.receiveShadow = true;
    const m = new THREE.Matrix4();
    this._sidewalkGeos.forEach((s, idx) => {
      m.makeTranslation(s.x, SIDEWALK / 2, s.z);
      inst.setMatrixAt(idx, m);
    });
    inst.instanceMatrix.needsUpdate = true;
    this.group.add(inst);
  }

  // Subdivide a block footprint into 1–4 building lots.
  _buildLot(cx, cz, rng) {
    const margin = 2.4;
    const inner = BLOCK - margin * 2;
    const splitX = rng() < 0.6 ? 2 : 1;
    const splitZ = rng() < 0.6 ? 2 : 1;
    const lotW = inner / splitX, lotD = inner / splitZ;
    for (let a = 0; a < splitX; a++) {
      for (let b = 0; b < splitZ; b++) {
        if (rng() < 0.12) continue; // occasional courtyard gap
        const pad = 0.8;
        const w = lotW - pad, d = lotD - pad;
        const lx = cx - inner / 2 + lotW * (a + 0.5);
        const lz = cz - inner / 2 + lotD * (b + 0.5);
        // downtown core: buildings get much taller toward the city centre
        const distN = Math.min(1, Math.hypot(cx, cz) / HALF);
        const downtown = clamp(1 - distN * 1.25, 0, 1);
        const hScale = 1 + downtown * downtown * 2.4;
        let h = rangeFromRng(rng, MIN_BUILDING_H, MAX_BUILDING_H) * (0.45 + 0.55 * rng()) * hScale;
        h = clamp(h, MIN_BUILDING_H, 185);
        const pal = districtPalette(cx, cz);
        const color = pal[Math.floor(rng() * pal.length)];
        this._bldGeos.push({ w, d, h: Math.max(MIN_BUILDING_H, h), x: lx, z: lz, color });
        this.buildings.push({ minX: lx - w / 2, maxX: lx + w / 2, minZ: lz - d / 2, maxZ: lz + d / 2, h });
      }
    }
  }

  _buildPark(cx, cz, rng) {
    const grass = new THREE.Mesh(
      new THREE.BoxGeometry(BLOCK - 1, SIDEWALK + 0.05, BLOCK - 1),
      new THREE.MeshStandardMaterial({ color: COLORS.GRASS, roughness: 1 })
    );
    grass.position.set(cx, SIDEWALK / 2 + 0.03, cz);
    grass.receiveShadow = true;
    this.group.add(grass);

    const trees = 3 + Math.floor(rng() * 4);
    for (let t = 0; t < trees; t++) {
      const tx = cx + rangeFromRng(rng, -BLOCK / 2 + 4, BLOCK / 2 - 4);
      const tz = cz + rangeFromRng(rng, -BLOCK / 2 + 4, BLOCK / 2 - 4);
      this._makeTree(tx, tz, rng);
    }
  }

  _makeTree(x, z, rng) {
    const g = new THREE.Group();
    const h = rangeFromRng(rng, 5, 9);
    const trunk = new THREE.Mesh(
      new THREE.CylinderGeometry(0.4, 0.6, h * 0.5, 6),
      new THREE.MeshStandardMaterial({ color: 0x6b4a2b, roughness: 1 })
    );
    trunk.position.y = SIDEWALK + h * 0.25;
    trunk.castShadow = true;
    const foliage = new THREE.Mesh(
      new THREE.IcosahedronGeometry(h * 0.42, 0),
      new THREE.MeshStandardMaterial({ color: 0x3f6f37, flatShading: true, roughness: 1 })
    );
    foliage.position.y = SIDEWALK + h * 0.65;
    foliage.castShadow = true;
    g.add(trunk, foliage);
    g.position.set(x, 0, z);
    this.group.add(g);
    // small collision footprint for the trunk
    this.buildings.push({ minX: x - 0.7, maxX: x + 0.7, minZ: z - 0.7, maxZ: z + 0.7, h });
  }

  // A single distinct skyscraper landmark so the player can orient by sight.
  _buildLandmark(cx, cz) {
    const w = 19, d = 19, h = 232;
    this._bldGeos.push({ w, d, h, x: cx, z: cz, color: 0x35506e });   // deep blue — unlike any district
    this.buildings.push({ minX: cx - w / 2, maxX: cx + w / 2, minZ: cz - d / 2, maxZ: cz + d / 2, h });
    const beacon = new THREE.Mesh(
      new THREE.IcosahedronGeometry(3.6, 0),
      new THREE.MeshStandardMaterial({ color: 0xffd34e, emissive: 0xffd34e, emissiveIntensity: 1.5, roughness: 0.3 })
    );
    beacon.position.set(cx, SIDEWALK + h + 4, cz);
    this.group.add(beacon);
    this.landmark = new THREE.Vector3(cx, 0, cz);   // exposed for HUD/minimap
  }

  // All buildings merged into a single mesh with a window facade texture and
  // per-building vertex colours. UVs are scaled per-face to world size so
  // windows are a consistent size regardless of building dimensions.
  _buildBuildings() {
    const TILE = 6;
    const tex = makeWindowTexture();
    const tmp = new THREE.Color();
    const geos = [];
    for (const b of this._bldGeos) {
      const g = new THREE.BoxGeometry(b.w, b.h, b.d);
      const uv = g.attributes.uv;
      // face order: +x,-x,+y,-y,+z,-z (4 verts each)
      const dims = [[b.d, b.h], [b.d, b.h], [b.w, b.d], [b.w, b.d], [b.w, b.h], [b.w, b.h]];
      for (let f = 0; f < 6; f++) {
        const [du, dv] = dims[f];
        for (let v = 0; v < 4; v++) {
          const idx = f * 4 + v;
          uv.setXY(idx, uv.getX(idx) * du / TILE, uv.getY(idx) * dv / TILE);
        }
      }
      g.translate(b.x, SIDEWALK + b.h / 2, b.z);
      const n = g.attributes.position.count;
      tmp.setHex(b.color);
      const colors = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) { colors[i * 3] = tmp.r; colors[i * 3 + 1] = tmp.g; colors[i * 3 + 2] = tmp.b; }
      g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
      geos.push(g);
    }
    const merged = mergeGeometries(geos, false);
    geos.forEach((g) => g.dispose());
    const mat = new THREE.MeshStandardMaterial({ map: tex, vertexColors: true, roughness: 0.82, metalness: 0.04 });
    const mesh = new THREE.Mesh(merged, mat);
    mesh.castShadow = true; mesh.receiveShadow = true;
    this.buildingMesh = mesh;
    this.group.add(mesh);
  }

  // Street lamps along the kerbs (instanced pole + emissive head).
  _buildLamps() {
    const poleGeo = new THREE.CylinderGeometry(0.16, 0.22, 7, 6); poleGeo.translate(0, 3.5, 0);
    const headGeo = new THREE.BoxGeometry(0.8, 0.4, 0.8); headGeo.translate(0, 7.05, 0);
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x2a2d33, roughness: 0.6, metalness: 0.6 });
    const headMat = new THREE.MeshStandardMaterial({ color: 0x554b22, emissive: 0xffd98a, emissiveIntensity: 0.9 });

    const pts = [];
    const step = 44, edge = ROAD / 2 + 1.3;
    for (let k = 1; k < GRID; k++) {
      const g = gridLine(k);
      for (let along = -HALF + 20; along < HALF - 20; along += step) {
        pts.push({ x: g - edge, z: along }, { x: g + edge, z: along });
        pts.push({ x: along, z: g - edge }, { x: along, z: g + edge });
      }
    }
    const poles = new THREE.InstancedMesh(poleGeo, poleMat, pts.length);
    const heads = new THREE.InstancedMesh(headGeo, headMat, pts.length);
    poles.castShadow = true;
    const m = new THREE.Matrix4();
    pts.forEach((p, i) => { m.makeTranslation(p.x, SIDEWALK, p.z); poles.setMatrixAt(i, m); heads.setMatrixAt(i, m); });
    poles.instanceMatrix.needsUpdate = true; heads.instanceMatrix.needsUpdate = true;
    this.lampHeads = heads;   // exposed so a day/night cycle can dim them
    this.group.add(poles, heads);
  }

  _finalizeBuildings() {
    // free the scratch arrays
    this._bldGeos = null; this._sidewalkGeos = null;
  }

  // ---- queries -----------------------------------------------------------
  nearestGridLine(v) {
    let best = this.gridLines[0], bd = Infinity;
    for (const g of this.gridLines) { const d = Math.abs(g - v); if (d < bd) { bd = d; best = g; } }
    return best;
  }

  // Resolve a circle (x,z,r) out of all building AABBs + world bounds.
  collideCircle(x, z, r) {
    let hit = false;
    for (const b of this.buildings) {
      const cx = clamp(x, b.minX, b.maxX);
      const cz = clamp(z, b.minZ, b.maxZ);
      let dx = x - cx, dz = z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        const d = Math.sqrt(d2);
        if (d < 1e-6) {
          // centre is inside the box: eject through the nearest face
          const left = x - b.minX, right = b.maxX - x, near = z - b.minZ, far = b.maxZ - z;
          const m = Math.min(left, right, near, far);
          if (m === left) x = b.minX - r;
          else if (m === right) x = b.maxX + r;
          else if (m === near) z = b.minZ - r;
          else z = b.maxZ + r;
        } else {
          const push = r - d;
          x += (dx / d) * push; z += (dz / d) * push;
        }
        hit = true;
      }
    }
    const lim = HALF - r;
    if (x < -lim) { x = -lim; hit = true; }
    if (x > lim) { x = lim; hit = true; }
    if (z < -lim) { z = -lim; hit = true; }
    if (z > lim) { z = lim; hit = true; }
    return { x, z, hit };
  }

  pointInBuilding(x, z) {
    for (const b of this.buildings) {
      if (x >= b.minX && x <= b.maxX && z >= b.minZ && z <= b.maxZ) return true;
    }
    return false;
  }

  // A random point sitting on a road lane (good for spawning vehicles/peds).
  randomRoadPoint(rng) {
    const k = 1 + Math.floor(rng() * (GRID - 1));
    const along = rangeFromRng(rng, -HALF + ROAD, HALF - ROAD);
    const laneOff = (rng() < 0.5 ? -1 : 1) * ROAD * 0.22;
    return rng() < 0.5
      ? { x: gridLine(k) + laneOff, z: along }
      : { x: along, z: gridLine(k) + laneOff };
  }

  // Road-lane spawn with a yaw aligned to the lane (right-hand traffic).
  laneSpawn(rand = Math.random) {
    const inner = this.gridLines.length - 2;        // skip perimeter roads
    const k = 1 + Math.floor(rand() * inner);
    const g = this.gridLines[k];
    const along = (rand() * 2 - 1) * (HALF - ROAD * 1.5);
    const right = rand() < 0.5;
    const laneOff = (right ? 1 : -1) * ROAD * 0.24;
    if (rand() < 0.5) {
      // vertical road (drive along Z)
      return { x: g + laneOff, z: along, yaw: right ? Math.PI : 0 };
    }
    // horizontal road (drive along X)
    return { x: along, z: g + laneOff, yaw: right ? -Math.PI / 2 : Math.PI / 2 };
  }
}
