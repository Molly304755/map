@echo off
title Liberty Drive 3D  -  close this window to stop the game
rem ============================================================
rem  LIBERTY DRIVE 3D  -  one-click launcher
rem  Starts the local game server and opens the game in your browser.
rem  Close this window to stop the game.
rem ============================================================
setlocal
set "NODEDIR=%LOCALAPPDATA%\node-portable\node-v24.18.0-win-x64"
cd /d "%~dp0"

if not exist "%NODEDIR%\node.exe" (
  echo Could not find the portable Node at:
  echo   %NODEDIR%
  echo Please re-run setup or tell Claude to reinstall Node.
  pause
  exit /b 1
)

echo.
echo    LIBERTY DRIVE 3D
echo    Starting the game server on http://localhost:5173 ...
echo    Your browser will open in a few seconds.
echo    Keep this window open while you play; close it to stop the game.
echo.

rem open the browser a moment after the server boots (runs in the background)
start "" /b cmd /c "timeout /t 3 >nul & start http://localhost:5173"

"%NODEDIR%\node.exe" "node_modules\vite\bin\vite.js" --port 5173 --strictPort
