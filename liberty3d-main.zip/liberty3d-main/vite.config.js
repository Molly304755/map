import { defineConfig } from 'vite';

// Static, dependency-light config. base './' keeps the production build portable
// (works from file:// or any sub-path), and we open the browser on dev start.
export default defineConfig({
  base: './',
  server: {
    host: true,
    open: false,
    // honour the PORT env var (the preview tool assigns one via autoPort);
    // falls back to 5173 for `npm run dev` / play.bat.
    port: process.env.PORT ? Number(process.env.PORT) : 5173,
  },
  build: {
    target: 'es2020',
    outDir: 'dist',
  },
});
