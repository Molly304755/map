# SOLACE — Asset Pipeline (Free / AI)

> Companion to **BIBLE.md**. How to source free or AI-generated **meshes, textures, sounds, music, and voice** and bring them into the Three.js + Vite build. Procedural-first, CC0 second, AI third.

---

I have verified the key facts. Writing the section now.

# Asset Pipeline (Free / AI)

This is the concrete plan for sourcing and integrating art and audio for **LIBERTY DRIVE** (proposed original title: **GRIDLOCK CITY** or **FREEHAVEN**) using only free, free-tier, or self-hostable AI tools — verified June 2026. The current build uses box avatars, flat-shaded blocks, and procedural juice. This pipeline replaces those incrementally without spending money and without legal risk to original IP.

## Strategy: Procedural-first, CC0 second, AI third

| Tier | When to use | Why |
| --- | --- | --- |
| **1. Procedural** | Roads, buildings, props that are just boxes/extrusions; tyre smoke; skid marks; muzzle flashes; jsfxr SFX | Zero download weight, zero license risk, infinitely reskinnable, already your engine's strength. Keep it. |
| **2. CC0** (Kenney, Quaternius, Poly Haven, ambientCG, Freesound CC0) | Hero vehicles, peds, weapons, signature textures, ambience, music | Public-domain — no attribution, no per-use limits, redistributable, future-proof. This is the backbone. |
| **3. AI** (Meshy/Tripo free tier, Piper TTS) | One-off bespoke props you can't find CC0; runtime/baked voice barks | Powerful but carries the heaviest license gotchas (see flags). Use last, sparingly, and **never** for anything you'd ship without checking terms. |

Rationale: every tier up the chain adds download size, build complexity, and legal surface area. A browser sandbox lives or dies on bundle size and clear licensing. Stay procedural where the look is already "stylized low-poly," reach for CC0 when you need real meshes, and treat AI as a gap-filler — not the foundation.

---

## 3D Models

| Source | License | Cost / limits | Into Three.js + Vite |
| --- | --- | --- | --- |
| [Kenney](https://kenney.nl/) | **CC0** | Free, 40k+ assets, no attribution | "City Kit", "Car Kit", "Blaster Kit" ship as glTF/OBJ. Drop `.glb` in `public/models/`, load via `GLTFLoader`. |
| [Quaternius](https://quaternius.com/) | **CC0** | Free, animated characters/vehicles | "Ultimate Modular Men", "Animated Woman/Human" packs — perfect to replace box peds. glTF with baked skeletal anims. |
| [Poly Pizza](https://poly.pizza/) | Per-model (mostly **CC0**, some **CC-BY** — check each) | Free, no login | Aggregator hosting Quaternius/Kenney + others. Direct `.glb` download. **Verify each model's license badge** before use. |
| [Poly Haven](https://polyhaven.com/models) | **CC0** | Free, fewer models (props/HDRIs) | Great for HDRI skydome lighting + a few props. |
| [Meshy](https://www.meshy.ai/pricing) (AI text/image→3D) | Free plan: **CC BY 4.0** (must credit "Meshy") | 100 credits/month, resets monthly UTC | Export `.glb`, re-topologize/decimate in Blender, then `GLTFLoader`. |
| [Tripo](https://www.tripo3d.ai/) (AI) | Free tier reported **non-commercial** | ~300 credits/mo free | Same workflow; **non-commercial flag — do not ship free-tier output**. |

**Gotchas:** Meshy free output is CC-BY (attribution to *Meshy* required even on a free game) and Tripo free is non-commercial — both differ from Meshy *paid* (full ownership). AI meshes are also high-poly/messy-topology and need Blender cleanup before they fit a low-poly browser game. Prefer CC0 packs; reach for AI only for a unique prop you genuinely can't find.

**Pipeline into the engine (one-time setup):**
```js
// src/loaders.js
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';
import { KTX2Loader } from 'three/addons/loaders/KTX2Loader.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';

const draco = new DRACOLoader().setDecoderPath('/draco/');        // copy decoder from three/examples/jsm/libs/draco
const ktx2  = new KTX2Loader().setTranscoderPath('/basis/').detectSupport(renderer);

export const gltfLoader = new GLTFLoader()
  .setDRACOLoader(draco)
  .setKTX2Loader(ktx2)
  .setMeshoptDecoder(MeshoptDecoder);
```
- **File layout:** `public/models/*.glb`, `public/draco/`, `public/basis/`. Files in `public/` are served as-is by Vite — reference with absolute paths (`/models/car_sedan.glb`).
- **Compress before shipping:** run assets through `gltf-transform` (`npx @gltf-transform/cli optimize in.glb out.glb --compress draco --texture-compress ktx2`). Draco shrinks geometry; KTX2/Basis shrinks textures and lets the GPU keep them compressed. This is the single biggest win for a browser game's load time.

---

## Textures / Materials

| Source | License | Cost / limits | Into Three.js + Vite |
| --- | --- | --- | --- |
| [ambientCG](https://ambientcg.com/) | **CC0** | Free, 2000+ PBR sets up to 8K | Download albedo/normal/roughness/metallic/height. Use 1K–2K for web. |
| [Poly Haven](https://polyhaven.com/textures) | **CC0** | Free, 4K/8K PBR + HDRIs | Best HDRIs for your day/night sky + image-based lighting. |
| [cc0-textures / ShareTextures](https://www.sharetextures.com/) | **CC0** | Free | Backup library. |

**Gotchas:** none license-wise (all CC0). The real constraint is **size** — never ship 8K. Downscale to 1K (props) / 2K (roads, hero surfaces), and convert to **KTX2/Basis** with `gltf-transform` or the `basisu` CLI so the GPU stores them compressed.

**Loading:**
```js
import { TextureLoader, SRGBColorSpace, RepeatWrapping } from 'three';
const tex = new TextureLoader().load('/textures/asphalt_diff.jpg');
tex.colorSpace = SRGBColorSpace;      // diffuse/albedo only — NOT normal/roughness
tex.wrapS = tex.wrapT = RepeatWrapping;
tex.repeat.set(8, 8);
const mat = new THREE.MeshStandardMaterial({ map: tex, normalMap: nrm, roughnessMap: rgh });
```
Keep normal/roughness/metalness maps in **linear** color space (do not set `SRGBColorSpace`). Store source maps in `public/textures/`.

---

## SFX

| Source | License | Cost / limits | Into Three.js + Vite |
| --- | --- | --- | --- |
| [jsfxr](https://sfxr.me/) | **MIT** (tool) / your output is yours | Free, in-browser retro generator + JS lib | Generate engine revs, pickups, UI blips. Can play at runtime via the lib, or export `.wav`. Procedural = zero bytes shipped. |
| [Freesound](https://freesound.org/browse/tags/cc0/) | Per-sound; **filter to CC0** | Free account | Filter `License: Creative Commons 0`. CC-BY clips exist too — track attribution if you use them. |
| [Sonniss GameAudioGDC](https://sonniss.com/gameaudiogdc/) | Royalty-free, no attribution, commercial OK | Free annual multi-GB packs | Pro-grade Foley/weapons/vehicles. |
| [Pixabay SFX](https://pixabay.com/sound-effects/) | Pixabay Content License (free, commercial) | Free | Convenient backup; read the license (no resale-as-pack). |

**Gotchas:** Freesound is **mixed-license** — a single careless CC-BY or CC-BY-NC grab poisons your "no attribution needed" goal. Always set the CC0 filter, or log attributions immediately.

**Loading (positional audio for engines/gunfire):**
```js
import { AudioListener, PositionalAudio, AudioLoader } from 'three';
const listener = new AudioListener(); camera.add(listener);
new AudioLoader().load('/audio/engine_loop.ogg', buf => {
  const snd = new PositionalAudio(listener);
  snd.setBuffer(buf); snd.setLoop(true); snd.setRefDistance(8);
  carMesh.add(snd); snd.play();   // pans/attenuates from the car's position
});
```
Use `Audio` (non-positional) for music/UI. Ship `.ogg` (smaller, well-supported) in `public/audio/`. **Browsers block audio until first user gesture** — start/resume on the first keypress or click.

---

## Music

| Source | License | Cost / limits | Notes |
| --- | --- | --- | --- |
| [Incompetech / Kevin MacLeod](https://incompetech.com/music/royalty-free/) | **CC-BY 4.0** (or $30 flat-fee to skip credit) | Free w/ attribution | Huge catalog; must credit "Kevin MacLeod (incompetech.com)". |
| [Free Music Archive](https://freemusicarchive.org/) | Per-track (CC0 / CC-BY / CC-BY-SA) | Free | **Filter to CC0** for zero-attribution; avoid `-SA`/`-ND`. |
| [Pixabay Music](https://pixabay.com/music/) | Pixabay Content License | Free, commercial | No attribution required; convenient. |
| [OpenGameArt](https://opengameart.org/) | Per-asset (CC0 common) | Free | Game-tailored loops; check each license. |

**Gotchas:** Avoid **-SA** (ShareAlike — could force your code/assets open) and **-ND** (NoDerivs — can't loop/edit). CC0 or plain CC-BY only. Incompetech is CC-BY, not CC0 — credit it.

Load music as a streamed/decoded `Audio` (not positional), same `AudioLoader` flow; loop radio stations by swapping buffers. Keep tracks in `public/audio/music/` as `.ogg` at ~128kbps to control size.

---

## Voice / Dialogue

| Option | License | Cost / limits | Into Three.js + Vite |
| --- | --- | --- | --- |
| [Web Speech API `SpeechSynthesis`](https://developer.mozilla.org/en-US/docs/Web/API/SpeechSynthesis) | Browser built-in | Free, runtime, zero bytes | `speechSynthesis.speak(new SpeechSynthesisUtterance("Get in!"))`. Voices are OS-dependent and vary per machine. |
| [Piper TTS](https://github.com/OHF-Voice/piper1-gpl) | **GPL-3.0** (active fork; old `rhasspy/piper` was MIT, archived Oct 2025) | Free, self-hosted/offline | Generate `.ogg`/`.wav` barks **at build time**, ship as audio files. The GPL covers Piper the *program* — generated audio output is yours to use. |
| [OfflineTTS](https://offlinetts.com/) (Piper in-browser via WebGPU/WASM) | Per-model | Free | Browser-side neural TTS if you want dynamic voice without OS variance — heavier download. |

**Recommendation (best of both):** Use **Web Speech API** for cheap, dynamic, zero-byte runtime barks (police callouts, ped reactions) — accept that voices differ per user. For consistent, characterful **named-NPC mission lines**, pre-render with **Piper** offline and ship the `.ogg` files (load via `AudioLoader`). This keeps your build deterministic while staying 100% free and offline.

```js
// Runtime barks — no asset, no license, instant
function bark(text) {
  const u = new SpeechSynthesisUtterance(text);
  u.rate = 1.05; u.pitch = 0.9;
  speechSynthesis.speak(u);   // requires a prior user gesture in some browsers
}
```
**Gotchas:** `SpeechSynthesis` quality/voice list is unpredictable across OSes and may need a `voiceschanged` event before voices are available. Piper is GPL-3.0 — fine as an offline tool, but don't bundle Piper's *code* into your game unless you intend to comply with GPL; ship only its audio output.

---

## Step-by-step: integrate the FIRST real model + texture + sound + voice line

1. **Set up loaders once.** Add `src/loaders.js` (above). Copy `node_modules/three/examples/jsm/libs/draco/` → `public/draco/` and the Basis transcoder → `public/basis/`.
2. **Get a CC0 car.** Download a vehicle `.glb` from [Kenney's Car Kit](https://kenney.nl/assets/car-kit) (CC0). Save raw to `assets-src/`.
3. **Get a CC0 road texture.** Grab an asphalt PBR set from [ambientCG](https://ambientcg.com/), downscale to 2K.
4. **Compress.** `npx @gltf-transform/cli optimize assets-src/car.glb public/models/car_sedan.glb --compress draco --texture-compress ktx2`. Convert the road texture to KTX2.
5. **Swap the box vehicle.** In your sedan class spawn, replace the `BoxGeometry` mesh with `gltfLoader.load('/models/car_sedan.glb', g => mesh.add(g.scene))`. Scale/orient to match your existing collision circle; keep physics untouched (visual swap only).
6. **Apply the road texture** to your ground/road material as `map` + `normalMap` (RepeatWrapping, sRGB on albedo only).
7. **Add an engine SFX.** Generate an engine loop in [jsfxr](https://sfxr.me/) (or grab a CC0 engine from Freesound), export `.ogg` to `public/audio/`, attach as `PositionalAudio` to the car. Resume audio on first keypress.
8. **Add one voice line.** Wire `bark("Hey — that's my car!")` to the carjack event via Web Speech API. (Optional: pre-render the line with Piper and play the `.ogg` instead for consistency.)
9. **Verify** headless/in-browser that the car renders, road tiles, engine loops, and the bark fires on carjack.

## Attribution / credits policy

- **Default to CC0** everywhere — it needs no credit and is redistributable. This keeps the legal surface minimal.
- **Maintain `CREDITS.md`** in the repo and an in-game **Credits** screen listing every non-CC0 asset: title, author, source URL, license. Required for any **CC-BY** asset (Incompetech music, Poly Pizza CC-BY models, Meshy free-tier output → credit "Meshy", Freesound CC-BY sounds).
- **Track as you go:** add a line to `CREDITS.md` *the moment* you download a non-CC0 asset — never reconstruct attributions later.
- **Hard bans:** no `-SA` / `-ND` Creative Commons assets; no AI free-tier output flagged non-commercial (e.g. Tripo free); no real-world brands, logos, car marques, or trademarked names — keep all city/brand/faction/character names original.
- **Keep a `licenses/` folder** with a copy of each license text and the original download URL, so provenance is auditable before any public release.

**Verified sources:** [Kenney](https://kenney.nl/) · [Quaternius](https://quaternius.com/) · [Poly Pizza](https://poly.pizza/) · [Poly Haven license](https://polyhaven.com/license) · [ambientCG](https://ambientcg.com/) · [Freesound CC0](https://freesound.org/browse/tags/cc0/) · [jsfxr](https://sfxr.me/) · [Sonniss GameAudioGDC](https://sonniss.com/gameaudiogdc/) · [Incompetech licenses](https://incompetech.com/music/royalty-free/licenses/) · [Piper (GPL fork)](https://github.com/OHF-Voice/piper1-gpl) · [MDN SpeechSynthesis](https://developer.mozilla.org/en-US/docs/Web/API/SpeechSynthesis) · [Meshy pricing/license](https://www.meshy.ai/pricing) · [three.js GLTFLoader docs](https://threejs.org/docs/#examples/en/loaders/GLTFLoader)
