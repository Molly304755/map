# SOLACE — Project Bible
*"No City Sleeps Clean"*

> **The single source of truth** for this game (working title "Liberty Drive" → **SOLACE**). Authored 2026-06-26 by a multi-agent design pass; keep it updated as the build evolves.
> Companion docs: **ASSET_PIPELINE.md** (how to source free / AI assets) · **../PROGRESS.md** (live per-cycle tracker & scores).
>
> **How to use this:** every work cycle, open PROGRESS.md, pick the highest-leverage gap that moves us toward the *Definition of Convincing* (bottom of this file), implement the smallest meaningful change, verify it in-browser, and log it. Stay on the rails.

---

# LIBERTY DRIVE → **NEON ATTRITION: SOLACE CITY**

> Final game name: **SOLACE** (subtitle: *No City Sleeps Clean*). "Solace City" is the setting; "SOLACE" is the marquee title — short, ironic, brandable.

---

## Setting & Tone

**Solace City**, 2031. A mid-sized coastal metro that sold itself to the highest bidder: a smart-city "renewal" pitched as utopia, delivered as surveillance-for-rent. Self-driving fleets, gig-work everything, a municipal app that fines you for jaywalking and upsells you bail. The rich got frictionless; everyone else got a subscription.

Tone: **grounded near-future satire** — deadpan, neon-soaked, mean about institutions, warm about people. Think corporate-dystopia comedy with real stakes, not fantasy and not gritty-grimdark. Every brand is a parody of a *type* (rideshare, fintech, wellness, private police). The humor is in the fine print; the heart is in the underclass scraping by. Violence is arcade-stylized, consequences are personal.

The city map already exists — 8x8 grid, 4 colour districts + downtown core + one landmark tower. Below, each is named, themed, and given hooks.

---

## City Geography

| Build region | District name | Vibe & palette | Identity | Key locations |
|---|---|---|---|---|
| **NW** (cool steel/glass) | **Verdance Heights** | Cold blue glass, manicured, drone-patrolled | Corporate HQs, new money, the "renewal" showroom | **HALO Tower lobby**, Renewal Welcome Center, rooftop valet, fintech campus |
| **NE** (warm terracotta) | **Solano Row** | Sun-baked brick, markets, string lights | Oldest neighborhood, immigrant heart, resisting eviction | Mercado Solano, the Row garages, community radio shack, taco-truck plaza |
| **SE** (pale concrete) | **The Spillway** | Bleached concrete, overpasses, drainage canals | Industrial flats, docks, where the city dumps what it hates | Impound yard, container docks, abandoned transit depot, fight pit |
| **SW** (green/teal) | **Greenline** | Overgrown teal parks, reclaimed lots | Squatter-artist belt, off-grid, mutual-aid | The Commons (squat), pirate-radio loft, skate basin, urban farm |
| **Center** | **The Ledger** (downtown core) | Mixed mid-rise, traffic, signage | Financial/civic gut: courts, banks, the muni-app data center | City Hall annex, Solace Bank vault, data center, central interchange |
| **Landmark** | **HALO Tower** | The single skyscraper; rotating beacon | HQ of HALO Systems, the smart-city overlord | Penthouse server core, sky-bridge, beacon roof |

---

## Factions

**HALO Systems** *(authority / antagonist)* — The smart-city contractor that privatized Solace's infrastructure. Goal: total "frictionless" control — every street a toll, every citizen a data stream. Owns the muni-app and the surveillance grid. Polished, smiling, ruthless.

**Civic Shield** *(private police)* — HALO's outsourced enforcement, replacing the bankrupt PD. They are the in-game "police/wanted" force. Goal: protect HALO assets, bill the city per arrest. Corrupt, over-armed, quota-driven.

**The Offline** *(protagonist faction / resistance)* — A loose crew of hackers, mechanics, and evicted locals who live "off the grid," jamming the surveillance net. Goal: expose HALO and keep the old neighborhoods breathing. Scrappy, principled, broke.

**The Meridian Syndicate** *(organized crime)* — Old-money smuggling family that ran Solace before HALO. Goal: reclaim the rackets HALO automated them out of. Pragmatic, dangerous, will deal with anyone. Frenemies with The Offline (shared enemy, opposite ethics).

**Relationships:** HALO + Civic Shield are partners. The Offline vs HALO is the core war. Meridian vs HALO is a turf war. The Offline + Meridian = uneasy marriage of convenience that frays in Act 3.

---

## Characters

**PROTAGONIST — Mara "Mile" Okonkwo** — Ex-fleet driver for HALO's rideshare arm, fired and debt-flagged after refusing to run a dirty route; now wheelman for The Offline. *Role:* player character. *Voice:* mid-low, dry, unhurried; faint Lagos-London lilt; gets clipped and fast when adrenaline hits.

**Tomás "Tio" Reyes** — Runs the Row garages; surrogate uncle, fixes your cars and your head. *Role:* hub/quest-giver, upgrades. *Voice:* warm, gravelly, slow Tejano cadence; laughs mid-sentence.

**Wren** — Teenage signal-jammer genius of The Offline; voice in your ear. *Role:* mission handler/comms. *Voice:* fast, bright, sardonic; American Gen-Z upspeak, talks over herself.

**Dorian Vale** — HALO's smiling VP of "Urban Happiness." *Role:* primary antagonist. *Voice:* smooth, mid-high, TED-talk warm with a cold floor; over-enunciated.

**Captain Brick Halloran** — Civic Shield commander who has a personal vendetta against Mara. *Role:* recurring chase/combat boss. *Voice:* loud, barked, gravel-bottom American; relishes threats.

**Lucia Meridian** — Heir to the Meridian Syndicate; elegant, lethal, offers seductive shortcuts. *Role:* morally-grey ally/handler. *Voice:* low, measured, velvet menace; transatlantic polish.

**Echo** — A rogue HALO AI fragment Wren smuggles out; deadpan moral wildcard. *Role:* late-game wildcard/comms. *Voice:* flat, synthetic, perfectly calm; subtle pitch-bend.

---

## Main Story

Each mission maps to one existing type: **DELIVER / CHASE / EVADE / COLLECT / ELIMINATE**.

### Prologue
**P1 — "Dead Mileage"** · *Giver: Wren* · Your last HALO ride goes wrong; ditch the flagged car and reach the Row before Civic Shield pings you. · **EVADE** · *Reward: $500 + car stashed at Tio's*

### Act 1 — Off the Grid
**1 — "Welcome Package"** · *Tio* · Run untracked parts across Solano Row to wire up The Offline's safehouse. · **DELIVER** · *$800*
**2 — "Static"** · *Wren* · Tail a Civic Shield patrol to learn their new patrol-AI routes — don't get spotted. · **CHASE** · *$1,000 + minimap intel*
**3 — "Yard Sale"** · *Tio* · Raid the Spillway impound for confiscated Offline gear before it's crushed. · **COLLECT** · *$1,200 + free repair tier*

### Act 2 — Friction
**4 — "Velvet Offer"** · *Lucia* · Escort a Meridian shipment through The Ledger; Civic Shield is hunting the convoy. · **DELIVER** · *$2,000 + Meridian contact*
**5 — "Quota"** · *Wren* · Captain Halloran is sweeping Greenline for arrests — draw him off the Commons and lose him. · **EVADE** · *$2,200 + Commons safe*
**6 — "Skim"** · *Lucia* · Intercept HALO's data couriers across downtown and collect their drives before they sync. · **COLLECT** · *$2,800 + decryption key*
**7 — "Bagman"** · *Tio* · A Shield lieutenant is selling out the Row; run him down before he reaches HALO. · **CHASE** · *$3,000*

### Act 3 — No City Sleeps Clean
**8 — "Severance"** · *Echo* · Eliminate Captain Halloran's strike team when they storm the Row garages. · **ELIMINATE** · *$4,000 + HALO Tower access*
**9 — "Doublecross"** · *Lucia → Wren* · Lucia's "extraction" is a trap; flee the Meridian ambush through the Spillway. · **EVADE** · *$4,500 + truth about Meridian*
**10 — "Frictionless"** · *Echo* · Storm HALO Tower and eliminate Dorian Vale at the penthouse server core. · **ELIMINATE** · *$10,000 + city's surveillance grid goes dark (ending)*

---

## Side Activities

- **Ghost Routes** — Time-trial deliveries on "deprecated" roads; beat HALO's old fleet records for cash. *(DELIVER reuse)*
- **Jammer Runs** — Reach and smash surveillance nodes across a district, then evade the heat you trigger. *(COLLECT + EVADE reuse)*
- **Pit Nights** — The Spillway fight pit: bare-knuckle / weapon brawls for escalating purses. *(ELIMINATE reuse)*
- **Repo Work** — Civic Shield impounded a local's car; steal it back and lose the tail. *(CHASE/EVADE reuse)*
- **Mutual Aid** — Collect supply drops around Greenline/Solano and deliver to neighbors for rep + discounts. *(COLLECT + DELIVER reuse)*

---

## Radio

- **KARMA 98.6 — "Frequency Free"** — Pirate station from the Greenline loft; lo-fi, dub, protest hip-hop, between-song rants against HALO.
- **VERTEX FM** — HALO's official "wellness" channel; sterile synth-pop, soothing corporate ads, passive-aggressive traffic updates.
- **Mercado Sonido** — Solano Row community radio; cumbia, reggaeton, norteño, live market chatter.
- **NIGHTLEDGER** — After-dark downtown station; synthwave, dark electro, deadpan noir DJ for late drives.


---


I now have a thorough grounding in the actual code. Writing the bible against the real modules, functions, and constants.

# Gameplay & Systems Bible

> Working title **LIBERTY DRIVE** → proposed original name: **OFFRAMP** (alt: *Asphalt Republic*, *Neon Precinct*, *Gridlock*). "Offramp" reads as both the literal exits of a city grid and the player's life going off the rails. Used below as the project name.

---

## 1. Core Gameplay Loop

The moment-to-moment loop is a tight **earn → spend → escalate → escape** cycle running on top of a living city (traffic AI, wandering crowds, day/night, weather), all driven from `update(dt)` in `main.js`.

```
        ┌─────────────────────────────────────────────────────────┐
        │                    EXPLORE THE CITY                      │
        │   walk / carjack (F) / drive · 8×8 grid · 4 districts     │
        └───────────────┬──────────────────────────┬──────────────┘
                        │                          │
              ┌─────────▼─────────┐      ┌─────────▼─────────┐
              │   EARN (income)   │      │  CAUSE CHAOS      │
              │ • JOB marker →    │      │ • shoot / run     │
              │   random mission  │      │   over peds       │
              │ • world pickups   │      │ • addWanted()     │
              │ • "shook the cops"│      └─────────┬─────────┘
              │   survival bonus  │                │
              └─────────┬─────────┘      ┌─────────▼─────────┐
                        │                │  HEAT / WANTED     │
              ┌─────────▼─────────┐      │ police spawn,      │
              │   SPEND (shop)    │      │ chase, shoot       │
              │ hold E in ring:   │      └─────────┬─────────┘
              │ ammo, armor, heal,│                │
              │ weapons, upgrades │      ┌─────────▼─────────┐
              └─────────┬─────────┘      │ ESCAPE or DIE      │
                        │                │ decay (7s no crime)│
                        └────────────────┤ → survival payout  │
                                         │ death → WASTED,    │
                                         │ -$100, respawn     │
                                         └────────────────────┘
```

**The hook the build is missing:** there is currently no *reason to leave the loop* — no narrative spine, no ownership, no map unveiling. The loop is solid arcade churn but flat. See [Top 10 Gaps](#10-top-10-gameplay-gaps-to-close-next).

---

## 2. Full Control Scheme

Bindings are resolved through `input.js` (`isDown`, `axisX/axisY`, `wasPressed`, `consumeMouseClick`, `input.mouseDown`). `axisX/axisY` are WASD/arrow composites.

### On-foot (`updateOnFoot`)
| Input | Action | Source |
|---|---|---|
| `W A S D` / Arrows | Move (camera-relative) | `axisX/axisY` → `dir` |
| `Shift` (L/R) | Run (`PLAYER.RUN` 14.5 vs `WALK` 7.5) | `isDown('ShiftLeft/Right')` |
| `Space` | Jump (`PLAYER.JUMP` 16) | `wasPressed('Space')` |
| Mouse move | Look / orbit camera | `CameraRig` |
| **Hold LMB** | Aim (locks body yaw to camera) | `input.mouseDown` → `player.aiming` |
| LMB | Fire (see combat) | `consumeMouseClick` / `mouseDown` |
| `F` | Enter nearest vehicle (≤7 m) | `handleEnterExit` |

### Driving (`updateDriving`)
| Input | Action |
|---|---|
| `W` / `S` | Throttle / brake-reverse (`axisY`) |
| `A` / `D` | Steer (`axisX`) |
| `Space` | **Handbrake** (drops grip 7.0 → 1.6, raises steer rate ×1.3) |
| `Shift` | Boost (engine ×1.5, top ×1.35, grip ×0.75) |
| `F` | Exit (ejects to driver's left, collision-checked) |
| Mouse | Free look (camera dampens back to `car.yaw`) |

### Combat
| Input | Action |
|---|---|
| Hold LMB | Auto weapons fire continuously (`w.auto`); semi-auto fire on click edge |
| `1` / `2` / `3` | Select pistol / SMG / shotgun (must be in `state.unlocked`) |
| — | No reload, no melee, no grenades, **no in-car shooting** (`tryShoot` returns if `player.inCar`) |

### UI / Meta
| Input | Action |
|---|---|
| `Hold E` (0.5 s in shop ring) | Open LOADOUT shop |
| `Esc` / `E` (shop open) | Close shop |
| Click "PLAY" | `beginGame()` (pointer lock) |
| `M` | Full-screen map *(per build notes; wire in `hud`)* |

---

## 3. Systems Table

Legend: **✓** built & in `update()` · **◐** partial/stubbed · **☐** planned.

| System | State | One-line spec |
|---|:--:|---|
| Renderer / scene / sky dome | ✓ | WebGL2, ACES tonemap, gradient shader sky, fog, single shadow-casting sun |
| City grid | ✓ | 8×8 blocks (`CITY.CELL`=62), buildings, roads, sidewalks; `collideCircle` AABB |
| Districts & landmark | ✓ | 4 colour-coded zones + downtown core + one skyscraper (cosmetic only) |
| Arcade driving (drift) | ✓ | Player gets world-space grip/drift model; weight-transfer lean (`_driveDrift`) |
| Vehicle classes | ✓ | 5 classes as multipliers on `VEHICLE` base (sedan/sports/muscle/van/compact) |
| Traffic AI | ✓ | Cardinal road-follow, `cruise` speed, intersection turns (`updateAI`) |
| Carjack enter/exit | ✓ | `F` within 7 m, hides player mesh, collision-safe ejection |
| Pedestrian crowd | ✓ | ~22 peds, wander/panic/flee, HP, ragdoll-lite death, run-overs (`npc.js`) |
| Missions (5 types) | ✓ | Data-driven `MISSIONS[]` state machines from one JOB marker |
| Wanted / heat | ◐ | `addWanted`/decay works; **no line-of-sight, no evasion radius** (see §6) |
| Police spawn/chase/shoot | ✓ | `maintainPolice`/`updatePolice`; ram + ranged dmg scaled by stars |
| Weapons (3) | ✓ | Pistol/SMG/shotgun via `WEAPONS[]`; hitscan `raycastTargets` |
| Combat damage model | ✓ | Per-target dmg (`dmgPed`/`dmgCop`), spread, pellets, range |
| Economy | ✓ | `state.money`; mission payouts, survival bonus, pickups; sinks = shop, hospital |
| LOADOUT shop | ✓ | 7 items: ammo/armor/heal/SMG/shotgun/+speed/+plating (`SHOP_ITEMS`) |
| Player upgrades | ◐ | `topSpeedBonus` (flat +14) & `armorMax` (→150); no handling/health upgrades |
| World pickups | ✓ | Health/SMG/shotgun crates, 12 s respawn-elsewhere (`updatePickups`) |
| Health / armor / death | ✓ | Armor soaks first; `WASTED` → 3 s → respawn, -$100 |
| Minimap + blips | ✓ | `hud.drawMinimap` with colour-coded actor/marker blips |
| Full-screen map (M) | ◐ | In build notes; verify wiring in `hud` |
| HUD | ✓ | Health/armor/money/stars/weapon/speedo/mission/toasts/prompts |
| Day/night cycle | ✓ | `updateDayNight`, ~3.5 min day, sun arc + sky/fog lerp |
| Weather (rain) | ✓ | `Weather.update` modulates sun/hemi/fog |
| Effects / juice | ✓ | Muzzle, tracers, blood, explosions, tyre smoke, skid marks, screen shake |
| Audio | ◐ | Engine/siren/gunshot procedural; no music, footsteps, ambience |
| Save / persistence | ☐ | No localStorage; all progress lost on reload |
| Vehicle damage/health | ☐ | Player car is indestructible (only mission/police cars have `hp`) |
| Story / characters / dialogue | ☐ | No named characters, cutscenes, or meshes beyond box avatars |
| Shops: garage / property | ☐ | No vehicle ownership, garages, or safehouses |

---

## 4. Mission Framework

### How a mission is authored
Every mission is one entry in the `MISSIONS[]` array in `main.js` — a plain object that is a small **state machine**:

```js
{ name: 'CHASE', pay: [320, 520], limit: 50,
  start(c)        { /* spawn actors onto ctx `c`; set c.blipAt */ },
  update(dt, c)   { /* return 'active' | 'done' | 'fail'; write hud.setMission(...) */ },
  cleanup(c)      { /* tear down spawned actors */ } }
```

- **One marker, random job.** The yellow `marker` is the JOB start. `updateMission` checks distance; within 6 m → `startRandomJob()` picks `MISSIONS[random]`, builds a `ctx` (`job.active`), sets `job.t = def.limit`, rolls `job.payout` from the `pay` range, calls `def.start(ctx)`, hides the marker.
- **Per-frame.** `job.t -= dt`; `def.update(dt, ctx)` runs in a `try/catch` (a throw = `'fail'`). `ctx.blipAt` (a Vector3) becomes the pink minimap blip.
- **Success / fail.** `'done'` → pay out `job.payout`, toast, `cleanup`, re-place marker. `'fail'` (timer ≤ 0, target lost >230 m, death, etc.) → toast, `cleanup`, re-place marker, **no pay**.
- **Rewards.** Pure cash from the `pay[min,max]` band; richer types pay more (`ELIMINATE` 380–600 > `DELIVER` 220–360). No XP, items, or reputation yet.

### The 5 shipped types
| Type | Pay | Limit | Win condition |
|---|---|---|---|
| DELIVER | 220–360 | 55 s | Reach dropoff < 6 m |
| CHASE | 320–520 | 50 s | Be in a car within 6 m of fleeing target |
| EVADE | 300–480 | 30 s | Hit 2★, then survive 30 s still wanted & alive |
| COLLECT | 260–420 | 55 s | Grab 5 crates |
| ELIMINATE | 380–600 | 60 s | Destroy target car (hp ≤ 0) |

### Adding a new mission type (worked example — `PROTECT` / escort)
1. **Append to `MISSIONS[]`** with `name`, `pay`, `limit`.
2. **`start(c)`** — spawn a VIP car with `spawnMissionCar(60)`, store on `c.car`, pick a destination via `roadAwayFromPlayer(80)` into `c.dest`, set `c.car.hp = 80`, `c.blipAt = c.car.pos`.
3. **`update(dt, c)`** — drive the VIP toward `c.dest` (reuse `fleeStep` logic but steer *toward* instead of away, or add a `seekStep`), spawn ambusher police/`mission` cars over time, `return 'fail'` if `c.car.hp <= 0` or `job.t <= 0`, `'done'` when VIP reaches `c.dest`. Push status via `hud.setMission(...)`.
4. **`cleanup(c)`** — `removeMissionCar(c.car)`.
That's the entire contract — no other file changes. The helpers `spawnMissionCar`, `removeMissionCar`, `roadAwayFromPlayer`, `playerNear`, `distXZ`, and `fleeStep` are the authoring toolkit.

> **Refactor note:** `MISSIONS[]` and its helpers should move to `missions.js` taking a `ctx` of injected deps (`{scene, city, player, cars, effects, hud}`) so `main.js` stops being a 850-line god module.

---

## 5. Progression & Economy

### Money sources (per `main.js`)
| Source | Amount |
|---|---|
| Mission complete | 220–600 (type-dependent) |
| "Shook the cops" survival bonus | `peakStars × 40` (max $200 at 5★) when heat decays to 0 |
| World pickups | Non-cash (ammo/health) |

### Money sinks
| Sink | Cost |
|---|---|
| Refill ammo | $60 |
| +50 Armor | $120 |
| Full health | $80 |
| Unlock SMG | $400 |
| Unlock Shotgun | $550 |
| +Top speed (flat +14, one-time) | $700 |
| +Armor plating (cap →150) | $650 |
| **Hospital bill on death** | **−$100** (floored at 0) |

### Pacing / curve
- **Early (run 1–3, ~$0–600):** consumables only. A clean mission funds 1–2 refills/heals. Death is a real setback (−$100 ≈ a third of a mission).
- **Mid (~$600–1200):** unlock SMG ($400), then a permanent upgrade. ~3–5 missions to first weapon, ~7–10 to a permanent.
- **Late (>$1500):** both upgrades + shotgun bought → **the shop runs dry.** This is the core economy flaw: **money has no late-game sink**, so cash piles up meaninglessly. Curve flattens hard once the 7 items are owned.

**Curve fixes (priority order):** repeatable scaling sinks — vehicle purchases/garage, ammo that drains faster, repair costs, property income that itself costs money to buy. Convert `topSpeedBonus`/`armorMax` from booleans into **tiered** upgrades ($300/$600/$1200…) so spending stays meaningful.

---

## 6. Wanted / Heat Model

### Current behaviour
- `addWanted(n)` adds to `state.wanted` (clamped 0–5), stamps `lastCrime`. Crimes: ped run-over `0.8/kill`, cop kill `1.2`, ped kill `1.1`, generic hit `0.5`, any shot `0.05`.
- `state.stars = floor(state.wanted)`.
- **Spawn:** `maintainPolice` targets `min(6, stars+1)` cruisers, spawned 55–170 m away.
- **Lethality scales with heat:** `heat = clamp(stars/3, 0.6, 1.6)`; cops shoot within 46 m at ~55% hit, fire every ~1–1.9 s.
- **De-escalation:** after **7 s with no crime**, `wanted` decays at `0.12/s` (≈8 s per star — very slow). At a >230 m straggle, individual cops despawn.

### The two missing pillars (◐)
1. **Line-of-sight.** Cops currently shoot through buildings — `updatePolice` only checks raw distance. They should require LOS. **Implementation:** in `updatePolice`, before the shoot/ram block, raycast `cop.pos → player.head` against `city` building AABBs (reuse the `raycastTargets` sphere-test pattern or add `city.segmentBlocked(ax,az,bx,bz)`); gate firing and *wanted accrual* on a clear line. No LOS for N seconds should begin a "searching" sub-state.
2. **Evasion / search cones.** Right now heat only decays on a flat timer regardless of whether cops can see you. Proper model: while **any cop has LOS**, freeze decay and refresh `lastCrime`; when LOS is lost, start a **cooldown bar** (e.g. 8 s at 1★ scaling up per star) — surviving it drops one star. Cops should switch from "pursue last-known-pos" to "wander/search" when LOS breaks. **Implementation:** add `state.copSighted` (bool, set in `updatePolice` LOS pass) and `state.searchTimer`; replace the flat decay in `update()` with: if `copSighted` → no decay; else tick `searchTimer` and drop a star at zero. Hide spots (alleys, tunnels) and breaking LOS become the skill expression.

### Target escalation ladder
| ★ | Response |
|---|---|
| 1 | 1–2 cruisers, light fire, easy shake |
| 2 | 3 cruisers, roadblocks (planned), `EVADE` threshold |
| 3 | 4 cruisers, faster spawn, helicopter spotlight defeats LOS breaks (planned) |
| 4 | SWAT vans, spike strips (planned) |
| 5 | Saturation + armored units; long cooldown to clear |

---

## 7. Difficulty & Accessibility

**Current difficulty knobs** (all in `config.js` / `WEAPONS` / heat constants — good that they're centralized):
- Police lethality (`heat` clamp, `0.55` hit chance), decay rate (`0.12`), spawn target, mission timers (`limit`), hospital fee.

**Recommended toggles (planned ☐):**
- **Difficulty presets** (Casual / Standard / Hard) scaling cop hit chance, decay rate, and mission timers from one table.
- **Aim assist** — widen `raycastTargets` sphere radius or add slight magnetism for cop targets on lower difficulty.
- **Accessibility:** rebindable keys (input layer already abstracts codes), hold-vs-toggle aim/run, colourblind-safe blip palette (current reds/blues are risky), HUD scale slider, screen-shake intensity slider (`rig.addShake` is one call site — easy global multiplier), reduced-flash option for police lights, subtitle/toast persistence. A **photo/easy mode** with no wanted accrual would help showcasing the world.

---

## 8. Top 10 Gameplay Gaps to Close Next

**1. Save/persistence (☐, highest leverage).** Everything resets on reload — money, unlocks, upgrades. Serialize `{money, unlocked:[...], topSpeedBonus, armorMax, weapon}` (and ammo) to `localStorage` on every `buy()` and `endJob('done')`; hydrate in the `state` initializer in `main.js`. Tiny effort, transforms the loop from a toy into a game with stakes.

**2. Police line-of-sight + proper evasion (◐).** As detailed in §6 — add a `city.segmentBlocked()` raycast, gate cop fire and heat decay on LOS, introduce a search/cooldown state. This is the single biggest *feel* fix: stealthy escapes become possible and the city's geometry becomes meaningful instead of decorative.

**3. Drive-by shooting (☐).** `tryShoot` hard-returns when `player.inCar`, killing all car combat. Allow firing from a vehicle with reduced accuracy: in `tryShoot`, when `inCar`, fire along `rig.yaw` (camera dir) with added spread and skip the long-gun. Pairs naturally with CHASE/ELIMINATE missions and the wanted loop.

**4. Vehicle damage & destruction (☐).** The player car is invincible while mission/police cars already track `hp`. Add `hp`, a damage model in `Vehicle._collide` (scale by impact speed), smoke at low hp, and an explosion (reuse `destroyPolice`'s `effects.burst`) that hurts the driver. Makes ramming a two-way risk and chases tense.

**5. Roadblocks & spike strips (☐).** Heat escalation is currently "more cars." In `maintainPolice`, at ≥3★ spawn perpendicular cruiser pairs at intersections ahead of the player (use `city.randomRoadPoint`/lane data and player velocity to place them). Spike strips set a `car.tireDamage` flag reducing `VEHICLE.GRIP`. Gives heat tactical texture.

**6. Economy late-game sinks / vehicle ownership (☐).** Per §5 the shop dries up. Add a garage: buy class-tiered cars ($800–$5000), spawn your owned car at a safehouse, repair fees. Convert `topSpeedBonus`/`armorMax` booleans into tiered purchases. Keeps `state.money` meaningful past the first hour.

**7. Mission variety & a mission-giver chain (◐).** Five random one-offs with no context. Move `MISSIONS[]` to `missions.js`, add 3–4 types (PROTECT/escort, RACE checkpoints reusing the marker, HEIST multi-stage), and a lightweight giver that unlocks harder/better-paid jobs as you complete them — the first thread of progression and narrative.

**8. Reload + ammo pressure + melee (◐).** No reload means SMG/shotgun are pure DPS with no rhythm; pistol's infinite ammo makes others optional. Add magazines (`w.mag`, `w.reserve`, R to reload) and a melee/unarmed attack so a disarmed player isn't helpless. Touches `WEAPONS[]`, `tryShoot`, HUD ammo readout — contained.

**9. Audio depth — music + ambience + footsteps (◐).** `audio.js` has engine/siren/gunshot only. Add a radio-station system (free CC tracks) toggled in-car, footstep/impact SFX, crowd murmur, and a heat-driven music stinger when stars rise. Audio is the cheapest perceived-quality multiplier for a browser game.

**10. Cop & ped reactions / cover (◐).** Cops drive straight at you and shoot; peds wander and flee. Add cops exiting cruisers to shoot on foot (reuse `buildAvatar` + `Pedestrian`-style controller), peds calling police on witnessed crimes (raise wanted via `crowd.alarm` feeding `addWanted`), and basic cover-seeking. Makes the world feel reactive rather than scripted, and ties crowds into the wanted system that currently ignores witnesses.


---


I now have the exact palette hex values, scale constants, and audio synthesis approach grounded in the real code. I have everything I need to write the charter.

# Art Direction, Audio & Realism Charter

> **Project codename:** **LIBERTY DRIVE** (working title)
> **Proposed original name:** **HOLLOWPOINT CITY** — set in the fictional metropolis of **Verano Bay**, a sun-bleached coastal sprawl. Use *Verano Bay* for in-world signage/radio; reserve *Hollowpoint City* as the game title. All names, brands, factions, and characters below are original to this project.

This charter is the single source of truth for how the game **looks, sounds, and feels convincing**. Every AI-generated, CC0, or hand-authored asset must conform to it. It is grounded in the current build: `config.js` constants (`VEHICLE.LENGTH = 8.2`, `CITY.BLOCK = 44`, `CITY.ROAD = 18`), the four district palettes in `city.js`, and the procedural WebAudio synth in `audio.js`.

---

## 1. Visual Identity

### 1.1 The one-line pitch
**Stylized low-poly with crisp, directional lighting and clean readable silhouettes** — warm, slightly oversaturated daytime; moody neon-tinted nights; soft atmospheric fog that hides the draw-distance edge instead of pretending to be photoreal. Think *flat-shaded geometry + one strong sun + honest shadows*, not baked-megascan realism.

### 1.2 What "convincing" means for THIS style
We are **not** chasing photorealism. We chase **coherence and confidence**:
- **Silhouette reads instantly.** A car is a car at 80 m; a cop is a cop by stance and colour; a pickup glints before you can resolve its shape.
- **Consistent light source.** One sun/moon, one shadow direction, one fog colour. Mixed lighting conventions are the #1 thing that makes low-poly look "asset-flip cheap."
- **Material discipline.** Matte surfaces, low metalness, no PBR sparkle fighting the flat aesthetic.
- **Colour does the orienting.** The player should know which district they're in from peripheral vision alone (see §1.3).
- **Juice sells weight.** Tyre smoke, skid decals, screen shake, muzzle flash, and audio-visual sync make simple boxes feel physical (see §4.3).

### 1.3 Palette — per district (authoritative)
These are the live values in `city.js` (`DISTRICTS[]`). Treat them as the **anchor hues**; any new asset placed in a district must sit within ±10% value of its band and must not introduce a competing dominant hue.

| District | Quadrant | Theme | Building hues (hex) | Accent / signage | Mood |
|---|---|---|---|---|---|
| **Terracotta Heights** | NE | Warm residential / old town | `#b0815f #a6745a #c09a6e #97624a #b89a72` | Warm amber, rust red, cream | Sunbaked, lived-in, low-rise |
| **The Spine** (steel/glass) | NW | Corporate / finance | `#6f7a85 #7a8694 #8a96a4 #5f6b78 #9aa6b4` | Cyan glass, cold white | Cool, glossy-but-matte, vertical |
| **Drywall Flats** (pale concrete) | SE | Industrial / suburban grid | `#c6c2b6 #b4b0a2 #d0ccbe #a9a596 #bfbbae` | Faded sign-blue, safety orange | Bright, flat, washed-out |
| **Greenline** (green/teal) | SW | Parks / waterfront | `#5f7a6e #6f8a7e #547064 #789a8c #4f6a5e` | Teal, moss, weathered timber | Cooler, foliage, open |
| **Downtown Core** | center | Mixed / nightlife | blend of all four, darker bases | **Neon** (magenta/cyan/amber) | Densest, tallest, most contrast |

**Shared world palette** (`COLORS` in `config.js`, do not drift): sky `#9fc7e8`, fog `#c8d6e6`, asphalt `#3a3e45`, sidewalk `#787e87`, lane paint `#d9d9c0`, grass `#4a7a44`, sun `#fff3d6`.

**Saturation rule:** buildings desaturated (S ≈ 15–30%), **gameplay objects pop** — vehicles, pickups, job markers, weapons, and peds carry the only high-saturation colours so the eye always finds the interactive thing. Pickups and mission markers use emissive so they read in fog and at night.

### 1.4 Lighting, fog & time-of-day rules
- **Key light:** one `DirectionalLight` = sun/moon, colour `#fff3d6` by day. Single cascaded shadow map; **shadows on hero/near objects only** (player, current vehicle, nearby cars/peds, landmark). Distant buildings receive baked/vertex AO, not realtime shadows.
- **Ambient:** one low `HemisphereLight` (sky tint top, ground-asphalt tint bottom) so shadowed faces never go pure black — flat-shaded geometry needs fill or it reads as a void.
- **Fog:** linear fog, colour = sky colour at the horizon, tuned so the city fades ~1.5–2 grid cells before the far plane (`CITY.CELL ≈ 62 units`). Fog is **the** draw-distance tool — pull the far plane in and let fog hide the cut. Rain thickens fog and shifts it cooler/darker.
- **Time-of-day curve** (drives sun colour, intensity, fog density, sky):

| Phase | Sun colour | Intensity | Fog | Notes |
|---|---|---|---|---|
| Dawn | `#ffc9a0` | rising | warm haze | long shadows, low angle |
| Day | `#fff3d6` | 1.0 | thin `#c8d6e6` | crisp shadows |
| Dusk | `#ff9e7a` | falling | orange haze | hero hour, neon begins |
| Night | `#5566aa` (moon) | 0.25 | dark `#1a2030` | **emissive windows + neon + headlights carry the scene** |

- **Night is emissive-driven, not light-driven.** Lit windows (the `#ffe7a6` window-texture trick already in `city.js`), neon signs (emissive unlit planes), vehicle headlight cones (cheap additive sprites/cones, NOT real spotlights at scale), and street-lamp glow sprites. Keep realtime point lights at or under the budget in §5.
- **Wet look in rain:** raise road roughness slightly and overlay a darkened, faintly reflective (screen-space-cheap or fake cubemap) asphalt tint + reflective puddle decals near kerbs. Avoid true planar reflections — too costly.

---

## 2. Asset Style Guide

Any model/texture — AI-generated, CC0 (Poly Pizza, Quaternius, Kenney, Kay Lousberg packs are ideal matches), or hand-made — must pass this guide before it enters the scene.

### 2.1 Scale & units (authoritative)
World units are metres-ish. **The car is the ruler.**
- **1 car ≈ 8 units long** (build truth: `VEHICLE.LENGTH = 8.2`, `WIDTH = 4.2`). Treat 8 u ≈ a real ~4.5 m car, so **1 unit ≈ 0.55 m**.
- Ped/player height ≈ **3.4 u** (`PLAYER.HEIGHT`) ≈ 1.85 m.
- Lane/road width **18 u**, building lot **44 u**, ground-floor storey ≈ **5–6 u**, door ≈ **3.5–4 u** tall.
- Pickups/weapons sized to read at the player's hand scale; job markers ≈ 4–6 u tall beacons.
- **Anything imported must be uniformly rescaled to these anchors before commit.** Never trust an asset's native scale.

### 2.2 Poly budget ranges (triangles)
Low-poly, silhouette-first. Detail goes into shape, not mesh density.

| Asset class | Tri budget | Notes |
|---|---|---|
| Pedestrian / player | 300–1,200 | Box-avatar lineage; readable stance > fingers |
| Hero vehicle (player can drive) | 1,500–4,000 | Wheels can be low-segment cylinders (8–12 sides) |
| Ambient/traffic vehicle | 800–2,000 | Shared meshes, instanced |
| Building (instanced shell) | 50–400 | Facade detail is **texture**, not geometry |
| Landmark skyscraper | up to 3,000 | One-off, allowed more love |
| Prop (lamp, bin, bench, sign) | 50–600 | Instance aggressively |
| Weapon (first/third-person) | 400–1,500 | Silhouette + 1–2 emissive accents |
| Tree / foliage | 100–500 | Billboard/cross-plane canopies fine |

### 2.3 Materials
- **`MeshStandardMaterial`, matte.** `roughness 0.7–1.0`, `metalness 0.0–0.15`. Glass/chrome may hit `metalness ≤ 0.4` but **only** with a cheap shared env/cube tint — never a heavy realtime reflection.
- **Flat / low-smooth shading.** Hard normals on faceted forms; avoid auto-smoothing that softens the low-poly read. Vertex colours preferred for building tint (already used).
- **Baked AO is encouraged** for static props and buildings (cheap contact shadows without realtime cost). No baked *direct* lighting that would conflict with the live sun.
- **Emissive** is the night currency: windows, neon, brake lights, muzzle, markers, pickups. Keep emissive materials unlit/cheap.
- **No normal maps on flat-shaded low-poly** unless subtle and AO-like — they fight the aesthetic and cost memory.

### 2.4 Textures & texel density
- **Target texel density ≈ 128–256 px per car-length (8 u)** → roughly **16–32 px/unit**, consistent across the world so nothing looks higher-res than its neighbour.
- **Atlas everything.** One shared atlas for props, one tileable set for roads/sidewalks, per-district facade atlas. The existing 128×128 procedural window canvas is the right spirit — keep textures small and tileable.
- **Power-of-two**, ≤ **512×512** for props, ≤ **1024×1024** for shared atlases. `SRGBColorSpace` for colour maps; anisotropy ≤ 4.
- **Trim sheets** for buildings (one sheet → windows, doors, ledges) keep memory flat as the city grows.
- Prefer **vertex colour + small detail texture** over large unique textures — it scales with the procedural city.

### 2.5 Silhouette-first checklist (gate before commit)
1. Recognisable as a black silhouette at 60–80 m? 2. Scale-anchored to the car ruler? 3. Within district palette band? 4. Matte StandardMaterial, low metalness? 5. Under tri budget? 6. Texture atlased & ≤ size cap? 7. Instanced if it repeats? **All seven must pass.**

---

## 3. Audio Identity

Current audio is **fully procedural WebAudio** (`audio.js`) — no asset files, never throws if context is missing. Keep that resilient core; layer optional CC0 one-shots where synthesis falls short (impacts, footsteps, radio music). Everything must duck/priority-mix so the moment-to-moment read stays clear.

### 3.1 Engine — by RPM
Build truth: a single sawtooth oscillator, `freq = 55 + speedNorm*230`, gain `0.04 + speedNorm*0.13`, smoothed via `setTargetAtTime`. Evolve toward a **convincing engine without samples**:
- **Layer 2–3 detuned oscillators** (saw + square + sub-sine) for body; map base freq to a **pseudo-RPM** curve, not raw speed, so it dips on gear-change feel and growls at low end.
- **Per vehicle class** (sedan/sports/muscle/van/compact): different base freq, harmonic mix, and max pitch — muscle = low rumbly sub, sports = higher reedy whine, van = boxy mid.
- Add **idle**, **rev on throttle**, **off-throttle decel burble**, and a **tyre-roll/road-noise** filtered-noise layer that rises with speed.
- Handbrake/drift → **tyre screech** (band-passed noise) synced to the existing skid-mark/smoke system.

### 3.2 Weapons
Build truth: gunshot = decaying noise burst through a 2 kHz lowpass. Differentiate the three weapons:
- **Pistol:** short, sharp, mid lowpass, quick tail.
- **SMG:** faster, thinner, slightly higher-pitched, rapid retrigger; add a subtle mechanical click layer.
- **Shotgun:** louder, lower, longer tail, a touch of sub thump.
- Add **tail/reverb-by-district** (tight in alleys, open downtown), **reload** clicks, **dry-fire** click, and bullet **impact** variants (concrete, metal, flesh).

### 3.3 Impacts & physical sync
- **Vehicle collisions:** crunch (filtered noise + low thump) scaled by impact speed; tyre screech before; glass tinkle for hard hits.
- **Ped run-over / hits:** muted thump + the existing blood VFX must fire on the **same frame** (see §4.3).
- **Explosions:** low boom + noise + a brief sub drop, tied to the explosion particle burst and screen shake.

### 3.4 Ambience & city tone
- **District-tinted ambient bed:** Terracotta Heights = sparse, warm, distant traffic; The Spine = HVAC hum + crowd murmur; Drywall Flats = industrial drone; Greenline = wind + birds/water; Downtown = denser traffic + crowd + faint music bleed.
- **Day vs night** crossfade (traffic down at night, crickets/electrical hum up).
- Crossfade between beds by **player position** (sample the district grid), never hard-cut.

### 3.5 Weather
- **Rain:** layered filtered-noise loop, intensity tracking the existing weather system; add occasional **thunder** (sub boom + delayed crack) and **wipers/water-on-metal** when driving in rain.

### 3.6 UI
- Soft, synthesized, non-fatiguing: hover blip, confirm, cancel, error buzz, money/pickup chime, **wanted-star sting** (rising tone per star gained), mission start/success/fail stings. Keep these short and distinct from gameplay sounds.

### 3.7 Radio system
- **Per-vehicle car radio**: 3–5 original stations (e.g. *Bay FM* soft rock, *Subgrid* electronic, *Verano Talk* fake call-in, *La Costa* latin pop, a static "off" slot). Use **CC0 / royalty-free or original-generated** tracks only — never real songs/artists.
- Station persists per session, switchable with a key; **ducks** under sirens, gunfire, and dialogue (§3.8). Talk station = original VO/text-to-speech satire of the city, reinforcing the original IP.

### 3.8 Mix & priority (ducking ladder, highest wins)
1. **Critical UI / mission stings** (brief, top priority)
2. **Player gunfire & nearby explosions**
3. **Player engine + tyre screech**
4. **Police siren** (the existing smooth sine wail — keep it; it's pleasant, not buzzy)
5. **Impacts / ped reactions**
6. **Car radio** (auto-ducks under 1–5)
7. **Ambience bed** (always lowest, never masks gameplay)
- **Distance attenuation + max-voices cap** (see §5). Cull farthest/quietest first. Master gain stays ~0.5 (build default); never clip — compress on the master bus.

---

## 4. Realism & Consistency Charter

"Genuinely convincing" for a stylized sandbox = **internally consistent and physically plausible**, not photoreal. The world must obey its own rules every time.

### 4.1 Physical plausibility tiers
- **Tier 1 — Must be plausible (player-facing core):** car acceleration/braking/grip/drift feel; collision response (circle-vs-AABB, current model); weapon hit registration; fall/death; momentum carrying through skids. These define the game feel — tune relentlessly.
- **Tier 2 — Should be plausible (readable but arcade):** ped reactions, police pursuit logic, traffic flow, damage scaling. Arcade simplifications allowed if they *read* right.
- **Tier 3 — May be faked (background):** distant traffic, far peds, building interiors (none), precise tyre physics, suspension. Fake freely to protect the budget.

### 4.2 World coherence rules
- **Traffic obeys roads.** AI vehicles stay on the road grid (`gridLines`), pick lanes, stop/slow for obstacles, and don't clip buildings. No cars on sidewalks except as a chaos consequence.
- **Peds react.** Flee from gunfire/reckless driving, use sidewalks, cross at intersections, visibly respond to being threatened or hit. A ped that ignores a speeding car breaks the illusion instantly.
- **Police escalate coherently** with the wanted/heat system: more stars → more/tougher units, matching the existing spawn/chase/shoot loop. De-escalation when hidden.
- **Economy makes sense.** Mission payouts, shop prices (armor/ammo/weapons/upgrades), and pickup values stay in a sane ratio — early missions afford basics, big upgrades require real play. No infinite-money loops.
- **Districts stay coherent.** Asset placement, ambience, and palette match the district (no waterfront palms in the industrial flats).

### 4.3 Audio-visual sync (non-negotiable)
Every impactful event fires **visual + audio on the same frame**:

| Event | Visual | Audio |
|---|---|---|
| Gunshot | muzzle flash + tracer | weapon report |
| Bullet hit | spark/blood decal | impact variant |
| Skid/drift | tyre smoke + skid decal | screech (synced to grip loss) |
| Collision | debris/shake | crunch scaled by speed |
| Explosion | particle burst + shake | boom + sub |
| Pickup/money | flash + HUD tick | chime |
| Wanted star | HUD star + flash | rising sting |
| Engine | (vehicle motion) | RPM-mapped pitch |

Desync (sound late, flash with no bang) is treated as a **bug**, not polish.

### 4.4 Performance budget — hard 60 fps target
The whole project lives or dies here. **No asset or system may push past these on a mid-range laptop (integrated-ish GPU). Treat as ceilings, not goals.**

| Metric | Budget (per frame) | Enforcement |
|---|---|---|
| **Frame time** | ≤ 16.6 ms (60 fps); soft floor 33 ms (30 fps) on weak HW | profile in build |
| **Draw calls** | **≤ 300–400** | **instance buildings/props/traffic**; merge static geo (`mergeGeometries` already used) |
| **Triangles on screen** | **≤ ~1.0–1.5 M** | fog-limited draw distance + LOD/cull |
| **Realtime shadow-casters** | **1 light, hero/near objects only** | everything else baked/vertex AO |
| **Realtime point/spot lights** | **≤ 8 active** | headlights/neon are emissive sprites, not lights |
| **Active particles** | **≤ ~1,000** pooled | reuse the existing pooled `effects.js` system; cap & recycle |
| **Texture memory** | **≤ ~256 MB** total | atlases, ≤1024² shared / ≤512² props, POT |
| **Audio voices** | **≤ ~24 concurrent** | priority ladder §3.8, distance cull |
| **Unique materials** | minimise | share materials; vertex colour over per-mesh tint |

**Scaling tools** (use these before sacrificing the budget): pull the far plane in and thicken fog; LOD distant buildings to flat impostors; instance and frustum-cull aggressively; pool everything (particles, audio nodes, traffic, peds); cap simultaneous peds/cars by distance.

---

## 5. Consistency Gate (definition of done for any asset/system)
An asset or feature ships only when it: **(1)** matches its district palette band; **(2)** is scaled to the car ruler (8 u); **(3)** uses matte StandardMaterial, low metalness, atlased POT texture within size/texel caps; **(4)** is under its tri budget and instanced if repeated; **(5)** has synced audio for every impactful event; **(6)** respects the §4.4 budget (draw calls, lights, particles, memory, voices); and **(7)** keeps the world coherent (traffic on roads, peds reacting, economy sane). If it fails any one, it is not done.


---


# Roadmap & Definition of Convincing

> Working title is fine, but consider **"FREEDRIVE: LIBERTY HEIGHTS"** or simply **"OVERPASS"** — short, ownable, trademark-clear, and evokes the open road without leaning on the GTA name. Below we use **the game** generically.

This roadmap is grounded in the current build: an 8x8 block grid, four colour districts + downtown core + one landmark, day/night + rain, arcade driving with 5 vehicle classes, carjack, 5 data-driven mission types, wanted/heat with police, 3 weapons, economy + loadout shop, pickups, minimap/full map, HUD, and juice. Custom arcade physics, box-avatar peds, no real meshes/audio/story yet.

The phases are ordered to convert a **verified tech demo** into a **convincing small-scale sandbox** with the least wasted effort.

---

## Phase A — Foundation *(mostly DONE)*

**Goal:** prove the core loop is fun and stable. This is essentially complete; remaining work is hardening, not new scope.

**Deliverables**
- [x] City grid, districts, downtown core, landmark
- [x] Day/night + rain
- [x] Arcade driving (grip/drift/handbrake), 5 vehicle classes
- [x] Carjack enter/exit
- [x] 5 mission types from a job marker (DELIVER/CHASE/EVADE/COLLECT/ELIMINATE)
- [x] Wanted/heat, police spawn/chase/shoot
- [x] 3 weapons + ped HP, economy + loadout shop, pickups
- [x] Minimap + full map, HUD, juice (muzzle/tracers/blood/explosions/skid/shake)
- [ ] **Hardening:** fixed-timestep physics loop (decouple sim from framerate); seeded RNG for reproducible test runs; a `?debug` URL flag exposing teleport/spawn/give-money/set-wanted for fast QA
- [ ] **Headless smoke test** that boots the world, runs one mission to completion, and exits non-zero on uncaught errors (already have the harness from the liberty3d setup)

**EXIT CRITERIA**
- 60 FPS on a mid-range laptop (integrated GPU) with full city loaded.
- Player can: spawn → drive → carjack → complete each of the 5 mission types → earn money → buy from shop → die/respawn — with **zero console errors** across a 10-minute session.
- Headless smoke test passes in CI.

---

## Phase B — Content & Identity *(NEXT — highest leverage)*

**Goal:** stop looking like a tech demo. Give the world a face, a voice, and a reason to keep playing. This is where "convincing" is won.

**Deliverables**
- **Real meshes (free assets):** swap box vehicles for low-poly car models (Kenney "Car Kit" / Quaternius — CC0); rig 1 player + 3 ped body types with a free mocap walk/run/idle (Mixamo, retargeted). Keep <2k tris/ped, shared atlas texture.
- **Texturing pass:** one shared low-poly material atlas per district palette; baked vertex AO on buildings; emissive windows at night; wet-look road material toggled by weather.
- **Original IP fiction bible (1–2 pages):** city name (e.g., *Liberty Heights*), 4 district names tied to the existing colours, 3–4 factions, 5 brand parodies (cars, food, radio), the protagonist + 2–3 named contacts. **No real-world or Rockstar references.**
- **Story spine:** 6–8 hand-authored story missions chaining the existing 5 mission *types* with scripted intros/outros, reusing the data-driven mission system. A simple linear unlock (mission N unlocks N+1).
- **Dialogue:** lightweight text-based dialogue boxes with portraits (no voice yet); branching not required — just flavour + objective framing.
- **Audio (free/CC0):** engine loop (pitch-by-speed), tyre screech, gunfire per weapon, impact/explosion, UI clicks, 2–3 looping radio music beds, ambient city hum. One-shot pool + spatialization via Three.js `PositionalAudio`.

**EXIT CRITERIA**
- No box-avatars or box-cars visible in normal play.
- A new player can complete the **first 3 story missions** guided only by in-world markers + dialogue.
- Every major action (engine, tyres, guns, impacts, UI, music) has audio; muting/volume works.
- Fiction bible reviewed for IP cleanliness; zero trademarked terms in shipped strings.

---

## Phase C — Systems Depth

**Goal:** make the world feel alive and the heat feel fair. Only start once B's identity is in place.

**Deliverables**
- **Traffic AI:** lane-following cars on the grid (waypoint graph from block edges), stop at simple intersections, yield/brake for the player, despawn off-screen. Target 20–40 active vehicles.
- **Pedestrian AI:** sidewalk wander, flee from gunfire/reckless driving, crowd density by district/time-of-day.
- **Heat depth:** line-of-sight detection (police must *see* you), last-known-position search, a "cooling" evade timer when out of sight, escalating star tiers (roadblocks at high stars). Make escaping a skill, not a wait.
- **More weapons/vehicles:** +2 weapons (e.g., rifle, thrown explosive) with distinct feel; +2 vehicle classes (e.g., motorcycle, heavy truck) with handling that matters.
- **Save hooks:** define a serializable game-state schema now (player, economy, mission progress, unlocks) even if full save lands in D.

**EXIT CRITERIA**
- Traffic and peds populate the city without dropping below 50 FPS.
- A player can deliberately **break line of sight and lose a 2–3 star wanted level** through skillful driving — escape feels earned.
- New weapons/vehicles each have a clear role; no duplicates of existing feel.

---

## Phase D — Polish & Ship

**Goal:** turn a good build into a finished, shareable game.

**Deliverables**
- **Performance:** instanced rendering for buildings/props/traffic; frustum + distance culling; LODs on vehicles/peds; texture atlas consolidation; object pooling for bullets/effects/audio. Budget: <16ms frame on target hardware.
- **Options menu:** graphics presets (low/med/high), audio sliders, key rebinding, invert/sensitivity, FPS cap.
- **Save/load:** `localStorage` slots using the C schema; autosave on mission complete + manual save; safe migration/versioning.
- **Onboarding:** first-run tutorial overlay for drive/enter/exit/shoot/mission/map.
- **Pause + accessibility:** pause menu, colourblind-safe HUD markers, remappable everything, subtitle toggle.
- **Ship:** production Vite build, asset compression (Draco/ktx2 where it pays), licence/credits screen for all CC0/CC-BY assets, a hosted demo link.

**EXIT CRITERIA**
- Cold load to playable in **<5s on broadband**; stable 60 FPS on target hardware with presets.
- Quit and resume restores exact progress.
- A stranger can start the game and reach their first mission **without external instructions**.
- Credits correctly attribute every third-party asset; build passes an IP-cleanliness review.

---

## DEFINITION OF CONVINCING

The bar that means **done-enough** — not AAA, but unmistakably a *game*, not a tech demo. A first-time player, with no guidance, should be able to do all of this in one ~15-minute sitting:

- [ ] **It looks intentional.** Real (low-poly) cars and people, district identity readable at a glance, night/rain that changes the mood — no placeholder boxes.
- [ ] **Driving feels good in 10 seconds.** Pick up a car, and the grip/drift/handbrake is immediately satisfying. This is the hook.
- [ ] **The world has a voice.** Engines rev, tyres screech, guns crack, radio plays, the city hums. Muting is a choice, not a relief.
- [ ] **A mission has a frame.** A named contact gives a reason, markers guide, an outro pays off — not just "go to dot, get money."
- [ ] **Heat is a story arc.** Do something wrong → stars rise → police *see* and chase → you break line of sight and *escape by driving well* → tension releases. The full crime-and-getaway loop lands.
- [ ] **There's a thread to pull.** Finishing a mission unlocks the next; the player understands there's a story, not just a sandbox.
- [ ] **It remembers you.** Close the tab, come back, progress and money are still there.
- [ ] **It runs.** No console errors, no sub-30 FPS stutter, no soft-locks across a 15-minute session.

> **Litmus test:** show it to someone cold. If they drive, take a mission, catch a wanted level, escape, and *ask what happens next in the story* — without you explaining anything — it's convincing.

---

## KEEP IT ON RAILS *(operating procedure)*

A lightweight loop so every work cycle moves the needle and nothing drifts into fantasy scope.

### 1. Maintain a living tracker
Keep a single `TRACKER.md` (or GitHub Project) with every task as a row: `id · phase · title · status · leverage · effort · verified?`. It is the **single source of truth**; the roadmap is the map, the tracker is the odometer.

### 2. Pick the next task by leverage score
Each cycle, score candidate tasks and take the top one:

```
leverage = (player-visible impact × phase-priority) ÷ effort
```

- **impact (1–5):** how much it moves the "Definition of Convincing".
- **phase-priority:** current phase = ×3, next phase = ×1, later = ×0 (don't pull future work forward).
- **effort (1–5):** rough dev-days.

Tie-breakers: unblocks other work > reduces risk > fixes a known bug. **Never** start a later-phase task while a current-phase exit criterion is unmet.

### 3. Definition of Done = verified in-browser
A task is **not done** until:
1. It builds clean (`vite build`, no errors/warnings introduced).
2. It runs in a real browser session with **zero new console errors**.
3. The specific behaviour is **observed** (screenshot or short clip) — driving feels right, audio plays, mission completes, save restores. Headless smoke test still passes.
4. The tracker row is flipped to `verified ✅` with a one-line note of what was observed.

### 4. Cycle ritual
1. **Pick** — highest-leverage task in the current phase.
2. **Slice** — if effort > 2 days, split until each slice is independently verifiable.
3. **Build** — implement the smallest shippable slice.
4. **Verify** — in-browser, against step 3's bar.
5. **Record** — update the tracker; note any new tasks discovered.
6. **Gate** — at phase end, run the full EXIT CRITERIA before advancing.

### 5. Guardrails
- **One vertical slice at a time** — finish drive→mission→heat→escape end-to-end before widening.
- **Free/CC0 assets only**, attribution logged on creation, not at the end.
- **IP hygiene every cycle** — no real brands/Rockstar terms enters a commit.
- **Perf budget is a feature** — if a change drops below the phase FPS floor, it isn't done.
- **Scope ratchet** — new ideas go to a `BACKLOG` section, never into the current cycle.
